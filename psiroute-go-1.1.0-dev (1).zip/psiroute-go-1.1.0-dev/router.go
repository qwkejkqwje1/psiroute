package main

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
	"time"
)

// Outbound names used across the router, stats and UI.
const (
	obPsiphon = "psiphon"
	obDirect  = "direct"
	obDesync  = "direct-dpi"
	obWarp    = "warp"
	obProxy   = "proxy"
	obBlock   = "block"
	obAuto    = "auto"
)

var errBlocked = errors.New("заблокировано правилом")

// learned remembers the outbound that last worked for a host.
type learned struct {
	Host     string `json:"host"`
	Outbound string `json:"outbound"`
	Reason   string `json:"reason"`
	Failed   int    `json:"failed"`
	Hits     int    `json:"hits"`
	Updated  int64  `json:"updated,omitempty"` // unix seconds of the last (re)learn
}

const (
	learnedTTL = 14 * 24 * time.Hour // re-check a learned route after two weeks
	learnedMax = 2000                // hard cap on remembered hosts
)

// Router picks an outbound for each connection.
type Router struct {
	app  *App
	mu   sync.Mutex
	seen map[string]*learned
	file string

	saveMu    sync.Mutex
	saveTimer *time.Timer
}

func newRouter(app *App, file string) *Router {
	r := &Router{app: app, seen: map[string]*learned{}, file: file}
	if b, err := os.ReadFile(file); err == nil {
		var list []*learned
		if json.Unmarshal(b, &list) == nil {
			now := time.Now().Unix()
			for _, l := range list {
				if l == nil || l.Host == "" {
					continue
				}
				if l.Updated == 0 {
					l.Updated = now // files from 1.0.0 have no timestamp
				}
				l.Host = cleanHostKey(l.Host)
				r.seen[l.Host] = l
			}
		}
	}
	return r
}

// dialer returns the dial function for an outbound name.
func (r *Router) dialer(name string) dialFunc {
	if cc, ok := countryOf(name); ok {
		return func(ctx context.Context, network, addr string) (net.Conn, error) {
			return r.app.countries.Dial(ctx, cc, addr)
		}
	}
	switch name {
	case obBlock:
		return func(ctx context.Context, network, addr string) (net.Conn, error) {
			return nil, errBlocked
		}
	case obPsiphon:
		return r.app.psi.Dial
	case obDesync:
		return func(ctx context.Context, network, addr string) (net.Conn, error) {
			r.app.cfg.mu.Lock()
			m := r.app.cfg.Desync.Method
			r.app.cfg.mu.Unlock()
			return dialObfs(ctx, network, addr, m)
		}
	case obWarp:
		return func(ctx context.Context, network, addr string) (net.Conn, error) {
			r.app.cfg.mu.Lock()
			socks := r.app.cfg.Warp.Socks
			builtin := r.app.cfg.Warp.Enabled && r.app.cfg.Warp.Engine != "socks"
			r.app.cfg.mu.Unlock()
			if builtin && r.app.warp != nil {
				return r.app.warp.Dial(ctx, network, addr) // the built-in WARP
			}
			return dialSocks5(ctx, socks, addr, "", "")
		}
	case obProxy:
		return func(ctx context.Context, network, addr string) (net.Conn, error) {
			r.app.cfg.mu.Lock()
			up := r.app.cfg.Proxy.Upstream
			r.app.cfg.mu.Unlock()
			return dialUpstream(ctx, up, addr)
		}
	default:
		return dialDirect
	}
}

// matchRule returns the outbound of the first matching rule.
//
// Inside one rule the host conditions (domains, keywords, CIDR) are OR-ed,
// and ports, when given, are AND-ed with them: {domains:[x.com], ports:[443]}
// means "x.com on port 443", not "anything on 443". A rule with ports only
// matches by port.
func (r *Router) matchRule(host string, port int) (string, string) {
	return r.matchRuleFor(host, port, "", false)
}

// appMatches: "chrome", "chrome.exe" and "C:\...\chrome.exe" all mean the
// same program; the comparison ignores case.
func appMatches(list []string, app string) bool {
	norm := func(s string) string {
		s = strings.ToLower(strings.TrimSpace(s))
		if i := strings.LastIndexAny(s, `\/`); i >= 0 {
			s = s[i+1:]
		}
		return strings.TrimSuffix(s, ".exe")
	}
	app = norm(app)
	if app == "" {
		return false
	}
	for _, x := range list {
		if x = norm(x); x != "" && x == app {
			return true
		}
	}
	return false
}

// matchRuleFor: the first matching rule for a connection from program app.
// alwaysOnly limits the search to rules marked «always».
func (r *Router) matchRuleFor(host string, port int, app string, alwaysOnly bool) (string, string) {
	return r.matchRuleForIP(host, "", port, app, alwaysOnly)
}

func (r *Router) matchRuleForIP(host, dstIP string, port int, app string, alwaysOnly bool) (string, string) {
	r.app.cfg.mu.Lock()
	rules := append([]Rule(nil), r.app.cfg.Routing.Rules...)
	r.app.cfg.mu.Unlock()
	host = cleanHostKey(host)
	var ips []net.IP
	if ip := net.ParseIP(host); ip != nil {
		ips = append(ips, ip)
	} else if cached := theDNS.cachedIPs(host); len(cached) > 0 {
		ips = append(ips, cached...)
	}
	if dstIP != "" && dstIP != host {
		if ip := net.ParseIP(cleanHostKey(dstIP)); ip != nil {
			ips = append(ips, ip)
		}
	}
	for _, ru := range rules {
		if ru.Outbound == "" || (alwaysOnly && !ru.Always) {
			continue
		}
		hostCond := len(ru.Domains)+len(ru.Keywords)+len(ru.CIDR)+len(ru.Lists) > 0
		if !hostCond && len(ru.Ports) == 0 && len(ru.Apps) == 0 {
			continue // empty rule matches nothing
		}
		if len(ru.Apps) > 0 && !appMatches(ru.Apps, app) {
			continue
		}
		if len(ru.Ports) > 0 {
			okPort := false
			for _, p := range ru.Ports {
				if p == port {
					okPort = true
					break
				}
			}
			if !okPort {
				continue
			}
		}
		if !hostCond || ruleHostMatch(ru, host, ips) || r.app.lists.MatchIPs(ru.Lists, host, ips) {
			return ru.Outbound, ru.Name
		}
	}
	return "", ""
}

func ruleHostMatch(ru Rule, host string, ips []net.IP) bool {
	for _, d := range ru.Domains {
		if hostMatches(host, d) {
			return true
		}
	}
	for _, k := range ru.Keywords {
		if k = strings.ToLower(strings.TrimSpace(k)); k != "" && strings.Contains(host, k) {
			return true
		}
	}
	if len(ips) > 0 {
		for _, c := range ru.CIDR {
			if n := parseCIDRCached(c); n != nil {
				for _, ip := range ips {
					if n.Contains(ip) {
						return true
					}
				}
			}
		}
	}
	return false
}

// cidrCache avoids re-parsing CIDR strings on every connection.
var cidrCache sync.Map // string -> *net.IPNet (nil for invalid input)

func parseCIDRCached(c string) *net.IPNet {
	c = strings.TrimSpace(c)
	if v, ok := cidrCache.Load(c); ok {
		return v.(*net.IPNet)
	}
	var n *net.IPNet
	if _, nn, err := net.ParseCIDR(c); err == nil {
		n = nn
	} else if ip := net.ParseIP(c); ip != nil { // a bare IP is a /32 or /128
		if v4 := ip.To4(); v4 != nil {
			n = &net.IPNet{IP: v4, Mask: net.CIDRMask(32, 32)}
		} else {
			n = &net.IPNet{IP: ip, Mask: net.CIDRMask(128, 128)}
		}
	}
	cidrCache.Store(c, n)
	return n
}

// cleanHostKey lower-cases a host, drops a trailing dot and IPv6 brackets.
func cleanHostKey(h string) string {
	h = strings.ToLower(strings.TrimSpace(h))
	h = strings.TrimSuffix(h, ".")
	h = strings.TrimPrefix(h, "[")
	h = strings.TrimSuffix(h, "]")
	return h
}

// hostMatches reports whether host equals pat or is a subdomain of it.
// IP addresses only match exactly (1.2.3.4 is not a "subdomain" of 2.3.4).
func hostMatches(host, pat string) bool {
	host = cleanHostKey(host)
	pat = cleanHostKey(strings.TrimPrefix(strings.TrimSpace(pat), "*."))
	if host == "" || pat == "" {
		return false
	}
	if host == pat {
		return true
	}
	if net.ParseIP(host) != nil || net.ParseIP(pat) != nil {
		return false
	}
	return strings.HasSuffix(host, "."+pat)
}

// plan returns the ordered outbounds to try for a destination.
func (r *Router) plan(host string, port int) (order []string, rule string) {
	return r.planFor(host, port, "")
}

// planFor: the outbound order for a connection from program app ("" when
// unknown: HTTP API checks, LAN clients without a name).
func (r *Router) planFor(host string, port int, app string) (order []string, rule string) {
	return r.planForIP(host, "", port, app)
}

func (r *Router) expandAuto(host string, chain []string, learn, desync, failover bool) ([]string, bool) {
	if learn {
		if ob := r.learnedFor(host); ob != "" {
			order := []string{ob}
			if failover && ob != obPsiphon && ob != obBlock {
				order = append(order, obPsiphon)
			}
			return order, true
		}
	}
	var order []string
	for _, ob := range chain {
		if ob == obDesync && !desync {
			continue
		}
		order = append(order, ob)
	}
	if len(order) == 0 {
		order = []string{obPsiphon}
	}
	if failover {
		has := false
		for _, o := range order {
			if o == obPsiphon {
				has = true
			}
		}
		if !has {
			order = append(order, obPsiphon)
		}
	}
	return order, false
}

func (r *Router) expandRuleOutbound(ob, name, host string, chain []string, learn, desync, failover bool) ([]string, string) {
	if ob == obBlock {
		return []string{obBlock}, name
	}
	if ob == obAuto {
		order, _ := r.expandAuto(host, chain, learn, desync, failover)
		return order, name
	}
	order := []string{ob}
	if isCountryOb(ob) {
		return order, name
	}
	if failover && ob != obPsiphon {
		order = append(order, obPsiphon)
	}
	return order, name
}

func (r *Router) planForIP(host, dstIP string, port int, app string) (order []string, rule string) {
	r.app.cfg.mu.Lock()
	mode := r.app.cfg.Routing.Mode
	def := r.app.cfg.Routing.Default
	chain := append([]string(nil), r.app.cfg.Routing.Chain...)
	failover := r.app.cfg.Routing.Failover
	learn := r.app.cfg.Routing.Learn
	desync := r.app.cfg.Desync.Enabled
	r.app.cfg.mu.Unlock()

	// Rules marked «always» win in every mode, before learned routes.
	if mode != "rules" {
		if ob, name := r.matchRuleForIP(host, dstIP, port, app, true); ob != "" {
			return r.expandRuleOutbound(ob, name, host, chain, learn, desync, failover)
		}
	}

	// Learned routes are an "auto" mode feature only: in "psiphon" mode the
	// user asked for everything through the tunnel, and in "rules" mode the
	// explicit rules win (unless a rule itself selects "auto").
	if learn && mode == "auto" {
		if ob := r.learnedFor(host); ob != "" {
			order = []string{ob}
			if failover && ob != obPsiphon && ob != obBlock {
				order = append(order, obPsiphon)
			}
			return order, "выученный"
		}
	}

	switch mode {
	case "rules":
		if ob, name := r.matchRuleForIP(host, dstIP, port, app, false); ob != "" {
			return r.expandRuleOutbound(ob, name, host, chain, learn, desync, failover)
		}
		return r.expandRuleOutbound(def, "по умолчанию", host, chain, learn, desync, failover)
	case "auto":
		order, _ = r.expandAuto(host, chain, false, desync, failover)
		return order, "автоподбор"
	default: // psiphon
		return []string{obPsiphon}, "всё через Psiphon"
	}
}

// learnedFor returns the remembered outbound for host ("" if none or stale).
func (r *Router) learnedFor(host string) string {
	host = cleanHostKey(host)
	r.mu.Lock()
	defer r.mu.Unlock()
	l := r.seen[host]
	if l == nil || l.Outbound == "" {
		return ""
	}
	if l.Updated > 0 && time.Since(time.Unix(l.Updated, 0)) > learnedTTL {
		delete(r.seen, host) // expired: let the auto chain re-check the host
		r.scheduleSave()
		return ""
	}
	l.Hits++ // counts real use, so the UI list is sorted by popularity
	return l.Outbound
}

// remember stores the working outbound for a host.
func (r *Router) remember(host, outbound, reason string, ok bool) {
	r.app.cfg.mu.Lock()
	learn := r.app.cfg.Routing.Learn
	r.app.cfg.mu.Unlock()
	host = cleanHostKey(host)
	if !learn || host == "" || outbound == obBlock {
		return
	}
	r.mu.Lock()
	l := r.seen[host]
	if l == nil {
		if !ok {
			r.mu.Unlock()
			return // nothing to count a failure against
		}
		r.evictLocked()
		l = &learned{Host: host}
		r.seen[host] = l
	}
	if ok {
		if l.Outbound != outbound {
			l.Failed = 0
		}
		l.Outbound = outbound
		l.Reason = reason
		l.Updated = time.Now().Unix()
	} else {
		l.Failed++
		if l.Failed >= 3 {
			delete(r.seen, host) // keeps failing: forget and re-learn
		}
	}
	r.scheduleSave()
	r.mu.Unlock()
}

// evictLocked keeps the table under learnedMax by dropping the oldest entry.
func (r *Router) evictLocked() {
	if len(r.seen) < learnedMax {
		return
	}
	oldK, oldT := "", int64(1<<62)
	for k, l := range r.seen {
		if l.Updated < oldT {
			oldK, oldT = k, l.Updated
		}
	}
	delete(r.seen, oldK)
}

func (r *Router) forget(host string) {
	host = cleanHostKey(host)
	r.mu.Lock()
	delete(r.seen, host)
	// also drop learned subdomains, so a new rule for x.com wins for a.x.com
	for k := range r.seen {
		if hostMatches(k, host) {
			delete(r.seen, k)
		}
	}
	r.scheduleSave()
	r.mu.Unlock()
}

func (r *Router) clearLearned() {
	r.mu.Lock()
	r.seen = map[string]*learned{}
	r.scheduleSave()
	r.mu.Unlock()
}

// scheduleSave coalesces writes: at most one disk write per 2 seconds, done
// outside the routing lock, so a burst of failovers does not hit the disk on
// every connection. Safe to call with r.mu held.
func (r *Router) scheduleSave() {
	r.saveMu.Lock()
	defer r.saveMu.Unlock()
	if r.saveTimer != nil {
		return
	}
	r.saveTimer = time.AfterFunc(2*time.Second, func() {
		r.saveMu.Lock()
		r.saveTimer = nil
		r.saveMu.Unlock()
		r.saveNow()
	})
}

// saveNow writes the learned table atomically (temp file + rename).
func (r *Router) saveNow() {
	r.mu.Lock()
	list := make([]learned, 0, len(r.seen))
	for _, l := range r.seen {
		list = append(list, *l)
	}
	r.mu.Unlock()
	if r.file == "" {
		return
	}
	if b, err := json.Marshal(list); err == nil {
		_ = writeFileAtomic(r.file, b)
	}
}

// flush writes pending changes immediately (used on shutdown and in tests).
func (r *Router) flush() {
	r.saveMu.Lock()
	pending := r.saveTimer != nil
	if pending {
		r.saveTimer.Stop()
		r.saveTimer = nil
	}
	r.saveMu.Unlock()
	if pending {
		r.saveNow()
	}
}

// writeFileAtomic writes via a temp file so a crash never leaves a torn file.
func writeFileAtomic(path string, b []byte) error {
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func (r *Router) learnedList() []map[string]any {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]map[string]any, 0, len(r.seen))
	for _, l := range r.seen {
		out = append(out, map[string]any{"host": l.Host, "outbound": l.Outbound,
			"reason": l.Reason, "failed": l.Failed, "hits": l.Hits})
	}
	sort.Slice(out, func(i, j int) bool { return out[i]["hits"].(int) > out[j]["hits"].(int) })
	if len(out) > 200 {
		out = out[:200]
	}
	return out
}

// dialSocks5 is a tiny SOCKS5 client (CONNECT, optional user/pass).
func dialSocks5(ctx context.Context, server, addr, user, pass string) (net.Conn, error) {
	if server == "" {
		return nil, fmt.Errorf("не задан адрес SOCKS")
	}
	server = strings.TrimPrefix(server, "socks5://")
	d := net.Dialer{Timeout: 10 * time.Second}
	c, err := d.DialContext(ctx, "tcp", server)
	if err != nil {
		return nil, err
	}
	fail := func(e error) (net.Conn, error) { c.Close(); return nil, e }
	_ = c.SetDeadline(time.Now().Add(15 * time.Second))
	if len(user) > 255 || len(pass) > 255 {
		return fail(fmt.Errorf("SOCKS: слишком длинный логин или пароль"))
	}
	if user != "" {
		if _, err := c.Write([]byte{5, 2, 0, 2}); err != nil {
			return fail(err)
		}
	} else {
		if _, err := c.Write([]byte{5, 1, 0}); err != nil {
			return fail(err)
		}
	}
	rep := make([]byte, 2)
	if _, err := readFull(c, rep); err != nil {
		return fail(err)
	}
	if rep[0] != 5 {
		return fail(fmt.Errorf("не SOCKS5"))
	}
	if rep[1] == 2 {
		if user == "" {
			return fail(fmt.Errorf("SOCKS: сервер требует логин и пароль"))
		}
		ub := append([]byte{1, byte(len(user))}, user...)
		ub = append(ub, byte(len(pass)))
		ub = append(ub, pass...)
		if _, err := c.Write(ub); err != nil {
			return fail(err)
		}
		ar := make([]byte, 2)
		if _, err := readFull(c, ar); err != nil {
			return fail(err)
		}
		if ar[1] != 0 {
			return fail(fmt.Errorf("SOCKS: отказ авторизации"))
		}
	} else if rep[1] != 0 {
		return fail(fmt.Errorf("SOCKS: метод не поддерживается"))
	}
	host, portStr, err := net.SplitHostPort(addr)
	if err != nil {
		return fail(err)
	}
	port := atoiSafe(portStr)
	var req []byte
	if ip := net.ParseIP(host); ip != nil && ip.To4() != nil {
		req = append([]byte{5, 1, 0, 1}, ip.To4()...)
	} else if ip != nil {
		req = append([]byte{5, 1, 0, 4}, ip.To16()...)
	} else {
		if len(host) > 255 {
			return fail(fmt.Errorf("SOCKS: слишком длинное имя хоста"))
		}
		req = append([]byte{5, 1, 0, 3, byte(len(host))}, host...)
	}
	req = append(req, byte(port>>8), byte(port))
	if _, err := c.Write(req); err != nil {
		return fail(err)
	}
	head := make([]byte, 4)
	if _, err := readFull(c, head); err != nil {
		return fail(err)
	}
	if head[1] != 0 {
		return fail(fmt.Errorf("SOCKS: отказ (код %d)", head[1]))
	}
	var skip int
	switch head[3] {
	case 1:
		skip = 4
	case 3:
		one := make([]byte, 1)
		if _, err := readFull(c, one); err != nil {
			return fail(err)
		}
		skip = int(one[0])
	case 4:
		skip = 16
	}
	if _, err := readFull(c, make([]byte, skip+2)); err != nil {
		return fail(err)
	}
	_ = c.SetDeadline(time.Time{})
	return c, nil
}

// dialUpstream dials through socks5:// or http(s):// upstream proxies.
func dialUpstream(ctx context.Context, upstream, addr string) (net.Conn, error) {
	u, err := url.Parse(upstream)
	if err != nil || u.Host == "" {
		return nil, fmt.Errorf("неверный адрес прокси")
	}
	switch strings.ToLower(u.Scheme) {
	case "socks5", "socks5h", "socks", "":
		user := ""
		pass := ""
		if u.User != nil {
			user = u.User.Username()
			pass, _ = u.User.Password()
		}
		return dialSocks5(ctx, u.Host, addr, user, pass)
	case "http", "https":
		return dialHTTPConnect(ctx, u, addr)
	}
	return nil, fmt.Errorf("неподдерживаемый прокси: %s", u.Scheme)
}

func dialHTTPConnect(ctx context.Context, u *url.URL, addr string) (net.Conn, error) {
	d := net.Dialer{Timeout: 10 * time.Second}
	hostPort := u.Host
	if u.Port() == "" {
		if strings.EqualFold(u.Scheme, "https") {
			hostPort = net.JoinHostPort(u.Hostname(), "443")
		} else {
			hostPort = net.JoinHostPort(u.Hostname(), "80")
		}
	}
	raw, err := d.DialContext(ctx, "tcp", hostPort)
	if err != nil {
		return nil, err
	}
	var c net.Conn = raw
	if strings.EqualFold(u.Scheme, "https") {
		// https:// upstream means TLS to the proxy itself (was plain TCP before).
		tc := tls.Client(raw, &tls.Config{ServerName: u.Hostname(), MinVersion: tls.VersionTLS12})
		if err := tc.HandshakeContext(ctx); err != nil {
			raw.Close()
			return nil, fmt.Errorf("прокси: TLS: %w", err)
		}
		c = tc
	}
	_ = c.SetDeadline(time.Now().Add(15 * time.Second))
	req := "CONNECT " + addr + " HTTP/1.1\r\nHost: " + addr + "\r\n"
	if u.User != nil {
		req += "Proxy-Authorization: Basic " + basicAuth(u.User) + "\r\n"
	}
	req += "\r\n"
	if _, err := c.Write([]byte(req)); err != nil {
		c.Close()
		return nil, err
	}
	line, err := readLine(c)
	if err != nil {
		c.Close()
		return nil, err
	}
	if f := strings.Fields(line); len(f) < 2 || !strings.HasPrefix(f[0], "HTTP/") || f[1] != "200" {
		c.Close()
		return nil, fmt.Errorf("прокси: %s", strings.TrimSpace(line))
	}
	for {
		l, err := readLine(c)
		if err != nil {
			c.Close()
			return nil, err
		}
		if strings.TrimSpace(l) == "" {
			break
		}
	}
	_ = c.SetDeadline(time.Time{})
	return c, nil
}
