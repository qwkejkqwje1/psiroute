package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
)

// Config is persisted to psiroute.json next to the data directory. It is kept
// deliberately flat-ish so the UI can read and write individual keys by a
// dotted path ("psiphon.parallel", "desync.enabled", ...).
type Config struct {
	Psiphon struct {
		Parallel        int      `json:"parallel"` // tunnels tried in parallel (TunnelPoolSize)
		Standby         bool     `json:"standby"`  // keep a spare tunnel warm
		HealthIntervalS int      `json:"health_interval_secs"`
		MinSpeedKBps    int      `json:"min_speed_kbps"` // rotate if slower (0 = off)
		DPI             string   `json:"dpi"`            // "" std | off | hello | light | strong
		Country         string   `json:"country"`        // egress region, "" = auto
		Via             string   `json:"via"`            // auto | direct | warp | proxy
		Strategies      []string `json:"strategies"`     // enabled strategy ids, order = priority
	} `json:"psiphon"`
	Desync struct {
		Enabled bool `json:"enabled"` // split TLS ClientHello on direct connections
		Method  string `json:"method"` // auto | tlsrec | split | double | multirec | chunk
		TestSites []string `json:"test_sites"` // sites for the DPI test panel
	} `json:"desync"`
	Warp struct {
		Enabled  bool   `json:"enabled"`
		Engine   string `json:"engine"`   // builtin (in-process, the default) | socks (external)
		Socks    string `json:"socks"`    // external WARP SOCKS5, e.g. 127.0.0.1:18181
		Mask     string `json:"mask"`     // built-in: handshake masking auto | quic | bwg | dns | off
		Endpoint string `json:"endpoint"` // built-in: Cloudflare endpoint ip:port, "" = auto
	} `json:"warp"`
	Proxy struct {
		Enabled  bool   `json:"enabled"`
		Upstream string `json:"upstream"` // external upstream, e.g. socks5://127.0.0.1:1081 or http://...
	} `json:"proxy"`
	DNS struct {
		Enabled bool `json:"enabled"` // encrypted DNS (DoH) for name resolution
	} `json:"dns"`
	Routing struct {
		Mode     string   `json:"mode"`     // psiphon | rules | auto
		Failover bool     `json:"failover"` // fall back to Psiphon when a direct route fails
		Learn    bool     `json:"learn"`    // remember the working route per host
		Default  string   `json:"default"`  // default outbound in rules mode
		Rules    []Rule   `json:"rules"`
		Chain    []string `json:"auto_chain"` // outbound order tried in auto mode
	} `json:"routing"`
	UDP struct {
		Mode string `json:"mode"` // route | direct | psiphon | off
	} `json:"udp"`
	Share struct {
		Enabled  bool   `json:"enabled"`
		Port     int    `json:"port"`
		User     string `json:"user"`
		Password string `json:"password"`
		NoPwdLAN bool   `json:"no_password_in_lan"`
	} `json:"share"`
	General struct {
		WatchConfig bool   `json:"watch_config"` // reload psiroute.json when it changes
		SystemProxy bool   `json:"system_proxy"` // set the OS proxy to us on start
		Autostart   bool   `json:"autostart"`    // launch with the OS
		Listen      string `json:"listen"`       // proxy address, e.g. 127.0.0.1:1080
		UI          string `json:"ui"`           // web UI address, e.g. 127.0.0.1:9090
	} `json:"general"`
	Tun struct {
		Enabled bool     `json:"enabled"`
		MTU     int      `json:"mtu"`
		DNS     bool     `json:"dns_hijack"`
		IPv6    bool     `json:"ipv6"`
		Exclude []string `json:"exclude_apps"`
	} `json:"tun"`

	mu   sync.Mutex `json:"-"`
	path string     `json:"-"`
}

// Rule is one routing rule matched by host, keyword, CIDR, or port.
type Rule struct {
	Name     string   `json:"name"`
	Outbound string   `json:"outbound"`
	Domains  []string `json:"domains"`
	Keywords []string `json:"keywords"`
	CIDR     []string `json:"cidr"`
	Ports    []int    `json:"ports"`
	// Lists: preset names or trusted https URLs with domains / IPs / CIDRs,
	// downloaded and refreshed automatically (see lists.go).
	Lists []string `json:"lists,omitempty"`
	// Apps: program names (chrome.exe, Telegram) — the rule applies only to
	// connections from these programs. Empty: any program.
	Apps []string `json:"apps,omitempty"`
	// Always: also applied in the «psiphon» and «auto» modes, not only in
	// «rules» (a program that must always go direct, a game, a bank).
	Always bool `json:"always,omitempty"`
}

func defaultConfig() *Config {
	c := &Config{}
	c.Psiphon.Parallel = 2
	c.Psiphon.Standby = true
	c.Psiphon.HealthIntervalS = 30
	c.Psiphon.MinSpeedKBps = 0
	c.Psiphon.Via = "auto"
	c.Psiphon.Strategies = []string{"via-warp", "auto", "conduit", "meek", "tls", "ossh", "quic"}
	c.Desync.Enabled = true
	c.Desync.Method = "auto"
	c.Warp.Enabled = false
	c.Warp.Socks = "127.0.0.1:40000"
	c.Warp.Engine = "builtin"
	c.Warp.Mask = "auto"
	c.Proxy.Enabled = false
	c.DNS.Enabled = true
	c.UDP.Mode = "route"
	c.Routing.Mode = "psiphon"
	c.Routing.Failover = true
	c.Routing.Learn = true
	c.Routing.Default = "psiphon"
	c.Routing.Chain = []string{"direct", "direct-dpi", "psiphon"}
	c.Share.Port = 1081
	c.Share.User = "psiroute"
	c.Share.NoPwdLAN = false // public Wi-Fi is a "private" network too: password by default
	c.General.WatchConfig = true
	c.General.Listen = "127.0.0.1:1080"
	c.General.UI = "127.0.0.1:9090"
	c.Tun.MTU = 1500
	c.Tun.DNS = true
	c.Tun.IPv6 = true
	return c
}

// loadConfig reads psiroute.json, filling missing fields with defaults.
func loadConfig(path string) *Config {
	c := defaultConfig()
	c.path = path
	b, err := os.ReadFile(path)
	if err == nil {
		_ = json.Unmarshal(b, c) // keep defaults for anything absent
	}
	if c.Desync.Method == "" {
		c.Desync.Method = "auto"
	}
	if c.General.Listen == "" {
		c.General.Listen = "127.0.0.1:1080"
	}
	if c.General.UI == "" {
		c.General.UI = "127.0.0.1:9090"
	}
	return c
}

func (c *Config) save() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.path == "" {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(c.path), 0o700); err != nil {
		return err
	}
	b, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	tmp := c.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, c.path)
}

// values returns the flat key/value map the settings UI binds to.
func (c *Config) values() map[string]any {
	c.mu.Lock()
	defer c.mu.Unlock()
	return map[string]any{
		"psiphon.parallel":             c.Psiphon.Parallel,
		"psiphon.standby":              c.Psiphon.Standby,
		"psiphon.health_interval_secs": c.Psiphon.HealthIntervalS,
		"psiphon.min_speed_kbps":       c.Psiphon.MinSpeedKBps,
		"psiphon.dpi":                  c.Psiphon.DPI,
		"desync.enabled":               c.Desync.Enabled,
		"desync.method": c.Desync.Method,
		"warp.enabled":                 c.Warp.Enabled,
		"warp.socks":                   c.Warp.Socks, "warp.engine": c.Warp.Engine, "warp.mask": c.Warp.Mask, "warp.endpoint": c.Warp.Endpoint,
		"proxy.enabled":        c.Proxy.Enabled,
		"proxy.upstream":       c.Proxy.Upstream,
		"dns.enabled":          c.DNS.Enabled,
		"udp.mode":             c.UDP.Mode,
		"tun.enabled":          c.Tun.Enabled,
		"tun.mtu":              c.Tun.MTU,
		"tun.dns_hijack":       c.Tun.DNS,
		"tun.ipv6":             c.Tun.IPv6,
		"tun.exclude_apps":     strings.Join(c.Tun.Exclude, ", "),
		"routing.failover":     c.Routing.Failover,
		"routing.learn":        c.Routing.Learn,
		"general.watch_config": c.General.WatchConfig,
		"general.system_proxy": c.General.SystemProxy,
	}
}

// setKey updates one dotted key. It returns true when the change requires the
// Psiphon engine to restart to take effect.
func (c *Config) setKey(key string, v any) (restart bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	switch key {
	case "psiphon.parallel":
		c.Psiphon.Parallel = toInt(v)
		restart = true
	case "psiphon.standby":
		c.Psiphon.Standby = toBool(v)
		restart = true
	case "psiphon.health_interval_secs":
		c.Psiphon.HealthIntervalS = toInt(v)
	case "psiphon.min_speed_kbps":
		c.Psiphon.MinSpeedKBps = toInt(v)
	case "psiphon.dpi":
		c.Psiphon.DPI = toStr(v)
		restart = true
	case "desync.enabled":
		c.Desync.Enabled = toBool(v)
	case "desync.method":
		c.Desync.Method = "auto"
		if m := toStr(v); obfsByID(m) != nil {
			c.Desync.Method = m
		}
	case "warp.enabled":
		c.Warp.Enabled = toBool(v)
		if c.Warp.Enabled && !slices.Contains(c.Psiphon.Strategies, "via-warp") {
			// turning WARP on means Psiphon should go through it, first
			c.Psiphon.Strategies = append([]string{"via-warp"}, c.Psiphon.Strategies...)
		}
		restart = true
	case "warp.engine":
		c.Warp.Engine = toStr(v)
		restart = true
	case "warp.mask":
		c.Warp.Mask = toStr(v)
	case "warp.endpoint":
		c.Warp.Endpoint = strings.TrimSpace(toStr(v))
	case "warp.socks":
		c.Warp.Socks = toStr(v)
		restart = true
	case "proxy.enabled":
		c.Proxy.Enabled = toBool(v)
		restart = true
	case "proxy.upstream":
		c.Proxy.Upstream = toStr(v)
		restart = true
	case "dns.enabled":
		c.DNS.Enabled = toBool(v)
	case "udp.mode":
		switch m := toStr(v); m {
		case "route", "direct", "psiphon", "off":
			c.UDP.Mode = m
		}
	case "tun.enabled":
		c.Tun.Enabled = toBool(v)
	case "tun.mtu":
		if n := toInt(v); n >= 1280 && n <= 9000 {
			c.Tun.MTU = n
		}
	case "tun.dns_hijack":
		c.Tun.DNS = toBool(v)
	case "tun.ipv6":
		c.Tun.IPv6 = toBool(v)
	case "tun.exclude_apps":
		c.Tun.Exclude = tunSplitApps(toStr(v))
	case "routing.failover":
		c.Routing.Failover = toBool(v)
	case "routing.learn":
		c.Routing.Learn = toBool(v)
	case "general.watch_config":
		c.General.WatchConfig = toBool(v)
	case "general.system_proxy":
		c.General.SystemProxy = toBool(v)
	}
	return restart
}

func toInt(v any) int {
	switch x := v.(type) {
	case float64:
		return int(x)
	case int:
		return x
	case bool:
		if x {
			return 1
		}
	}
	return 0
}

func toBool(v any) bool {
	switch x := v.(type) {
	case bool:
		return x
	case float64:
		return x != 0
	}
	return false
}

func toStr(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}
