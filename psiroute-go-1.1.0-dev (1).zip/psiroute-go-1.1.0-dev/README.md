# Psiroute 1.0 (Go)

A lightweight Windows program for connecting to **Psiphon VPN** when Psiphon is blocked: DPI bypass, smart routing, traffic counter, a native window.

## Why Go instead of Rust
- **Psiphon runs inside the program.** tunnel-core is the official Psiphon library, written in Go. It is now linked straight into the exe, so there is no separate psiphon.exe, no local SOCKS port in between, and none of the timing problems that broke the old version.
- Full access to Psiphon's internal settings: the fragmentor, splitting the TLS ClientHello, protocol choice, upstream proxy, and changing the node by rotating the NetworkID.
- Builds as a single file with one command; the code base is shared with ProxyDesk.

## What was taken from ProxyDesk
- Psiphon started in-process (the ProxyDesk sidecar psi.go): server-list key, platform, settings.
- 5 DPI bypass modes for Psiphon (standard / TLS split only / light / strong / off).
- **Automatic bypass selection** (psidpi): 9 variants are tested in a separate process and ranked by speed.
- Connection strategies: via WARP, auto, Conduit (volunteer in-proxies), CDN (meek), TLS, OSSH/Shadowsocks, QUIC, via an external proxy. They are tried in order: 45 s each in the first round, then 90 and 180 s. A strategy is remembered only if its tunnels held for 3 minutes; one whose tunnels the network cuts within 2 minutes twice in a row goes to the end of the list for 6 hours.
- A tunnel pool (warm standby tunnels), health checks every N seconds, automatic node change when the connection drops or gets slow.
- Exit IP and country detection (cdn-cgi/trace), speed test, node history and per-country statistics.
- System proxy, autostart, per-program traffic attribution, WebView2 window, tray icon.

## Features
- One port `127.0.0.1:1080`: SOCKS5 + HTTP. Interface: `http://127.0.0.1:9090`.
- Routing modes: **everything through Psiphon** / **rules** / **auto** (direct → direct with DPI bypass → Psiphon). Failover goes to Psiphon. Learned sites: if a direct connection is reset by DPI, the site is sent through the bypass from then on.
- Our own DPI bypass for direct connections: the TLS record is split in the middle of the SNI (as in zapret/GoodbyeDPI).
- DNS over HTTPS (1.1.1.1) for direct connections, which protects against DNS spoofing.
- Site diagnostics: DNS (system vs DoH), and connect/TLS/first-byte/speed for each route.
- Traffic counter by program, site and route; history by day.
- LAN sharing (phone/TV) with a password and a QR code (including a Telegram link).

## Build (Windows, Go 1.26+)
```
go mod tidy
go build -ldflags "-H windowsgui -s -w" -o psiroute.exe .
```
The first `go mod tidy` needs internet access (it downloads tunnel-core). Builds for Linux/macOS work too: the program opens in the browser, and system proxy and autostart are Windows-only.

Flags: `--no-gui`, `--minimized` (tray icon only, used for autostart), `--config path`, `--selftest` (check everything and exit), `--no-watchdog` (no crash restarts), `--version`.

## Window, tray and memory
Since 1.0.6 the window is a separate process. Psiroute itself (Psiphon, WARP, the proxy) runs with a tray icon, and the window opens from the icon. The window is drawn by WebView2, the Edge engine built into Windows: 5–7 `msedgewebview2.exe` processes that take most of the memory (typically 100–150 MB). They exist only while the window is open: close the window and Psiroute keeps working in the tray with that memory freed. Quit from the tray menu (right click) or from Settings. The icon colour shows the state, its tooltip shows the exit country and the memory in use; the same figure, with details on hover, is at the bottom of the sidebar.

## Crashes, log and report
Since 1.0.7 psiroute.exe starts a small watchdog process, and the core (Psiphon, WARP, the proxy) runs under it. If the core crashes, the watchdog turns off the system proxy (if the crashed core had turned it on) and starts the core again, minimized to the tray. After 3 crashes within 10 minutes it stops restarting. The crash text goes to `crash.log`, and the next start shows its first line in the log. A panic in one connection, an API handler or a background task is caught and logged instead of killing the program. `--no-watchdog` turns the watchdog off; it is also off with `--no-gui` and `--pprof`.

The log is also written to `psiroute.log` (up to 1 MB, then rotated to `psiroute.log.1`). Settings → "Сохранить отчёт" saves a zip to Downloads with the logs, `crash.log`, the self-check result, the state and the settings. Passwords, tokens and keys are replaced with `***`, and the WARP key is never included.

## Self-check
Settings → "Самопроверка" or `psiroute.exe --selftest`. It checks the network, the internet directly and through the proxy, clock skew, UDP through the proxy and through Psiphon, the system proxy, autostart, WebView2, permissions and recent crashes. If Psiroute is already running, `--selftest` checks that instance. The result is also saved to `psiroute-selftest.txt`.

## Sleep and network changes
Psiroute notices when Windows wakes up and when the network changes (Wi-Fi to cable, another access point, a VPN). Psiphon reconnects at once instead of sitting on a dead tunnel, and the DoH cache is reset. With no network at all it waits instead of cycling through strategies.

## UDP
The SOCKS5 port supports UDP ASSOCIATE. Settings → "UDP через SOCKS5": by route (like TCP to the same address), everything through Psiphon, direct, or off. Through Psiphon, UDP goes over udpgw inside the tunnel. This only helps programs that send UDP through SOCKS5 themselves (Telegram calls with a proxy, Proxifier/ProxyCap, some games). Browsers and Discord don't, so they need a TUN mode.

## Per-program rules
A routing rule can list programs ("программы": `Telegram.exe`, `chrome`; no path, case and `.exe` don't matter). A rule marked "во всех режимах" also works in the "everything through Psiphon" and "auto" modes, ahead of learned sites.

## WARP
WARP is built in: Settings → WARP → "Cloudflare WARP как подложка". When it is on, the "via WARP" strategy goes first: Psiphon connects from inside a WireGuard tunnel to Cloudflare, so the provider sees WARP traffic instead of a Psiphon connection.

- A free WARP device is registered automatically (`warp-identity.json`).
- The handshake is masked: a signature packet I1 that looks like QUIC (HTTP/3) or a DNS query, plus junk packets ("Маскировка WARP": auto, QUIC, bash-warp-generator, DNS, off; auto tries them and remembers the one that works).
- Cloudflare nodes behind the Russian and Belarusian filters (DME, SVX, KJA, OVB, KZN, MSQ) are skipped.
- When the network cuts the UDP flow, the tunnel reconnects on a fresh one.

There is no extra program: the tunnel runs inside psiroute, starts only when Psiphon goes through WARP and closes after 10 minutes unused. An external WARP SOCKS5 still works ("Какой WARP" → внешний SOCKS5): warp-plus, Cloudflare WARP in proxy mode (port 40000) or ProxyDesk's WARP (127.0.0.1:18181).

## Files next to the exe
`psiroute.json` (settings, edits are picked up automatically), `psiphon/` (server database), `psiroute-learned.json`, `psiroute-days.json`, `warp-identity.json` (built-in WARP device), `psiroute.log` and `psiroute.log.1` (log), `crash.log` (last crash), `psiroute-selftest.txt` (last self-check).

## Important
Version 1.0.7 was built, vetted and tested in the development environment with tunnel-core and wireguard-go replaced by stubs (there is no internet there); the real modules come with `go mod tidy`. If `go build` reports errors, send them and they will be fixed quickly.

License: GPL-3.0 (psiphon-tunnel-core is distributed under GPL-3.0).

## Режим TUN

Обычно через Psiroute идут только программы, которые слушаются системного прокси или умеют SOCKS5. Режим TUN создаёт виртуальный сетевой адаптер **Psiroute** (Wintun), и через него идёт весь трафик: игры, голос Discord, лаунчеры.

- Включается в «Настройки → Режим TUN». Нужны права администратора: если их нет, появится кнопка «Перезапустить от администратора».
- Драйвер: `wintun.dll` рядом с `psiroute.exe`. Если его нет, Psiroute скачает официальный архив с wintun.net и проверит SHA-256. Без интернета — положите `wintun\bin\amd64\wintun.dll` вручную.
- Маршруты и DNS адаптера живут, пока работает Psiroute: при выходе или сбое адаптер исчезает, сеть сама возвращается к обычной.
- Правила маршрутизации те же: домен берётся из TLS SNI / HTTP Host, а если его нет — из нашего же ответа DNS. Программа определяется по сокету, правила «для программы» работают.
- «Исключения»: программы из списка всегда идут напрямую (банки, античиты).
- Ограничения: ping (ICMP) до внешних адресов не работает; адреса локальной сети (роутер, принтер) идут мимо TUN; собственные соединения Psiroute всегда идут через настоящий адаптер; IPv6 включается, только если у вас есть IPv6.

## Прокси для браузера

Psiroute — это обычный локальный прокси: **SOCKS5 и HTTP на `127.0.0.1:1080`** (если порт был занят, фактический адрес показан в «Сервисе»). Все значения есть в карточке «Прокси для браузера» и копируются одним нажатием.

- **Firefox:** Параметры сети → «Ручная настройка прокси» → Узел SOCKS `127.0.0.1`, порт `1080`, SOCKS 5, отметьте «Проксировать DNS-запросы при использовании SOCKS v5». Или «URL автоматической настройки прокси»: `http://127.0.0.1:9090/proxy.pac`.
- **Chrome / Edge / Яндекс / Opera** используют системный прокси (переключатель на главной). Только для браузера — кнопка «Открыть … через Psiroute» (отдельный профиль) или расширение ZeroOmega / SwitchyOmega с SOCKS5 `127.0.0.1:1080`.
- Вручную: `chrome.exe --proxy-server="socks5://127.0.0.1:1080" --host-resolver-rules="MAP * ~NOTFOUND , EXCLUDE 127.0.0.1"` (Chrome должен быть закрыт полностью).
- PAC-файл отправляет всё через SOCKS5 (с запасным HTTP), а адреса домашней сети — напрямую. Запасного «напрямую» для интернета нет специально: если Psiroute выключен, сайты не откроются, а не уйдут мимо.

## Обфускация и стабильность

Прямые подключения с DPI-обходом режут первые байты так, чтобы провайдер не увидел имя сайта. Содержимое TLS не меняется, меняется только нарезка.

| Метод | Что делает |
|---|---|
| две TLS-записи | ClientHello — две TLS-записи с разрезом внутри имени, каждая в своём TCP-сегменте |
| разрез TCP | одна запись, два TCP-сегмента (для серверов, не любящих дроблёный ClientHello) |
| TLS-записи + разрез TCP | две записи, заголовок второй уходит отдельным пакетом |
| много TLS-записей | 4–5 записей: до имени, на его начале, внутри и на конце |
| мелкие TCP-куски | заголовок и имя сайта кусками по 1–3 байта |

В режиме «Авто» рабочий метод запоминается для каждого сайта. Если до ответа сервера приходит сброс, закрытие или 6 секунд тишины, Psiroute сам открывает новое соединение следующим методом и повторяет ClientHello (до трёх методов). Браузер обрыва не видит. Если не помог ни один, сайт уходит в Psiphon, как раньше.

Для Psiphon есть режим обхода «авто»: дробление меняется между попытками подключения, сработавшее остаётся.

## Управление DPI

Страница «Обход DPI»:

- **Тест методов.** Каждый сайт из списка открывается без обхода и каждым методом по очереди: TCP, TLS, запрос и до 64 КБ ответа. Так видны сброс (RST), молчание, подмена сертификата и обрыв на ~16 КБ. Итог — лучший метод и сайты, которым нужен Psiphon.
- **Быстрое переключение:** «Выкл», «Авто» или один из пяти методов. Также на главной и клавишами Alt+0…6. Перезапуск не нужен.
- **Дробление для Psiphon** переключается там же (Psiphon переподключится).

API: `POST /api/dpi/test {"sites": [...]}`, `GET /api/dpi/test`, `POST /api/dpi/test/stop`, `POST /api/dpi/mode {"mode": "auto"}`.
