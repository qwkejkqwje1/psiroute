//go:build windows

package main

import (
	"encoding/binary"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/registry"
)

var (
	wininet                 = windows.NewLazySystemDLL("wininet.dll")
	procInternetSetOption   = wininet.NewProc("InternetSetOptionW")
	iphlpapi                = windows.NewLazySystemDLL("iphlpapi.dll")
	procGetExtendedTcpTable = iphlpapi.NewProc("GetExtendedTcpTable")
)

const (
	inetKey = `Software\Microsoft\Windows\CurrentVersion\Internet Settings`
	runKey  = `Software\Microsoft\Windows\CurrentVersion\Run`
)

const savedKey = `Software\Psiroute\SavedProxy`

// setSystemProxy points Windows (and every app that follows system settings)
// at the local proxy port. The user's previous proxy settings are saved on
// enable and restored on disable (they used to be overwritten and lost).
func setSystemProxy(addr string, on bool) error {
	k, err := registry.OpenKey(registry.CURRENT_USER, inetKey, registry.SET_VALUE|registry.QUERY_VALUE)
	if err != nil {
		return err
	}
	defer k.Close()
	if on {
		saveUserProxy(k, addr)
		if err := k.SetDWordValue("ProxyEnable", 1); err != nil {
			return err
		}
		_ = k.SetStringValue("ProxyServer", addr)
		_ = k.SetStringValue("ProxyOverride", "<local>;localhost;127.*;[::1];10.*;172.16.*;192.168.*")
	} else if !restoreUserProxy(k) {
		if err := k.SetDWordValue("ProxyEnable", 0); err != nil {
			return err
		}
	}
	procInternetSetOption.Call(0, 39, 0, 0) // INTERNET_OPTION_SETTINGS_CHANGED
	procInternetSetOption.Call(0, 37, 0, 0) // INTERNET_OPTION_REFRESH
	return nil
}

// saveUserProxy remembers the current settings unless they are already ours
// (or already saved), so repeated enables never save our own values.
func saveUserProxy(k registry.Key, ours string) {
	if sk, err := registry.OpenKey(registry.CURRENT_USER, savedKey, registry.QUERY_VALUE); err == nil {
		sk.Close()
		return
	}
	en, _, _ := k.GetIntegerValue("ProxyEnable")
	srv, _, _ := k.GetStringValue("ProxyServer")
	ov, _, _ := k.GetStringValue("ProxyOverride")
	if isOurProxy(srv, ours) {
		return
	}
	sk, _, err := registry.CreateKey(registry.CURRENT_USER, savedKey, registry.SET_VALUE)
	if err != nil {
		return
	}
	defer sk.Close()
	_ = sk.SetDWordValue("ProxyEnable", uint32(en))
	_ = sk.SetStringValue("ProxyServer", srv)
	_ = sk.SetStringValue("ProxyOverride", ov)
}

func restoreUserProxy(k registry.Key) bool {
	sk, err := registry.OpenKey(registry.CURRENT_USER, savedKey, registry.QUERY_VALUE)
	if err != nil {
		return false
	}
	en, _, _ := sk.GetIntegerValue("ProxyEnable")
	srv, _, _ := sk.GetStringValue("ProxyServer")
	ov, _, _ := sk.GetStringValue("ProxyOverride")
	sk.Close()
	_ = k.SetDWordValue("ProxyEnable", uint32(en))
	if srv == "" {
		_ = k.DeleteValue("ProxyServer")
	} else {
		_ = k.SetStringValue("ProxyServer", srv)
	}
	if ov == "" {
		_ = k.DeleteValue("ProxyOverride")
	} else {
		_ = k.SetStringValue("ProxyOverride", ov)
	}
	_ = registry.DeleteKey(registry.CURRENT_USER, savedKey)
	return true
}

// isOurProxy reports whether a ProxyServer value points at one of our addrs.
func isOurProxy(srv string, ours ...string) bool {
	for _, o := range ours {
		if o != "" && (srv == o || strings.Contains(srv, "="+o)) {
			return true
		}
	}
	return false
}

// systemProxyOwnedBy reports an enabled system proxy pointing at us.
func systemProxyOwnedBy(addrs ...string) bool {
	k, err := registry.OpenKey(registry.CURRENT_USER, inetKey, registry.QUERY_VALUE)
	if err != nil {
		return false
	}
	defer k.Close()
	en, _, _ := k.GetIntegerValue("ProxyEnable")
	srv, _, _ := k.GetStringValue("ProxyServer")
	return en == 1 && isOurProxy(srv, addrs...)
}

func autostartEnabled() bool {
	k, err := registry.OpenKey(registry.CURRENT_USER, runKey, registry.QUERY_VALUE)
	if err != nil {
		return false
	}
	defer k.Close()
	_, _, err = k.GetStringValue("Psiroute")
	return err == nil
}

func setAutostart(on bool) error {
	k, err := registry.OpenKey(registry.CURRENT_USER, runKey, registry.SET_VALUE)
	if err != nil {
		return err
	}
	defer k.Close()
	if on {
		exe, err := os.Executable()
		if err != nil {
			return err
		}
		return k.SetStringValue("Psiroute", "\""+exe+"\" --minimized")
	}
	if err := k.DeleteValue("Psiroute"); err != nil && err != registry.ErrNotExist {
		return err
	}
	return nil
}

func hideConsole(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000} // CREATE_NO_WINDOW
}

type pidName struct {
	name string
	exp  time.Time
}

var pidNames sync.Map // uint32 -> pidName; entries expire, PIDs get reused

// appForConn finds which program opened a local connection (by its source
// port in the TCP table). LAN-share clients are shown by IP.
func appForConn(remote net.Addr) string {
	ta, ok := remote.(*net.TCPAddr)
	if !ok {
		return ""
	}
	if !ta.IP.IsLoopback() {
		return ta.IP.String()
	}
	if ta.IP.To4() == nil {
		return "" // IPv6 loopback: the IPv4 table does not have it
	}
	pid := pidForPort(ta.Port)
	if pid == 0 {
		return ""
	}
	if v, ok := pidNames.Load(pid); ok && time.Now().Before(v.(pidName).exp) {
		return v.(pidName).name
	}
	name := procName(pid)
	pidNames.Store(pid, pidName{name, time.Now().Add(time.Minute)})
	return name
}

// The TCP table is fetched at most every 500 ms and shared by all new
// connections (it was fetched once per connection before).
var tcpTab struct {
	mu   sync.Mutex
	at   time.Time
	map_ map[int]uint32
}

func pidForPort(port int) uint32 {
	tcpTab.mu.Lock()
	defer tcpTab.mu.Unlock()
	if pid, ok := tcpTab.map_[port]; ok && time.Since(tcpTab.at) < 500*time.Millisecond {
		return pid
	}
	tcpTab.map_ = loadTCPTable()
	tcpTab.at = time.Now()
	return tcpTab.map_[port]
}

func loadTCPTable() map[int]uint32 {
	m := map[int]uint32{}
	var size uint32
	procGetExtendedTcpTable.Call(0, uintptr(unsafe.Pointer(&size)), 0, 2, 5, 0) // AF_INET, TCP_TABLE_OWNER_PID_ALL
	if size == 0 {
		return m
	}
	buf := make([]byte, size+4096)
	size = uint32(len(buf))
	r, _, _ := procGetExtendedTcpTable.Call(uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&size)), 0, 2, 5, 0)
	if r != 0 {
		return m
	}
	n := int(binary.LittleEndian.Uint32(buf[0:4]))
	for i := 0; i < n; i++ {
		off := 4 + i*24 // MIB_TCPROW_OWNER_PID
		if off+24 > len(buf) {
			break
		}
		lp := int(buf[off+8])<<8 | int(buf[off+9])
		m[lp] = binary.LittleEndian.Uint32(buf[off+20:])
	}
	return m
}

func procName(pid uint32) string {
	h, err := windows.OpenProcess(windows.PROCESS_QUERY_LIMITED_INFORMATION, false, pid)
	if err != nil {
		return ""
	}
	defer windows.CloseHandle(h)
	buf := make([]uint16, 1024)
	n := uint32(len(buf))
	if err := windows.QueryFullProcessImageName(h, 0, &buf[0], &n); err != nil {
		return ""
	}
	return filepath.Base(windows.UTF16ToString(buf[:n]))
}
