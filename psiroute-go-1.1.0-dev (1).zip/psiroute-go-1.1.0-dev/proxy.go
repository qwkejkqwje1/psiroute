package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/subtle"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// One local port speaks both SOCKS5 and HTTP (CONNECT and plain requests).
// The same handler serves the LAN share port, with authentication.

func readFull(c net.Conn, b []byte) (int, error) { return io.ReadFull(c, b) }

// readLine reads one line byte by byte so nothing after it is consumed.
func readLine(c net.Conn) (string, error) {
	var sb []byte
	one := make([]byte, 1)
	for len(sb) < 8192 {
		if _, err := c.Read(one); err != nil {
			return string(sb), err
		}
		sb = append(sb, one[0])
		if one[0] == '\n' {
			return string(sb), nil
		}
	}
	return string(sb), errors.New("слишком длинная строка")
}

func atoiSafe(s string) int {
	n, _ := strconv.Atoi(s)
	return n
}

func basicAuth(u *url.Userinfo) string {
	p, _ := u.Password()
	return base64.StdEncoding.EncodeToString([]byte(u.Username() + ":" + p))
}

type proxyAuth struct {
	user, pass string
	lanFree    bool
}

func isPrivateAddr(a net.Addr) bool {
	ta, ok := a.(*net.TCPAddr)
	if !ok {
		return false
	}
	return ta.IP.IsLoopback() || ta.IP.IsPrivate() || ta.IP.IsLinkLocalUnicast()
}

func (s *Stats) setSNI(t *tracked, sni string) {
	s.mu.Lock()
	t.sni = sni
	s.mu.Unlock()
}

func (s *Stats) getSNI(t *tracked) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return t.sni
}

func (a *App) serveProxy(ln net.Listener, auth *proxyAuth) {
	for {
		c, err := ln.Accept()
		if err != nil {
			if a.ctx.Err() != nil || errors.Is(err, net.ErrClosed) {
				return
			}
			time.Sleep(100 * time.Millisecond)
			continue
		}
		go a.handleConn(c, auth)
	}
}

func (a *App) handleConn(c net.Conn, auth *proxyAuth) {
	defer c.Close()
	defer recoverLog("соединение прокси")
	_ = c.SetReadDeadline(time.Now().Add(30 * time.Second))
	br := bufio.NewReader(c)
	first, err := br.Peek(1)
	if err != nil {
		return
	}
	needAuth := auth != nil && !(auth.lanFree && isPrivateAddr(c.RemoteAddr()))
	if first[0] == 5 {
		host, port, cmd, err := socksHandshake(c, br, needAuth, auth)
		if err != nil {
			return
		}
		if cmd == 3 {
			a.udpAssociate(c, br)
			return
		}
		a.tunnel(c, br, host, port, func(up net.Conn, err error) error {
			if err != nil {
				_, _ = c.Write([]byte{5, socksErrCode(err), 0, 1, 0, 0, 0, 0, 0, 0})
				return err
			}
			_, werr := c.Write([]byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0})
			return werr
		})
		return
	}
	req, err := http.ReadRequest(br)
	if err != nil {
		return
	}
	if needAuth {
		want := "Basic " + base64.StdEncoding.EncodeToString([]byte(auth.user+":"+auth.pass))
		if !eqConst(req.Header.Get("Proxy-Authorization"), want) {
			_, _ = io.WriteString(c, "HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: Basic realm=\"psiroute\"\r\nContent-Length: 0\r\n\r\n")
			return
		}
	}
	req.Header.Del("Proxy-Authorization")
	req.Header.Del("Proxy-Connection")
	if req.Method == http.MethodConnect {
		host, portStr, err := net.SplitHostPort(req.Host)
		if err != nil {
			host, portStr = req.Host, "443"
		}
		a.tunnel(c, br, host, atoiSafe(portStr), func(up net.Conn, err error) error {
			if err != nil {
				if errors.Is(err, errBlocked) {
					_, _ = io.WriteString(c, "HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
					return err
				}
				_, _ = io.WriteString(c, "HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
				return err
			}
			_, werr := io.WriteString(c, "HTTP/1.1 200 Connection established\r\n\r\n")
			return werr
		})
		return
	}
	if req.URL.Host == "" {
		_, _ = io.WriteString(c, "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 0\r\n\r\n")
		return
	}
	host := req.URL.Hostname()
	port := atoiSafe(req.URL.Port())
	if port == 0 {
		port = 80
	}
	// Only this request is routed, so it must be the last one on the client
	// connection: with keep-alive the next request (maybe to another host)
	// would be relayed raw to this upstream.
	req.Close = true
	req.Header.Set("Connection", "close")
	a.tunnel(c, br, host, port, func(up net.Conn, err error) error {
		if err != nil {
			if errors.Is(err, errBlocked) {
				_, _ = io.WriteString(c, "HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
				return err
			}
			_, _ = io.WriteString(c, "HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
			return err
		}
		return req.Write(up)
	})
}

func socksHandshake(c net.Conn, br *bufio.Reader, needAuth bool, auth *proxyAuth) (string, int, byte, error) {
	h := make([]byte, 2)
	if _, err := io.ReadFull(br, h); err != nil {
		return "", 0, 0, err
	}
	methods := make([]byte, h[1])
	if _, err := io.ReadFull(br, methods); err != nil {
		return "", 0, 0, err
	}
	want := byte(0)
	if needAuth {
		want = 2
	}
	if !bytes.Contains(methods, []byte{want}) {
		_, _ = c.Write([]byte{5, 0xff})
		return "", 0, 0, errors.New("socks: нет подходящего метода")
	}
	if _, err := c.Write([]byte{5, want}); err != nil {
		return "", 0, 0, err
	}
	if needAuth {
		v := make([]byte, 2)
		if _, err := io.ReadFull(br, v); err != nil {
			return "", 0, 0, err
		}
		u := make([]byte, v[1])
		if _, err := io.ReadFull(br, u); err != nil {
			return "", 0, 0, err
		}
		pl := make([]byte, 1)
		if _, err := io.ReadFull(br, pl); err != nil {
			return "", 0, 0, err
		}
		p := make([]byte, pl[0])
		if _, err := io.ReadFull(br, p); err != nil {
			return "", 0, 0, err
		}
		if okU, okP := eqConst(string(u), auth.user), eqConst(string(p), auth.pass); !okU || !okP {
			_, _ = c.Write([]byte{1, 1})
			return "", 0, 0, errors.New("socks: неверный пароль")
		}
		if _, err := c.Write([]byte{1, 0}); err != nil {
			return "", 0, 0, err
		}
	}
	req := make([]byte, 4)
	if _, err := io.ReadFull(br, req); err != nil {
		return "", 0, 0, err
	}
	if req[1] != 1 && req[1] != 3 { // CONNECT, UDP ASSOCIATE
		_, _ = c.Write([]byte{5, 7, 0, 1, 0, 0, 0, 0, 0, 0})
		return "", 0, 0, errors.New("socks: поддерживаются CONNECT и UDP ASSOCIATE")
	}
	var host string
	switch req[3] {
	case 1:
		b := make([]byte, 4)
		if _, err := io.ReadFull(br, b); err != nil {
			return "", 0, 0, err
		}
		host = net.IP(b).String()
	case 3:
		l := make([]byte, 1)
		if _, err := io.ReadFull(br, l); err != nil {
			return "", 0, 0, err
		}
		b := make([]byte, l[0])
		if _, err := io.ReadFull(br, b); err != nil {
			return "", 0, 0, err
		}
		host = string(b)
	case 4:
		b := make([]byte, 16)
		if _, err := io.ReadFull(br, b); err != nil {
			return "", 0, 0, err
		}
		host = net.IP(b).String()
	default:
		return "", 0, 0, errors.New("socks: неизвестный тип адреса")
	}
	pb := make([]byte, 2)
	if _, err := io.ReadFull(br, pb); err != nil {
		return "", 0, 0, err
	}
	return host, int(pb[0])<<8 | int(pb[1]), req[1], nil
}

// socksErrCode maps a dial error to a SOCKS5 reply code (RFC 1928).
func socksErrCode(err error) byte {
	switch {
	case errors.Is(err, errBlocked):
		return 2 // connection not allowed by ruleset
	case isTimeout(err):
		return 4 // host unreachable
	case errors.Is(err, syscall.ECONNREFUSED):
		return 5
	case strings.Contains(err.Error(), "no such host"), strings.Contains(err.Error(), "DNS"):
		return 4
	}
	return 1 // general failure
}

// directAddrs resolves a host for direct outbounds, through DoH when enabled.
// It returns up to 3 addresses so a dead first IP does not fail the site.
func (a *App) directAddrs(ctx context.Context, host string, port int) ([]string, error) {
	a.cfg.mu.Lock()
	doh := a.cfg.DNS.Enabled
	a.cfg.mu.Unlock()
	ips, err := resolve(ctx, host, doh)
	if err != nil {
		return nil, err
	}
	if len(ips) == 0 {
		return nil, fmt.Errorf("DNS: нет адресов для %s", host)
	}
	if len(ips) > 3 {
		ips = ips[:3]
	}
	out := make([]string, len(ips))
	for i, ip := range ips {
		out[i] = net.JoinHostPort(ip, strconv.Itoa(port))
	}
	return out, nil
}

// tunnel dials the destination using the router plan and relays data.
func (a *App) tunnel(c net.Conn, br *bufio.Reader, host string, port int, reply func(up net.Conn, err error) error) {
	a.tunnelApp(c, br, host, port, appForConn(c.RemoteAddr()), reply)
}

func (a *App) tunnelApp(c net.Conn, br *bufio.Reader, host string, port int, app string, reply func(up net.Conn, err error) error) {
	a.tunnelAppAddr(c, br, host, "", port, app, reply)
}

func (a *App) tunnelAppAddr(c net.Conn, br *bufio.Reader, host, dstIP string, port int, app string, reply func(up net.Conn, err error) error) {
	order, rule := a.router.planForIP(host, dstIP, port, app)
	ctx, cancel := context.WithTimeout(a.ctx, 30*time.Second)
	var up net.Conn
	var ob string
	var lastErr error
	var resolved []string // resolved once, shared by direct and direct-dpi
	var resolveErr error
	for i, o := range order {
		if o == obBlock {
			lastErr = errBlocked
			break
		}
		addrs := []string{net.JoinHostPort(host, strconv.Itoa(port))}
		if o == obDirect || o == obDesync {
			if resolved == nil && resolveErr == nil {
				resolved, resolveErr = a.directAddrs(ctx, host, port)
				if resolveErr != nil && dstIP != "" {
					resolved, resolveErr = []string{net.JoinHostPort(dstIP, strconv.Itoa(port))}, nil
				}
			}
			if resolveErr != nil {
				lastErr = resolveErr
				continue
			}
			addrs = resolved
		}
		dctx := ctx
		var dcancel context.CancelFunc = func() {}
		if i < len(order)-1 && o != obPsiphon {
			dctx, dcancel = context.WithTimeout(ctx, 7*time.Second)
		}
		dial := a.router.dialer(o)
		for _, addr := range addrs {
			up, lastErr = dial(dctx, "tcp", addr)
			if lastErr == nil || dctx.Err() != nil {
				break
			}
		}
		dcancel()
		if lastErr == nil {
			ob = o
			break
		}
	}
	cancel()
	if up == nil {
		last := order[len(order)-1]
		t := a.stats.open(app, host, "", port, last, rule)
		if lastErr == nil {
			lastErr = errors.New("нет маршрута")
		}
		a.stats.close(t, lastErr)
		_ = reply(nil, lastErr)
		return
	}
	if ob != order[0] {
		rule = "запасной (" + order[0] + " не ответил)"
		a.router.remember(host, ob, order[0]+" не подключился", true)
	}
	t := a.stats.open(app, host, "", port, ob, rule)
	cc := &countConn{Conn: up, s: a.stats, t: t}
	defer up.Close()
	if err := reply(cc, nil); err != nil {
		a.stats.close(t, err)
		return
	}
	_ = c.SetReadDeadline(time.Time{})
	started := time.Now()
	err, clientFirst := a.relay(c, br, cc, t)
	a.stats.close(t, err)
	// A direct TLS connection that sent data, got nothing back and was killed
	// by the network (reset, or the server side went silent and closed first)
	// is the classic DPI pattern. A client that simply gave up (preconnect,
	// closed tab) is NOT a block: that used to teach wrong routes.
	blocked := isConnReset(err) || (!clientFirst && err == nil)
	if (ob == obDirect || ob == obDesync) && port == 443 && blocked && t.down.Load() == 0 && t.up.Load() > 0 && time.Since(started) < 20*time.Second {
		next := obPsiphon
		if ob == obDirect {
			a.cfg.mu.Lock()
			if a.cfg.Desync.Enabled {
				next = obDesync
			}
			a.cfg.mu.Unlock()
		}
		reason := fmt.Sprintf("%s: сброс соединения (DPI)", ob)
		a.router.remember(host, next, reason, true)
		if sni := a.stats.getSNI(t); sni != "" && sni != host {
			a.router.remember(sni, next, reason, true)
		}
		logf("warn", "%s: похоже на блокировку через %s, дальше — %s", host, ob, next)
	}
}

// relay copies both directions. clientFirst is true when the client side
// finished first (it closed or failed before the upstream did).
func (a *App) relay(c net.Conn, br *bufio.Reader, up net.Conn, t *tracked) (error, bool) {
	type res struct {
		client bool
		err    error
	}
	errc := make(chan res, 2)
	go func() {
		buf := make([]byte, 32<<10)
		first := true
		for {
			n, err := br.Read(buf)
			if n > 0 {
				if first {
					first = false
					if s := parseSNI(buf[:n]); s != "" {
						a.stats.setSNI(t, s)
					}
				}
				if _, werr := up.Write(buf[:n]); werr != nil {
					errc <- res{false, werr} // the upstream failed
					return
				}
			}
			if err != nil {
				if err == io.EOF {
					err = nil
				}
				errc <- res{true, err}
				return
			}
		}
	}()
	go func() {
		_, err := io.Copy(c, up)
		errc <- res{false, err}
	}()
	r1 := <-errc
	// Half-close the other side so request/response protocols finish fast,
	// then give the remaining direction a short grace period.
	if r1.client {
		if cw, ok := up.(interface{ CloseWrite() error }); ok {
			_ = cw.CloseWrite()
		}
	} else if cw, ok := c.(interface{ CloseWrite() error }); ok {
		_ = cw.CloseWrite()
	}
	_ = c.SetDeadline(time.Now().Add(5 * time.Second))
	_ = up.SetDeadline(time.Now().Add(5 * time.Second))
	r2 := <-errc
	for _, r := range []res{r1, r2} {
		if r.err != nil && !errors.Is(r.err, net.ErrClosed) && !isTimeout(r.err) {
			return r.err, r1.client
		}
	}
	return nil, r1.client
}

func isTimeout(err error) bool {
	var ne net.Error
	return errors.As(err, &ne) && ne.Timeout()
}

// isConnReset reports a TCP reset / abort, the typical DPI injection.
func isConnReset(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, syscall.ECONNRESET) || errors.Is(err, syscall.ECONNABORTED) {
		return true
	}
	// Windows: WSAECONNRESET (10054) / WSAECONNABORTED (10053) are not
	// always mapped to the POSIX errno values above.
	var en syscall.Errno
	if errors.As(err, &en) && (en == 10054 || en == 10053) {
		return true
	}
	return false
}

// eqConst compares secrets in constant time.
func eqConst(a, b string) bool {
	return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}
