//go:build windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"unsafe"

	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/registry"

	webview2 "github.com/jchv/go-webview2"
)

// windowTitle also identifies the window: the core finds it by its title to
// bring it to the front and to close it on exit.
const windowTitle = "Psiroute — Psiphon VPN"

// lightWebView: Chromium switches for the window's WebView2. No spare
// renderer kept warm for navigations that never come, one renderer for the
// single local page, no SmartScreen checks or component downloads for
// 127.0.0.1. Chromium ignores switches it does not know.
const lightWebView = "--disable-features=msSmartScreenProtection,SpareRendererForSitePerProcess " +
	"--renderer-process-limit=1 --disable-background-networking --disable-component-update"

// runWindowProcess is the "psiroute --window" process: the WebView2 window
// (built into Windows 10/11) and nothing else. It ends when the window is
// closed or when the core (parentPID) exits. Without WebView2 it opens the
// UI in the default browser and exits with exitNoWebView.
func runWindowProcess(dataDir, url string, parentPID int) {
	if h := findAppWindow(); h != 0 {
		focusWindow(h) // already open
		return
	}
	setEnvDefault("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", lightWebView)
	bg := "FFF9F8F7"
	if systemDark() {
		bg = "FF191919"
	}
	setEnvDefault("WEBVIEW2_DEFAULT_BACKGROUND_COLOR", bg) // no white flash before the page
	w := webview2.NewWithOptions(webview2.WebViewOptions{
		Debug:     false,
		AutoFocus: true,
		DataPath:  filepath.Join(dataDir, "webview"),
		WindowOptions: webview2.WindowOptions{
			Title:  windowTitle,
			Width:  1180,
			Height: 780,
			Center: true,
		},
	})
	if w == nil {
		openBrowser(url)
		os.Exit(exitNoWebView)
	}
	setWindowIcon()
	if parentPID > 0 {
		if p, err := os.FindProcess(parentPID); err == nil {
			go func() {
				_, _ = p.Wait() // the core is gone (crash, kill): no window without it
				w.Dispatch(func() { w.Terminate() })
			}()
		}
	}
	w.Navigate(url)
	w.Run()
	w.Destroy()
}

func setEnvDefault(k, v string) {
	if os.Getenv(k) == "" {
		_ = os.Setenv(k, v)
	}
}

// systemDark: Windows apps use the dark theme (the UI follows the system
// unless a theme was picked in it).
func systemDark() bool {
	k, err := registry.OpenKey(registry.CURRENT_USER, `Software\Microsoft\Windows\CurrentVersion\Themes\Personalize`, registry.QUERY_VALUE)
	if err != nil {
		return true
	}
	defer k.Close()
	v, _, err := k.GetIntegerValue("AppsUseLightTheme")
	return err != nil || v == 0
}

func openBrowser(url string) {
	_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
}

var procMessageBox = windows.NewLazySystemDLL("user32.dll").NewProc("MessageBoxW")

// showFatal shows a startup error: the GUI build has no console to print to.
func showFatal(msg string) {
	t, _ := windows.UTF16PtrFromString("Psiroute")
	m, _ := windows.UTF16PtrFromString(msg)
	procMessageBox.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), 0x10) // MB_ICONERROR
}
