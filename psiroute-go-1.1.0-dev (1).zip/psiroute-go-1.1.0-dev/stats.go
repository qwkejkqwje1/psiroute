package main

import (
	"encoding/json"
	"net"
	"os"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

// tracked is one proxied connection, live or recently closed.
type tracked struct {
	id       int64
	app      string
	host     string
	sni      string
	key      string // byHost key fixed at open, so open/close hit one entry
	port     int
	outbound string
	rule     string
	err      string
	start    time.Time
	end      time.Time
	up       atomic.Int64
	down     atomic.Int64
}

func (t *tracked) view() map[string]any {
	end := t.end
	if end.IsZero() {
		end = time.Now()
	}
	m := map[string]any{
		"id": t.id, "app": t.app, "host": t.host, "sni": t.sni, "port": t.port,
		"outbound": t.outbound, "rule": t.rule, "up": t.up.Load(), "down": t.down.Load(),
		"age": int64(end.Sub(t.start).Seconds()),
	}
	if t.err != "" {
		m["error"] = t.err
	}
	return m
}

type agg struct {
	conns    int
	up, down int64
	outbound string
}

// Stats counts traffic per connection, outbound, application, host and day.
type Stats struct {
	mu       sync.Mutex
	nextID   int64
	live     map[int64]*tracked
	closed   []*tracked
	byOb     map[string]*agg
	byApp    map[string]*agg
	byHost   map[string]*agg
	totUp    atomic.Int64
	totDown  atomic.Int64
	lastUp   int64
	lastDown int64
	spUp     int64
	spDown   int64
	hist     [][2]int64
	days     map[string]*[2]int64
	dayFile  string
	ticks    int
}

func newStats(dayFile string) *Stats {
	s := &Stats{live: map[int64]*tracked{}, byOb: map[string]*agg{}, byApp: map[string]*agg{},
		byHost: map[string]*agg{}, days: map[string]*[2]int64{}, dayFile: dayFile}
	if b, err := os.ReadFile(dayFile); err == nil {
		var d map[string][2]int64
		if json.Unmarshal(b, &d) == nil {
			for k, v := range d {
				v := v
				s.days[k] = &v
			}
		}
	}
	return s
}

func bump(m map[string]*agg, k string, conns int, up, down int64) *agg {
	if k == "" {
		k = "—"
	}
	a := m[k]
	if a == nil {
		a = &agg{}
		m[k] = a
	}
	a.conns += conns
	a.up += up
	a.down += down
	return a
}

func (s *Stats) open(app, host, sni string, port int, outbound, rule string) *tracked {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.nextID++
	t := &tracked{id: s.nextID, app: app, host: host, sni: sni, port: port, outbound: outbound, rule: rule, start: time.Now()}
	s.live[t.id] = t
	bump(s.byOb, outbound, 1, 0, 0)
	bump(s.byApp, app, 1, 0, 0)
	t.key = displayHost(t)
	if len(s.byHost) > 5000 { // long sessions: do not grow without bound
		s.byHost = map[string]*agg{}
	}
	bump(s.byHost, t.key, 1, 0, 0).outbound = outbound
	return t
}

func displayHost(t *tracked) string {
	if t.sni != "" {
		return t.sni
	}
	return t.host
}

func (s *Stats) close(t *tracked, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.live[t.id]; !ok {
		return
	}
	delete(s.live, t.id)
	t.end = time.Now()
	if err != nil {
		t.err = short(err.Error(), 160)
	}
	up, down := t.up.Load(), t.down.Load()
	bump(s.byOb, t.outbound, 0, up, down)
	bump(s.byApp, t.app, 0, up, down)
	bump(s.byHost, t.key, 0, up, down)
	s.closed = append(s.closed, t)
	if len(s.closed) > 300 {
		s.closed = s.closed[len(s.closed)-300:]
	}
}

func (s *Stats) add(t *tracked, up, down int64) {
	if up > 0 {
		t.up.Add(up)
		s.totUp.Add(up)
	}
	if down > 0 {
		t.down.Add(down)
		s.totDown.Add(down)
	}
}

// tick runs once a second: speed, speed history, per-day totals.
func (s *Stats) tick() {
	up, down := s.totUp.Load(), s.totDown.Load()
	s.mu.Lock()
	s.spUp, s.spDown = up-s.lastUp, down-s.lastDown
	s.lastUp, s.lastDown = up, down
	s.hist = append(s.hist, [2]int64{s.spUp, s.spDown})
	if len(s.hist) > 120 {
		s.hist = s.hist[len(s.hist)-120:]
	}
	day := time.Now().Format("2006-01-02")
	d := s.days[day]
	if d == nil {
		d = &[2]int64{}
		s.days[day] = d
	}
	d[0] += s.spUp
	d[1] += s.spDown
	s.ticks++
	save := s.ticks%30 == 0
	var snap map[string][2]int64
	if save {
		snap = map[string][2]int64{}
		for k, v := range s.days {
			snap[k] = *v
		}
	}
	s.mu.Unlock()
	if save && s.dayFile != "" {
		if b, err := json.Marshal(snap); err == nil {
			_ = os.WriteFile(s.dayFile, b, 0o600)
		}
	}
}

func aggList(m map[string]*agg, key string, live map[string]int64) []map[string]any {
	out := make([]map[string]any, 0, len(m))
	for k, a := range m {
		x := map[string]any{key: k, "conns": a.conns, "up": a.up + live[k+"\x00u"], "down": a.down + live[k+"\x00d"]}
		if a.outbound != "" {
			x["outbound"] = a.outbound
		}
		out = append(out, x)
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i]["up"].(int64)+out[i]["down"].(int64) > out[j]["up"].(int64)+out[j]["down"].(int64)
	})
	return out
}

// snapshot is the "stats" object of /api/state.
func (s *Stats) snapshot() map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	liveOb, liveApp, liveHost := map[string]int64{}, map[string]int64{}, map[string]int64{}
	live := make([]map[string]any, 0, len(s.live))
	for _, t := range s.live {
		u, d := t.up.Load(), t.down.Load()
		for _, p := range []struct {
			m map[string]int64
			k string
		}{{liveOb, t.outbound}, {liveApp, t.app}, {liveHost, displayHost(t)}} {
			k := p.k
			if k == "" {
				k = "—"
			}
			p.m[k+"\x00u"] += u
			p.m[k+"\x00d"] += d
		}
		live = append(live, t.view())
	}
	sort.Slice(live, func(i, j int) bool { return live[i]["id"].(int64) > live[j]["id"].(int64) })
	closed := make([]map[string]any, 0, len(s.closed))
	for i := len(s.closed) - 1; i >= 0; i-- {
		closed = append(closed, s.closed[i].view())
	}
	hist := make([][2]int64, len(s.hist))
	copy(hist, s.hist)
	return map[string]any{
		"total":     map[string]any{"up": s.totUp.Load(), "down": s.totDown.Load(), "live": len(s.live)},
		"speed":     map[string]any{"up": s.spUp, "down": s.spDown, "history": hist},
		"outbounds": aggList(s.byOb, "outbound", liveOb),
		"apps":      aggList(s.byApp, "app", liveApp),
		"hosts":     aggList(s.byHost, "host", liveHost),
		"live":      live,
		"closed":    closed,
	}
}

// history is per-day totals, newest first.
func (s *Stats) history() []map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]map[string]any, 0, len(s.days))
	for k, v := range s.days {
		out = append(out, map[string]any{"date": k, "total": map[string]any{"up": v[0], "down": v[1]}})
	}
	sort.Slice(out, func(i, j int) bool { return out[i]["date"].(string) > out[j]["date"].(string) })
	if len(out) > 30 {
		out = out[:30]
	}
	return out
}

// countConn counts bytes of a proxied connection.
type countConn struct {
	net.Conn
	s *Stats
	t *tracked
}

func (c *countConn) Read(b []byte) (int, error) {
	n, err := c.Conn.Read(b)
	c.s.add(c.t, 0, int64(n))
	return n, err
}

func (c *countConn) Write(b []byte) (int, error) {
	n, err := c.Conn.Write(b)
	c.s.add(c.t, int64(n), 0)
	return n, err
}
