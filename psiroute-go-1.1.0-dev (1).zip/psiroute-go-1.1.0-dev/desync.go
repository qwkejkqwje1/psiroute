package main

import (
	"context"
	"net"
	"time"
)

// Direct connections with "DPI bypass" (outbound direct-dpi) work like
// zapret's tlsrec + split: the TLS ClientHello is cut into two TLS records
// right inside the SNI and each record goes out in its own TCP segment, so a
// DPI box that inspects only the first packet never sees the whole host name.
// More methods, their automatic choice and resends are in obfs.go.

// findSNI returns the offset of the server name inside a ClientHello
// handshake body (the bytes after the 5-byte record header), or -1.
func findSNI(body []byte) (int, int) {
	p := 4 + 2 + 32 // handshake header, version, random
	if len(body) < p+1 || body[0] != 0x01 {
		return -1, 0
	}
	p += 1 + int(body[p]) // session id
	if len(body) < p+2 {
		return -1, 0
	}
	p += 2 + (int(body[p])<<8 | int(body[p+1])) // cipher suites
	if len(body) < p+1 {
		return -1, 0
	}
	p += 1 + int(body[p]) // compression methods
	if len(body) < p+2 {
		return -1, 0
	}
	end := p + 2 + (int(body[p])<<8 | int(body[p+1]))
	p += 2
	if end > len(body) {
		end = len(body)
	}
	for p+4 <= end {
		typ := int(body[p])<<8 | int(body[p+1])
		l := int(body[p+2])<<8 | int(body[p+3])
		p += 4
		if typ == 0 && p+5 <= end { // server_name: list len(2) type(1) len(2) name
			n := int(body[p+3])<<8 | int(body[p+4])
			if p+5+n <= end {
				return p + 5, n
			}
			return -1, 0
		}
		p += l
	}
	return -1, 0
}

// parseSNI extracts the host name from the first bytes of a TLS connection.
func parseSNI(b []byte) string {
	if len(b) < 6 || b[0] != 0x16 || b[1] != 0x03 {
		return ""
	}
	recLen := int(b[3])<<8 | int(b[4])
	body := b[5:]
	if recLen < len(body) {
		body = body[:recLen]
	}
	off, n := findSNI(body)
	if off < 0 {
		return ""
	}
	return string(body[off : off+n])
}

// splitClientHello turns one TLS record holding a ClientHello into two
// records cut in the middle of the SNI. Other data is returned unchanged.
func splitClientHello(b []byte) [][]byte {
	if len(b) < 6 || b[0] != 0x16 || b[1] != 0x03 {
		return [][]byte{b}
	}
	recLen := int(b[3])<<8 | int(b[4])
	if recLen < 8 || 5+recLen > len(b) {
		return [][]byte{b}
	}
	body := b[5 : 5+recLen]
	cut := 2
	if off, n := findSNI(body); off > 0 && n > 1 {
		cut = off + n/2
	}
	rec := func(part []byte) []byte {
		r := make([]byte, 0, 5+len(part))
		r = append(r, 0x16, b[1], b[2], byte(len(part)>>8), byte(len(part)))
		return append(r, part...)
	}
	second := rec(body[cut:])
	second = append(second, b[5+recLen:]...)
	return [][]byte{rec(body[:cut]), second}
}

func dialDirect(ctx context.Context, network, addr string) (net.Conn, error) {
	d := net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second, Control: directControl}
	return d.DialContext(ctx, network, addr)
}
