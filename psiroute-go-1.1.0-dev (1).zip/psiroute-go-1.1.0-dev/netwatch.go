package main

import (
	"context"
	"errors"
	"net"
	"sync"
	"time"
	"unicode"
	"unicode/utf8"
)

// netWatch (1.0.7) notices that the computer woke up or changed networks
// (another Wi-Fi, a cable, a VPN, a phone hotspot) and recovers at once,
// instead of waiting for health checks to fail one by one: DNS cache
// cleared, idle connections dropped, WARP starts a fresh UDP flow, Psiphon
// checks its tunnel and reconnects if it is dead.
//
// Windows tells us about address changes (NotifyAddrChange) and sleep
// (WM_POWERBROADCAST); everywhere else, and as a safety net, a 5-second
// poll compares the primary address and spots gaps in time (sleep).

type netWatch struct {
	a     *App
	every time.Duration
	probe func() string
	now   func() time.Time
	kick  chan string

	onEvent func(kind, text string) // tests; nil: a.recoverNetwork

	mu         sync.Mutex
	ip         string
	changes    int
	resumes    int
	lastEvent  time.Time
	lastText   string
	lastResume time.Time
	asleepAt   time.Time
}

func newNetWatch(a *App) *netWatch {
	return &netWatch{a: a, every: 5 * time.Second, probe: primaryIP, now: time.Now, kick: make(chan string, 4)}
}

// Kick: the system says something changed ("net" or "resume").
func (w *netWatch) Kick(why string) {
	if w == nil {
		return
	}
	select {
	case w.kick <- why:
	default:
	}
}

// suspended: the system goes to sleep.
func (w *netWatch) suspended() {
	if w == nil {
		return
	}
	w.mu.Lock()
	w.asleepAt = w.now()
	w.mu.Unlock()
	logf("info", "Компьютер засыпает")
}

func (w *netWatch) run(ctx context.Context) {
	w.mu.Lock()
	w.ip = w.probe()
	w.mu.Unlock()
	goSafe("слежение за сетью", func() { platformNetNotify(ctx, w) })
	t := time.NewTicker(w.every)
	defer t.Stop()
	last := w.now()
	for {
		select {
		case <-ctx.Done():
			return
		case why := <-w.kick:
			// let the new network settle (DHCP, DNS) before testing it
			select {
			case <-ctx.Done():
				return
			case <-time.After(2 * time.Second):
			}
			now := w.now()
			w.step(why, 0)
			last = now
		case <-t.C:
			now := w.now()
			w.step("", now.Sub(last))
			last = now
		}
	}
}

// step compares the network with what it was. gap: time since the last
// tick; much longer than the tick interval means the computer slept.
func (w *netWatch) step(why string, gap time.Duration) {
	ip := w.probe()
	now := w.now()
	w.mu.Lock()
	old := w.ip
	w.ip = ip
	kind, text := "", ""
	switch {
	case ip != "" && ip != old:
		kind = "net"
		if old == "" {
			text = "сеть появилась (" + ip + ")"
		} else {
			text = "сменилась сеть (" + old + " → " + ip + ")"
		}
		w.changes++
	case why == "resume" || gap > 30*time.Second:
		if now.Sub(w.lastResume) < time.Minute {
			break // Windows sends several resume messages; the tick sees the gap too
		}
		kind, text = "resume", "компьютер проснулся"
		if !w.asleepAt.IsZero() {
			text += " (спал " + humanDur(now.Sub(w.asleepAt)) + ")"
		} else if gap > 0 {
			text += " (спал " + humanDur(gap) + ")"
		}
		w.lastResume, w.asleepAt = now, time.Time{}
		w.resumes++
	case ip == "" && old != "":
		w.mu.Unlock()
		logf("warn", "Сеть пропала — жду, когда появится")
		return
	}
	if kind != "" {
		w.lastEvent, w.lastText = now, text
	}
	w.mu.Unlock()
	if kind == "" {
		return
	}
	if w.onEvent != nil {
		w.onEvent(kind, text)
		return
	}
	w.a.recoverNetwork(kind, text)
}

func (w *netWatch) view() map[string]any {
	if w == nil {
		return nil
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	m := map[string]any{"ip": w.ip, "changes": w.changes, "resumes": w.resumes}
	if !w.lastEvent.IsZero() {
		m["last"] = w.lastText
		m["lastAt"] = w.lastEvent.Unix()
	}
	return m
}

// primaryIP: the local address of the route to the internet (no packet is
// sent: a UDP "connect" only picks the route).
func primaryIP() string {
	for _, t := range [][2]string{{"udp4", "8.8.8.8:53"}, {"udp6", "[2001:4860:4860::8888]:53"}} {
		c, err := net.Dial(t[0], t[1])
		if err != nil {
			continue
		}
		ip := c.LocalAddr().(*net.UDPAddr).IP.String()
		_ = c.Close()
		return ip
	}
	return ""
}

// theNetWatch: for the tray window procedure (WM_POWERBROADCAST).
var theNetWatch *netWatch

var errNetChange = errors.New("сеть сменилась")

// recoverNetwork: what to redo after a network change or sleep.
func (a *App) recoverNetwork(kind, text string) {
	logf("info", "%s — проверяю связь", upperFirst(text))
	theDNS.clear()
	a.dohReset()
	obfs.reset() // another network, other DPI: learn the methods again
	a.tun.refresh()
	if kind == "net" {
		// country exits were connected over the old network; they restart
		// on demand
		a.countries.StopAll()
		if t := a.warp.cur.Load(); t != nil {
			if err := t.refresh(); err != nil {
				logf("warn", "WARP: не удалось переоткрыть туннель: %v", err)
			}
		}
	}
	if a.psi.running() {
		a.psi.send("check")
	}
}

func upperFirst(s string) string {
	r, n := utf8.DecodeRuneInString(s)
	if n == 0 {
		return s
	}
	return string(unicode.ToUpper(r)) + s[n:]
}
