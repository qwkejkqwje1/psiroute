package main

// Choosing the next Psiphon method: a quick first round, remembering only a
// method whose tunnels actually held, sending methods whose tunnels the
// network cuts soon after connecting to the end of the list, and not letting
// repeated button presses cancel every attempt.

import (
	"encoding/json"
	"os"
	"strings"
	"time"
)

const (
	holdOK      = 3 * time.Minute  // tunnels held this long: the method is remembered
	shortLife   = 2 * time.Minute  // tunnels lost sooner were cut by the network
	unstableFor = 6 * time.Hour    // a method cut twice in a row goes last this long
	cmdGap      = 20 * time.Second // button presses closer than this are not passed on
)

// attemptTimeout is the time one method gets before the next one is tried:
// the first round goes over all methods quickly, later rounds give more.
func attemptTimeout(round int) int { return []int{45, 90, 180}[min(max(round, 0), 2)] }

// userCmd passes a button press (next method, new node) on to the engine
// unless the previous press or the start of the attempt was less than
// cmdGap ago: every press cancels the attempt in progress, so pressing again
// and again never lets a method finish. It returns the seconds left to wait
// (0 = passed on).
func (p *Psi) userCmd(c string) int {
	p.mu.Lock()
	since := min(time.Since(p.cmdAt), time.Since(p.attemptAt))
	if p.cancel != nil && since < cmdGap {
		p.mu.Unlock()
		return int((cmdGap - since + time.Second - 1) / time.Second)
	}
	p.cmdAt = time.Now()
	p.mu.Unlock()
	p.send(c)
	return 0
}

// warpUp: the built-in WARP tunnel is up.
func (p *Psi) warpUp() bool { return p.app != nil && p.app.warp.connected() }

// lastGood is the method whose tunnels last held for holdOK.
func (p *Psi) lastGood() string {
	b, _ := os.ReadFile(p.file("psiroute-last"))
	return strings.TrimSpace(string(b))
}

// order puts the method that last held first and the methods whose tunnels
// kept dying soon after connecting last.
func (p *Psi) order(list []strategyDef, last string) []strategyDef {
	var good, bad []strategyDef
	for _, s := range list {
		if p.isUnstable(s.ID) {
			bad = append(bad, s)
		} else {
			good = append(good, s)
		}
	}
	for i, s := range good {
		if s.ID == last && i > 0 {
			rest := append(append([]strategyDef(nil), good[:i]...), good[i+1:]...)
			good = append([]strategyDef{s}, rest...)
			break
		}
	}
	return append(good, bad...)
}

func (p *Psi) unstableLocked() map[string]int64 {
	if p.unstable == nil {
		p.unstable = map[string]int64{}
		if b, err := os.ReadFile(p.file("psiroute-unstable.json")); err == nil {
			var m map[string]int64
			if json.Unmarshal(b, &m) == nil && m != nil {
				p.unstable = m
			}
		}
	}
	return p.unstable
}

func (p *Psi) isUnstable(id string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.unstableLocked()[id] > time.Now().Unix()
}

// markUnstable sends a method to the end of the list for unstableFor (on)
// or takes it back (off); the marks survive a restart.
func (p *Psi) markUnstable(id string, on bool) {
	p.mu.Lock()
	m := p.unstableLocked()
	now := time.Now()
	for k, until := range m {
		if until <= now.Unix() {
			delete(m, k)
		}
	}
	if on {
		m[id] = now.Add(unstableFor).Unix()
	} else {
		delete(m, id)
	}
	b, _ := json.Marshal(m)
	p.mu.Unlock()
	_ = os.WriteFile(p.file("psiroute-unstable.json"), b, 0o600)
}
