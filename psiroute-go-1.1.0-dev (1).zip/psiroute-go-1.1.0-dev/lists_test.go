package main

import (
	"context"
	"net/netip"
	"strings"
	"testing"
	"time"
)

func TestParseListAndMatch(t *testing.T) {
	d := parseList(strings.NewReader("# comment\nYouTube.com\n*.googlevideo.com\n.ytimg.com\n91.108.4.0/22\n149.154.167.50\nbad line here\nfoo // x\n\n2001:67c:4e8::/48\n"))
	cases := map[string]bool{
		"youtube.com": true, "www.youtube.com": true, "r1.googlevideo.com": true, "i.ytimg.com": true,
		"notyoutube.com": false, "com": false, "bad": false,
	}
	for h, want := range cases {
		if got := (&Lists{data: map[string]*listData{"u": d}}).dataMatch("u", h); got != want {
			t.Errorf("%s: got %v want %v", h, got, want)
		}
	}
	l := &Lists{data: map[string]*listData{}}
	u, _ := resolveListURL("telegram-ip")
	l.data[u] = d
	for ip, want := range map[string]bool{"91.108.5.1": true, "91.108.8.1": false, "149.154.167.50": true, "2001:67c:4e8::1": true} {
		if got := l.Match([]string{"telegram-ip"}, ip); got != want {
			t.Errorf("%s: got %v want %v", ip, got, want)
		}
	}
}

func (l *Lists) dataMatch(u, host string) bool {
	return l.data[u].match(host, parseAddrOrZero(host))
}

func TestResolveListURL(t *testing.T) {
	for _, ok := range []string{"ru-blocked", "RU-BLOCKED", "https://raw.githubusercontent.com/a/b/main/x.lst", "https://antifilter.download/list/ip.lst"} {
		if _, err := resolveListURL(ok); err != nil {
			t.Errorf("%s rejected: %v", ok, err)
		}
	}
	for _, bad := range []string{"", "http://raw.githubusercontent.com/x", "https://evil.example/list", "https://raw.githubusercontent.com.evil.ru/x", "file:///etc/passwd", "unknown-preset"} {
		if _, err := resolveListURL(bad); err == nil {
			t.Errorf("%q accepted", bad)
		}
	}
}

func TestCountryOutbound(t *testing.T) {
	for in, want := range map[string]string{"psiphon:DE": "DE", "psiphon:nl": "NL"} {
		if cc, ok := countryOf(in); !ok || cc != want {
			t.Errorf("%s -> %s %v", in, cc, ok)
		}
	}
	for _, bad := range []string{"psiphon", "psiphon:", "psiphon:DEU", "psiphon:1E", "direct:DE"} {
		if _, ok := countryOf(bad); ok {
			t.Errorf("%s accepted", bad)
		}
	}
}

// A rule with a list and a country routes every listed host there, with no
// silent fallback to a Psiphon exit in another country.
func TestRuleWithListAndCountry(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	a := NewApp(ctx, cancel, "", t.TempDir())
	a.cfg.Routing.Mode = "rules"
	a.cfg.Routing.Failover = true
	a.cfg.Routing.Default = obDirect
	a.cfg.Routing.Rules = []Rule{{Name: "через Германию", Outbound: "psiphon:DE", Lists: []string{"youtube"}}}
	u, _ := resolveListURL("youtube")
	a.lists.data[u] = parseList(strings.NewReader("youtube.com\ngooglevideo.com\n"))
	order, rule := a.router.plan("rr3.googlevideo.com", 443)
	if len(order) != 1 || order[0] != "psiphon:DE" || rule != "через Германию" {
		t.Fatalf("order=%v rule=%q", order, rule)
	}
	order, _ = a.router.plan("vk.com", 443)
	if order[0] != obDirect {
		t.Fatalf("vk.com: %v", order)
	}
	_ = time.Second
}

func parseAddrOrZero(s string) (a netip.Addr) {
	a, _ = netip.ParseAddr(s)
	return a
}
