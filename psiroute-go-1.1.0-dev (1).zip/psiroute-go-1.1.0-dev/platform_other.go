//go:build !windows

package main

import (
	"errors"
	"net"
	"os/exec"
)

var errWindowsOnly = errors.New("доступно только в Windows")

func setSystemProxy(addr string, on bool) error { return errWindowsOnly }
func systemProxyOwnedBy(addrs ...string) bool   { return false }
func autostartEnabled() bool                    { return false }
func setAutostart(on bool) error                { return errWindowsOnly }
func hideConsole(cmd *exec.Cmd)                 {}

func appForConn(remote net.Addr) string {
	if ta, ok := remote.(*net.TCPAddr); ok && !ta.IP.IsLoopback() {
		return ta.IP.String()
	}
	return ""
}
