package main

import (
	"bytes"
	"context"
	"crypto/subtle"
	_ "embed"
	"encoding/json"
	"net"
	"net/http"
	"slices"
	"strconv"
	"strings"
	"time"
)

//go:embed ui/index.html
var indexHTML []byte

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	// headers must be set before WriteHeader, otherwise the JSON content
	// type was silently dropped on every error response
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": false, "error": msg})
}

func (a *App) serveUI(ln net.Listener) {
	srv := &http.Server{Handler: a.routes(), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		<-a.ctx.Done()
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		_ = srv.Shutdown(ctx)
	}()
	_ = srv.Serve(ln)
}

func (a *App) routes() http.Handler {
	page := bytes.ReplaceAll(indexHTML, []byte("__PSIROUTE_TOKEN__"), []byte(a.token))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Block DNS-rebinding: only accept requests addressed to localhost.
		host := r.Host
		if h, _, err := net.SplitHostPort(host); err == nil {
			host = h
		}
		host = strings.Trim(host, "[]")
		if host != "127.0.0.1" && host != "localhost" && host != "::1" {
			http.Error(w, "доступ запрещён", http.StatusForbidden)
			return
		}
		switch {
		case r.URL.Path == "/api/ping":
			_, _ = w.Write([]byte("psiroute " + version))
		case strings.HasPrefix(r.URL.Path, "/api/"):
			if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-Psiroute")), []byte(a.token)) != 1 {
				writeErr(w, http.StatusForbidden, "неверный токен") // ТЗ §3.4: 403
				return
			}
			r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
			defer func() {
				if v := recover(); v != nil {
					reportPanic("интерфейс "+r.URL.Path, v)
					writeErr(w, 500, "внутренняя ошибка (записана в журнал)")
				}
			}()
			a.api(w, r)
		case r.URL.Path == "/proxy.pac": // for "automatic proxy configuration" in browsers, no token
			w.Header().Set("Content-Type", "application/x-ns-proxy-autoconfig")
			w.Header().Set("Cache-Control", "no-store")
			_, _ = w.Write([]byte(browserPAC(a.listenAddr())))
		case r.URL.Path == "/" || r.URL.Path == "/index.html":
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.Header().Set("Cache-Control", "no-store")
			_, _ = w.Write(page)
		default:
			http.NotFound(w, r)
		}
	})
}

func (a *App) restartIfRunning() bool {
	if a.psi.running() {
		go a.psi.Restart()
		return true
	}
	return false
}

func (a *App) api(w http.ResponseWriter, r *http.Request) {
	p := strings.TrimPrefix(r.URL.Path, "/api/")
	q := r.URL.Query()
	post := r.Method == http.MethodPost
	ok := map[string]any{"ok": true}
	tail := func(prefix string) string { return strings.TrimPrefix(p, prefix) }

	if strings.HasPrefix(p, "profiles") && a.profilesAPI(w, r, p) {
		return // profiles.go: export, import, ready-made profiles, undo
	}

	switch {
	case p == "selftest" && post:
		ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
		defer cancel()
		checks := a.selftest(ctx)
		writeJSON(w, map[string]any{"checks": checks, "text": formatChecks(checks)})
	case p == "report" && post:
		ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
		defer cancel()
		path, err := a.makeReport(ctx)
		if err != nil {
			writeErr(w, 500, "отчёт не сохранён: "+err.Error())
			return
		}
		if q.Get("reveal") != "0" {
			revealFile(path)
		}
		writeJSON(w, map[string]any{"ok": true, "path": path})
	case p == "state":
		writeJSON(w, a.state())
	case p == "psi/info":
		writeJSON(w, a.psi.info())

	case p == "settings" && !post:
		writeJSON(w, map[string]any{"values": a.cfg.values(), "autostart": autostartEnabled(), "config_path": a.cfgPath})
	case p == "settings":
		var m map[string]any
		if json.NewDecoder(r.Body).Decode(&m) != nil {
			writeErr(w, 400, "ошибка в данных запроса")
			return
		}
		restart := false
		for k, v := range m {
			if k == "tun.enabled" {
				if err := a.setTun(toBool(v)); err != nil {
					writeJSON(w, map[string]any{"ok": false, "error": tunErrText(err), "need_admin": err == errNeedAdmin})
					return
				}
				continue
			}
			if k == "general.system_proxy" {
				if err := a.setSysProxy(toBool(v)); err != nil {
					writeErr(w, 500, err.Error())
					return
				}
				continue
			}
			if a.cfg.setKey(k, v) {
				restart = true
			}
		}
		_ = a.cfg.save()
		restarted := restart && a.restartIfRunning()
		writeJSON(w, map[string]any{"ok": true, "restarted": restarted})

	case p == "psi/strategies":
		var b struct {
			Strategies []string `json:"strategies"`
		}
		if json.NewDecoder(r.Body).Decode(&b) != nil {
			writeErr(w, 400, "ошибка в данных запроса")
			return
		}
		ids := []string{}
		for _, id := range b.Strategies {
			if _, okk := strategyByID(id); okk {
				ids = append(ids, id)
			}
		}
		a.cfg.mu.Lock()
		a.cfg.Psiphon.Strategies = ids
		a.cfg.mu.Unlock()
		_ = a.cfg.save()
		writeJSON(w, map[string]any{"ok": true, "restarted": a.restartIfRunning()})
	case p == "psi/region":
		var b struct {
			Region string `json:"region"`
		}
		_ = json.NewDecoder(r.Body).Decode(&b)
		a.cfg.mu.Lock()
		a.cfg.Psiphon.Country = strings.ToUpper(strings.TrimSpace(b.Region))
		a.cfg.mu.Unlock()
		_ = a.cfg.save()
		if b.Region == "" {
			logf("info", "Страна выхода: любая (быстрейшая)")
		} else {
			logf("info", "Страна выхода: %s", strings.ToUpper(b.Region))
		}
		writeJSON(w, map[string]any{"ok": true, "restarted": a.restartIfRunning()})
	case p == "psi/speedtest":
		ctx, cancel := context.WithTimeout(r.Context(), 40*time.Second)
		defer cancel()
		writeJSON(w, a.psi.SpeedTest(ctx))
	case p == "psi/probe":
		if post {
			if err := a.startProbe(); err != nil {
				writeErr(w, 409, err.Error())
				return
			}
		}
		writeJSON(w, a.probeState())
	case p == "psi/probe/stop":
		a.stopProbe()
		writeJSON(w, ok)
	case p == "psi/probe/apply":
		if err := a.applyProbe(q.Get("id")); err != nil {
			writeErr(w, 400, err.Error())
			return
		}
		writeJSON(w, ok)

	case strings.HasPrefix(p, "psiphon/"):
		switch tail("psiphon/") {
		case "start":
			a.psi.Start()
		case "stop":
			go a.psi.Stop()
		case "restart":
			go a.psi.Restart()
		case "next":
			if left := a.psi.Next(); left > 0 {
				writeJSON(w, map[string]any{"ok": true, "wait": left})
				return
			}
		case "newnode":
			if left := a.psi.NewNode(); left > 0 {
				writeJSON(w, map[string]any{"ok": true, "wait": left})
				return
			}
		default:
			writeErr(w, 404, "неизвестное действие")
			return
		}
		writeJSON(w, ok)

	case strings.HasPrefix(p, "autostart/"):
		if err := setAutostart(tail("autostart/") == "on"); err != nil {
			writeErr(w, 500, err.Error())
			return
		}
		writeJSON(w, map[string]any{"ok": true, "autostart": autostartEnabled()})
	case strings.HasPrefix(p, "mode/"):
		m := tail("mode/")
		if m != "psiphon" && m != "rules" && m != "auto" {
			writeErr(w, 400, "неизвестный режим")
			return
		}
		a.cfg.mu.Lock()
		a.cfg.Routing.Mode = m
		a.cfg.mu.Unlock()
		_ = a.cfg.save()
		logf("info", "Режим маршрутизации: %s", m)
		writeJSON(w, ok)
	case strings.HasPrefix(p, "sysproxy/"):
		if err := a.setSysProxy(tail("sysproxy/") == "on"); err != nil {
			writeErr(w, 500, err.Error())
			return
		}
		writeJSON(w, ok)
	case p == "tun/elevate" && post:
		if isElevated() {
			if err := a.setTun(true); err != nil {
				writeErr(w, 500, tunErrText(err))
				return
			}
			writeJSON(w, map[string]any{"ok": true})
			return
		}
		if err := a.relaunchForTun(); err != nil {
			writeErr(w, 500, err.Error())
			return
		}
		writeJSON(w, map[string]any{"ok": true, "restarting": true})
		go func() { time.Sleep(700 * time.Millisecond); a.cancel() }()
	case strings.HasPrefix(p, "tun/") && post:
		on := tail("tun/") == "on"
		if err := a.setTun(on); err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": tunErrText(err), "need_admin": err == errNeedAdmin})
			return
		}
		writeJSON(w, ok)
	case p == "browser/info":
		writeJSON(w, map[string]any{"ok": true, "list": browserList()})
	case p == "browser/open" && post:
		var body struct {
			Browser string `json:"browser"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			writeErr(w, 400, "неверный запрос")
			return
		}
		if err := a.openBrowser(body.Browser); err != nil {
			writeErr(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]any{"ok": true})
	case p == "dpi/test" && post:
		var b struct {
			Sites []string `json:"sites"`
		}
		_ = json.NewDecoder(r.Body).Decode(&b)
		if len(b.Sites) == 0 {
			b.Sites = a.dpiSites()
		}
		if err := a.dpiTestStart(b.Sites); err != nil {
			writeErr(w, 409, err.Error())
			return
		}
		writeJSON(w, a.dpiTestView())
	case p == "dpi/test":
		writeJSON(w, a.dpiTestView())
	case p == "dpi/test/stop" && post:
		dpiTestStop()
		writeJSON(w, map[string]any{"ok": true})
	case p == "dpi/mode" && post:
		var b struct {
			Mode string `json:"mode"`
		}
		if json.NewDecoder(r.Body).Decode(&b) != nil {
			writeErr(w, 400, "ошибка в данных запроса")
			return
		}
		if err := a.dpiSetMode(b.Mode); err != nil {
			writeErr(w, 400, err.Error())
			return
		}
		writeJSON(w, map[string]any{"ok": true, "mode": a.dpiMode()})
	case p == "obfs/reset" && post:
		obfs.reset()
		writeJSON(w, map[string]any{"ok": true})
	case p == "quit":
		writeJSON(w, ok)
		go func() { time.Sleep(300 * time.Millisecond); a.cancel() }()
	case p == "reload":
		a.reloadConfig()
		writeJSON(w, ok)
	case p == "dns/clear":
		theDNS.clear()
		logf("info", "Кэш DNS очищен")
		writeJSON(w, ok)

	case p == "learned/forget":
		a.router.forget(q.Get("host"))
		writeJSON(w, ok)
	case p == "learned/clear":
		a.router.clearLearned()
		writeJSON(w, ok)

	case p == "diagnose":
		host := strings.TrimSpace(q.Get("host"))
		if host == "" {
			writeErr(w, 400, "укажите сайт")
			return
		}
		port, _ := strconv.Atoi(q.Get("port"))
		if port == 0 {
			port = 443
		}
		ctx, cancel := context.WithTimeout(r.Context(), 60*time.Second)
		defer cancel()
		writeJSON(w, a.diagnose(ctx, cleanHost(host), port))
	case p == "route":
		host := cleanHost(q.Get("host"))
		port, _ := strconv.Atoi(q.Get("port"))
		if port == 0 {
			port = 443
		}
		app := strings.TrimSpace(q.Get("app"))
		order, rule := a.router.planFor(host, port, app)
		first := ""
		if len(order) > 0 {
			first = order[0]
		}
		// port and learned are read by the UI ("Проверить маршрут"); before 1.0.2
		// they were missing and the page showed "host:undefined".
		writeJSON(w, map[string]any{"host": host, "port": port, "outbound": first, "chain": order, "rule": rule, "learned": a.router.learnedFor(host)})

	case p == "rules" && !post:
		// Status() takes cfg.mu itself: read it before locking (no deadlock).
		listSt, countrySt := a.lists.Status(), a.countries.Status()
		a.cfg.mu.Lock()
		// "outbounds" fills the route dropdowns in the rule editor. Without it the
		// selects were empty and saving rules wiped every rule's outbound.
		resp := map[string]any{"default": a.cfg.Routing.Default, "auto_chain": a.cfg.Routing.Chain, "rules": a.cfg.Routing.Rules,
			"outbounds": ruleOutbounds(), "presets": listPresets, "trusted": listTrustedHosts,
			"lists": listSt, "countries": countrySt}
		a.cfg.mu.Unlock()
		writeJSON(w, resp)
	case p == "rules":
		var b struct {
			Default string   `json:"default"`
			Chain   []string `json:"auto_chain"`
			Rules   []Rule   `json:"rules"`
		}
		if json.NewDecoder(r.Body).Decode(&b) != nil {
			writeErr(w, 400, "ошибка в данных запроса")
			return
		}
		// A rule without an outbound is a data-loss bug in the making (the
		// 1.0.2 UI wiped routes exactly this way): reject the whole save.
		for _, ru := range b.Rules {
			if ru.Outbound == "" {
				writeErr(w, 400, "у правила «"+ru.Name+"» не указан маршрут")
				return
			}
			if strings.HasPrefix(ru.Outbound, obPsiphon+":") && !isCountryOb(ru.Outbound) {
				writeErr(w, 400, "у правила «"+ru.Name+"» неверная страна: нужен код из двух букв, например psiphon:DE")
				return
			}
			for _, l := range ru.Lists {
				if _, err := resolveListURL(l); err != nil {
					writeErr(w, 400, "правило «"+ru.Name+"»: "+err.Error())
					return
				}
			}
		}
		a.cfg.mu.Lock()
		if b.Default != "" {
			a.cfg.Routing.Default = b.Default
		}
		if len(b.Chain) > 0 {
			a.cfg.Routing.Chain = b.Chain
		}
		if b.Rules == nil {
			b.Rules = []Rule{}
		}
		a.cfg.Routing.Rules = b.Rules
		a.cfg.mu.Unlock()
		_ = a.cfg.save()
		a.lists.Refresh()
		writeJSON(w, ok)
	case p == "rules/add":
		var body struct {
			Hosts    []string `json:"hosts"`
			Outbound string   `json:"outbound"`
			Name     string   `json:"name"`
		}
		_ = json.NewDecoder(r.Body).Decode(&body)
		ob := q.Get("outbound")
		if ob == "" {
			ob = body.Outbound
		}
		if ob == "" {
			ob = obPsiphon
		}
		var hosts []string
		if h := cleanHost(q.Get("host")); h != "" {
			hosts = append(hosts, h)
		}
		for _, raw := range body.Hosts {
			if h := cleanHost(raw); h != "" && !slices.Contains(hosts, h) {
				hosts = append(hosts, h)
			}
		}
		if len(hosts) == 0 {
			writeErr(w, 400, "укажите сайт")
			return
		}
		name := strings.TrimSpace(body.Name)
		if name == "" {
			name = strings.Join(hosts, ", ")
			if len(name) > 48 {
				name = hosts[0] + " (+" + strconv.Itoa(len(hosts)-1) + ")"
			}
		}
		a.cfg.mu.Lock()
		updated := false
		if len(hosts) == 1 {
			for i := range a.cfg.Routing.Rules {
				ru := &a.cfg.Routing.Rules[i]
				if len(ru.Domains) == 1 && cleanHostKey(ru.Domains[0]) == hosts[0] && len(ru.Apps) == 0 && len(ru.Ports) == 0 && len(ru.Lists) == 0 {
					ru.Outbound = ob
					updated = true
					break
				}
			}
		}
		if !updated {
			a.cfg.Routing.Rules = append(a.cfg.Routing.Rules, Rule{Name: name, Outbound: ob, Domains: hosts})
		}
		a.cfg.mu.Unlock()
		_ = a.cfg.save()
		for _, h := range hosts {
			a.router.forget(h)
		}
		logf("info", "Правило: %s → %s", name, ob)
		writeJSON(w, ok)

	case p == "share":
		writeJSON(w, a.shareInfo())
	case strings.HasPrefix(p, "share/"):
		if err := a.setShare(tail("share/") == "on"); err != nil {
			writeErr(w, 500, err.Error())
			return
		}
		writeJSON(w, a.shareInfo())
	default:
		writeErr(w, 404, "неизвестный запрос")
	}
}

// cleanHost accepts "https://site.com/path", "site.com:443" or "site.com".
func cleanHost(s string) string {
	s = strings.TrimSpace(strings.ToLower(s))
	if i := strings.Index(s, "://"); i >= 0 {
		s = s[i+3:]
	}
	if i := strings.IndexAny(s, "/?#"); i >= 0 {
		s = s[:i]
	}
	if h, _, err := net.SplitHostPort(s); err == nil {
		s = h
	}
	return strings.Trim(s, "[]")
}

// ruleOutbounds fills the route dropdowns: the usual outbounds plus
// "Psiphon, exit country XX" for the per-rule country feature.
func ruleOutbounds() []string {
	out := []string{obPsiphon, obDirect, obDesync, obWarp, obProxy, obBlock, obAuto}
	for _, cc := range countryChoices {
		out = append(out, obPsiphon+":"+cc)
	}
	return out
}
