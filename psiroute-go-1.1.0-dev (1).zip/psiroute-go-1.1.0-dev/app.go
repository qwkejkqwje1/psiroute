package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

var errAlreadyRunning = errors.New("psiroute уже запущен")

// App wires everything together: config, Psiphon engine, router, stats,
// local proxy, LAN share, web UI.
type App struct {
	tun     tunCtl // TUN mode, tun.go
	ctx     context.Context
	cancel  context.CancelFunc
	cfg     *Config
	cfgPath string
	dataDir string
	token   string

	psi    *Psi
	stats  *Stats
	router *Router

	lists     *Lists
	countries *Countries
	warp      *Warp // built-in WARP for Psiphon «Через WARP»

	proxyLn net.Listener
	uiLn    net.Listener

	// Actual addresses after port fallback (may differ from the config when
	// the configured port is taken by another program).
	uiActual     string
	listenActual string

	mu      sync.Mutex
	shareLn net.Listener
	sysOn   bool

	probeMu      sync.Mutex
	probeRunning bool
	probeResults []probeResult
	probeCancel  context.CancelFunc

	net        *netWatch // sleep / network change recovery
	started    time.Time
	dohClients sync.Map // outbound -> *http.Client for DoH (dnsmsg.go)
}

func NewApp(ctx context.Context, cancel context.CancelFunc, cfgPath, dataDir string) *App {
	a := &App{ctx: ctx, cancel: cancel, cfgPath: cfgPath, dataDir: dataDir}
	a.cfg = loadConfig(cfgPath)
	a.stats = newStats(filepath.Join(dataDir, "psiroute-days.json"))
	a.psi = newPsi(a, dataDir)
	a.router = newRouter(a, filepath.Join(dataDir, "psiroute-learned.json"))
	a.lists = newLists(a, filepath.Join(dataDir, "lists"))
	a.countries = newCountries(a)
	a.warp = newWarp(a, dataDir)
	a.net = newNetWatch(a)
	theNetWatch = a.net
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		panic("crypto/rand: " + err.Error()) // never run with a predictable token
	}
	a.token = hex.EncodeToString(b)
	return a
}

// listenFallback listens on addr; if that port is unavailable it tries the
// next ports and finally lets the OS pick a free one. The host part (normally
// 127.0.0.1) is never changed, so the service stays local-only.
func listenFallback(addr string, tries int, skip ...int) (net.Listener, error) {
	ln, err := net.Listen("tcp", addr)
	if err == nil {
		return ln, nil
	}
	firstErr := err
	host, ps, serr := net.SplitHostPort(addr)
	if serr != nil {
		return nil, firstErr
	}
	port := atoiSafe(ps)
next:
	for i := 1; i <= tries && port > 0 && port+i < 65536; i++ {
		for _, sk := range skip {
			if port+i == sk {
				continue next
			}
		}
		if ln, err := net.Listen("tcp", net.JoinHostPort(host, fmt.Sprint(port+i))); err == nil {
			return ln, nil
		}
	}
	if ln, err := net.Listen("tcp", net.JoinHostPort(host, "0")); err == nil {
		return ln, nil
	}
	return nil, firstErr
}

// The instance file records where the running copy serves its UI, so a
// second launch finds it even after a port fallback.
func instanceFile(dir string) string { return filepath.Join(dir, "psiroute.instance") }

func readInstance(dir string) string { return readInstanceLine(dir, 0) }

// readInstanceLine: line n (0-based) of the instance file, "" if absent.
func readInstanceLine(dir string, n int) string {
	b, err := os.ReadFile(instanceFile(dir))
	if err != nil {
		return ""
	}
	lines := strings.Split(strings.ReplaceAll(string(b), "\r", ""), "\n")
	if n < 0 || n >= len(lines) {
		return ""
	}
	return strings.TrimSpace(lines[n])
}

// isPsirouteAt reports whether another psiroute answers on the UI address.
func isPsirouteAt(addr string) bool {
	if addr == "" {
		return false
	}
	// Never go through any proxy for this local check.
	cl := &http.Client{Timeout: 2 * time.Second, Transport: &http.Transport{Proxy: nil}}
	resp, err := cl.Get("http://" + addr + "/api/ping")
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 64))
	return strings.HasPrefix(string(b), "psiroute")
}

func (a *App) uiAddr() string {
	a.mu.Lock()
	act := a.uiActual
	a.mu.Unlock()
	if act != "" {
		return act
	}
	a.cfg.mu.Lock()
	defer a.cfg.mu.Unlock()
	return a.cfg.General.UI
}

// listenAddr is the proxy address actually in use.
func (a *App) listenAddr() string {
	a.mu.Lock()
	act := a.listenActual
	a.mu.Unlock()
	if act != "" {
		return act
	}
	a.cfg.mu.Lock()
	defer a.cfg.mu.Unlock()
	return a.cfg.General.Listen
}

func (a *App) uiURL() string { return "http://" + a.uiAddr() + "/" }

func (a *App) Start() error {
	a.cfg.mu.Lock()
	listen, ui := a.cfg.General.Listen, a.cfg.General.UI
	share, sys := a.cfg.Share.Enabled, a.cfg.General.SystemProxy
	a.cfg.mu.Unlock()

	// Already running? Check the recorded address first (it may be a
	// fallback port), then the configured one.
	for _, addr := range []string{readInstance(a.dataDir), ui} {
		if isPsirouteAt(addr) {
			a.mu.Lock()
			a.uiActual = addr
			a.mu.Unlock()
			return errAlreadyRunning
		}
	}
	// Port 9090 is popular (Prometheus, Cockpit, some vendor tools) and may
	// sit in a Windows excluded port range: fall back instead of failing.
	uiLn, err := listenFallback(ui, 20)
	if err != nil {
		return fmt.Errorf("не удалось открыть интерфейс на %s и соседних портах: %w", ui, err)
	}
	if got := uiLn.Addr().String(); got != ui {
		logf("warn", "Адрес интерфейса %s занят другой программой — использую %s", ui, got)
	}
	a.cfg.mu.Lock()
	sharePort := a.cfg.Share.Port
	a.cfg.mu.Unlock()
	ln, err := listenFallback(listen, 20, sharePort)
	if err != nil {
		uiLn.Close()
		return fmt.Errorf("порт прокси %s занят: %w", listen, err)
	}
	if got := ln.Addr().String(); got != listen {
		logf("warn", "Порт прокси %s занят — использую %s (укажите его в программах, настроенных вручную)", listen, got)
	}
	a.mu.Lock()
	a.uiLn, a.proxyLn = uiLn, ln
	a.uiActual, a.listenActual = uiLn.Addr().String(), ln.Addr().String()
	a.mu.Unlock()
	ui, listen = a.uiActual, a.listenActual
	// Line 1: UI address (older versions read only this), 2: API token for
	// "psiroute --selftest", 3: proxy address.
	_ = os.WriteFile(instanceFile(a.dataDir), []byte(ui+"\n"+a.token+"\n"+listen), 0o600)
	a.started = time.Now()

	// §4.6: a previous run was killed while the system proxy pointed at us.
	if !sys {
		if stale := systemProxyOwnedBy(a.cfg.General.Listen, listen); stale {
			if err := setSystemProxy(listen, false); err == nil {
				logf("warn", "Системный прокси остался от прошлого запуска — сброшен")
			}
		}
	}
	go a.serveProxy(ln, nil)
	go a.serveUI(uiLn)
	goLoop(a.ctx, "основной цикл", a.loop)
	if share {
		if err := a.setShare(true); err != nil {
			logf("warn", "Раздача в сеть не запущена: %v", err)
		}
	}
	if sys {
		if err := a.setSysProxy(true); err != nil {
			logf("warn", "Системный прокси: %v", err)
		}
	}
	a.psi.Start()
	goLoop(a.ctx, "WARP", func() { a.warp.run(a.ctx) })
	goLoop(a.ctx, "слежение за сетью", func() { a.net.run(a.ctx) })
	a.lists.Start(a.ctx)
	a.countries.Start(a.ctx)
	if a.cfg.tunWanted() {
		goSafe("TUN", func() {
			if err := a.tun.start(a); err != nil {
				logf("warn", "Режим TUN: %s", tunErrText(err))
			}
		})
	}
	logf("info", "Psiroute %s: прокси %s (SOCKS5 + HTTP), интерфейс http://%s", version, listen, ui)
	return nil
}

func (a *App) Shutdown() {
	a.mu.Lock()
	sys := a.sysOn
	a.mu.Unlock()
	if sys {
		_ = setSystemProxy(a.listenAddr(), false) // keep the setting: it is restored on next start
	}
	a.tun.stop() // remove the adapter and its routes first
	a.router.flush()
	if readInstance(a.dataDir) == a.uiAddr() {
		_ = os.Remove(instanceFile(a.dataDir))
	}
	a.stopProbe()
	a.countries.StopAll()
	a.psi.Stop()
	a.warp.Close()
	for _, l := range []net.Listener{a.proxyLn, a.uiLn} {
		if l != nil {
			l.Close()
		}
	}
	a.mu.Lock()
	if a.shareLn != nil {
		a.shareLn.Close()
	}
	a.mu.Unlock()
}

func (a *App) loop() {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	var mod time.Time
	if st, err := os.Stat(a.cfgPath); err == nil {
		mod = st.ModTime()
	}
	n := 0
	for {
		select {
		case <-a.ctx.Done():
			return
		case <-t.C:
			a.stats.tick()
			n++
			if n%3 != 0 {
				continue
			}
			a.cfg.mu.Lock()
			watch := a.cfg.General.WatchConfig
			a.cfg.mu.Unlock()
			if st, err := os.Stat(a.cfgPath); err == nil && st.ModTime().After(mod) {
				mod = st.ModTime()
				if watch {
					a.reloadConfig()
				}
			}
		}
	}
}

// reloadConfig re-reads psiroute.json. A broken file is ignored (never
// replaced by defaults) so a half-saved edit cannot wipe the settings.
func (a *App) reloadConfig() {
	b, err := os.ReadFile(a.cfgPath)
	if err != nil {
		return
	}
	n := defaultConfig()
	if err := json.Unmarshal(b, n); err != nil {
		logf("warn", "psiroute.json: ошибка в файле, изменения не применены: %v", err)
		return
	}
	if n.Desync.Method == "" {
		n.Desync.Method = "auto"
	}
	if n.Tun.MTU < 1280 || n.Tun.MTU > 9000 {
		n.Tun.MTU = 1500
	}
	c := a.cfg
	c.mu.Lock()
	before, _ := json.Marshal([]any{c.Psiphon, c.Warp, c.Proxy})
	wasTun := c.Tun.Enabled
	c.Psiphon, c.Desync, c.Warp, c.Proxy, c.DNS, c.Routing = n.Psiphon, n.Desync, n.Warp, n.Proxy, n.DNS, n.Routing
	c.UDP = n.UDP
	c.Tun = n.Tun
	c.General.WatchConfig = n.General.WatchConfig
	needRestart := n.General.Listen != c.General.Listen || n.General.UI != c.General.UI
	after, _ := json.Marshal([]any{c.Psiphon, c.Warp, c.Proxy})
	nowTun := c.Tun.Enabled
	c.mu.Unlock()
	if needRestart {
		logf("info", "Адрес прокси или интерфейса изменён в файле — применится после перезапуска Psiroute")
	}
	if nowTun != wasTun {
		if nowTun {
			goSafe("TUN", func() {
				if err := a.tun.start(a); err != nil {
					logf("warn", "Режим TUN: %s", tunErrText(err))
				}
			})
		} else {
			goSafe("TUN", a.tun.stop)
		}
	}
	if string(before) != string(after) && a.psi.running() {
		logf("info", "Настройки Psiphon изменились — переподключаюсь")
		go a.psi.Restart()
	}
}

func (a *App) setSysProxy(on bool) error {
	l := a.listenAddr()
	if err := setSystemProxy(l, on); err != nil {
		return err
	}
	a.mu.Lock()
	a.sysOn = on
	a.mu.Unlock()
	a.cfg.setKey("general.system_proxy", on)
	_ = a.cfg.save()
	if on {
		logf("info", "Системный прокси включён: %s", l)
	} else {
		logf("info", "Системный прокси выключен")
	}
	return nil
}

func (a *App) state() map[string]any {
	a.cfg.mu.Lock()
	mode := a.cfg.Routing.Mode
	a.cfg.mu.Unlock()
	listen, ui := a.listenAddr(), a.uiAddr()
	a.mu.Lock()
	sys := a.sysOn
	a.mu.Unlock()
	logs := theLog.snapshot()
	if len(logs) > 300 {
		logs = logs[len(logs)-300:]
	}
	learned := a.router.learnedList()
	return map[string]any{
		"version": version, "mode": mode, "listen": listen, "ui": ui, "sysproxy": sys,
		"psiphon": a.psi.view(), "psiphon_slots": a.psi.slots(), "warp": a.warp.view(),
		"stats": a.stats.snapshot(), "history": a.stats.history(),
		"log": logs, "learned": learned, "learned_count": len(learned),
		"mem": memView(), "net": a.net.view(), "panics": panicsCaught.Load(), "crash_restarts": crashRestarts,
		"udp": map[string]any{"mode": a.udpMode(), "sessions": udpStats.sessions.Load(), "flows": udpStats.flows.Load()},
		"tun": a.tun.view(),
		"obfs": a.obfsView(),
	}
}

// ---- DPI auto-probe (separate process, see probe.go) ----

func (a *App) startProbe() error {
	a.probeMu.Lock()
	if a.probeRunning {
		a.probeMu.Unlock()
		return errors.New("подбор уже идёт")
	}
	a.probeRunning = true
	a.probeResults = nil
	ctx, cancel := context.WithCancel(a.ctx)
	a.probeCancel = cancel
	a.probeMu.Unlock()

	fail := func(err error) error {
		a.probeMu.Lock()
		a.probeRunning = false
		a.probeMu.Unlock()
		cancel()
		return err
	}
	exe, err := os.Executable()
	if err != nil {
		return fail(err)
	}
	a.cfg.mu.Lock()
	region := strings.ToUpper(a.cfg.Psiphon.Country)
	a.cfg.mu.Unlock()
	cmd := exec.CommandContext(ctx, exe, "--probe", "--probe-dir", filepath.Join(a.dataDir, "probe"), "--probe-region", region)
	hideConsole(cmd)
	out, err := cmd.StdoutPipe()
	if err != nil {
		return fail(err)
	}
	if err := cmd.Start(); err != nil {
		return fail(err)
	}
	logf("info", "Подбор обхода: проверяю варианты (до 8 минут)")
	go func() {
		sc := bufio.NewScanner(out)
		for sc.Scan() {
			var r probeResult
			if json.Unmarshal(sc.Bytes(), &r) != nil {
				continue
			}
			a.probeMu.Lock()
			a.probeResults = append(a.probeResults, r)
			a.probeMu.Unlock()
			if r.OK {
				logf("info", "Подбор: «%s» — работает, %d мс, %d КБ/с", r.Name, r.ConnectMs, r.Kbps)
			} else if r.Name != "" {
				logf("info", "Подбор: «%s» — нет (%s)", r.Name, r.Note)
			}
		}
		if err := sc.Err(); err != nil {
			logf("warn", "Подбор: результаты прочитаны не полностью: %v", err)
		}
		_ = cmd.Wait()
		a.probeMu.Lock()
		a.probeRunning = false
		a.probeCancel = nil
		a.probeMu.Unlock()
		cancel()
		logf("info", "Подбор обхода завершён")
	}()
	return nil
}

func (a *App) stopProbe() {
	a.probeMu.Lock()
	if a.probeCancel != nil {
		a.probeCancel()
	}
	a.probeMu.Unlock()
}

func (a *App) probeState() map[string]any {
	a.probeMu.Lock()
	defer a.probeMu.Unlock()
	res := append([]probeResult(nil), a.probeResults...)
	if res == nil {
		res = []probeResult{}
	}
	best := ""
	bestScore := -1.0
	for _, r := range res {
		if !r.OK {
			continue
		}
		score := float64(r.Kbps) + 100000.0/float64(r.ConnectMs+1)
		if score > bestScore {
			best, bestScore = r.ID, score
		}
	}
	return map[string]any{"running": a.probeRunning, "results": res, "best": best, "total": len(psiDPIStrategies())}
}

// applyProbe turns a probe result into settings: a DPI mode, or a protocol
// strategy moved to the top of the list.
func (a *App) applyProbe(id string) error {
	a.probeMu.Lock()
	var found *probeResult
	for i := range a.probeResults {
		if a.probeResults[i].ID == id && a.probeResults[i].OK {
			found = &a.probeResults[i]
		}
	}
	a.probeMu.Unlock()
	if found == nil {
		return errors.New("нет такого рабочего варианта")
	}
	c := a.cfg
	c.mu.Lock()
	if found.Protos == "" {
		c.Psiphon.DPI = found.DPI
	} else {
		list := []string{found.Protos}
		for _, s := range c.Psiphon.Strategies {
			if s != found.Protos {
				list = append(list, s)
			}
		}
		c.Psiphon.Strategies = list
	}
	c.mu.Unlock()
	_ = c.save()
	_ = os.Remove(a.psi.file("psiroute-last"))
	logf("info", "Применён вариант «%s»", found.Name)
	go a.psi.Restart()
	return nil
}
