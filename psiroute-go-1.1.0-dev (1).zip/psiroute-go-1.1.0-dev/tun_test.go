package main

import (
	"net"
	"net/netip"
	"testing"
	"time"
)

func TestTunSniffHTTPHost(t *testing.T) {
	b := []byte("GET / HTTP/1.1\r\nUser-Agent: x\r\nHost: Example.COM:8080\r\n\r\n")
	if h := sniffHost(b); h != "example.com" {
		t.Fatalf("host = %q", h)
	}
	if sniffWantMore(b) {
		t.Fatal("complete headers must not want more")
	}
	if !sniffWantMore([]byte("GET / HTTP/1.1\r\nHo")) {
		t.Fatal("partial headers must want more")
	}
	if sniffHost([]byte("SSH-2.0-OpenSSH")) != "" {
		t.Fatal("non-HTTP must give no host")
	}
}

func TestTunSniffTLSWantMore(t *testing.T) {
	if !sniffWantMore([]byte{0x16, 3, 1, 0x02, 0x00, 1, 2}) {
		t.Fatal("short ClientHello must want more")
	}
}

func TestTunDNSHelpers(t *testing.T) {
	q := []byte{0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0,
		3, 'W', 'w', 'W', 7, 'e', 'x', 'a', 'm', 'p', 'l', 'e', 3, 'c', 'o', 'm', 0, 0, 1, 0, 1}
	name, end := dnsQName(q)
	if name != "www.example.com" || end != len(q) {
		t.Fatalf("qname %q end %d", name, end)
	}
	r := dnsServfail(q)
	if r[0] != 0x12 || r[1] != 0x34 || r[2]&0x80 == 0 || r[3]&0x0f != 2 || len(r) != len(q) {
		t.Fatalf("bad servfail % x", r)
	}
	if _, end := dnsQName(q[:20]); end >= 0 {
		t.Fatal("truncated query must fail")
	}
}

func TestTunRevMap(t *testing.T) {
	var m revMap
	m.put(net.ParseIP("1.2.3.4"), "a.example", time.Minute)
	if m.get(netip.MustParseAddr("1.2.3.4")) != "a.example" {
		t.Fatal("lookup failed")
	}
	m.put(net.ParseIP("5.6.7.8"), "b.example", -time.Second)
	if m.get(netip.MustParseAddr("5.6.7.8")) != "" {
		t.Fatal("expired entry returned")
	}
}

func TestTunAppsAndTargets(t *testing.T) {
	l := tunSplitApps("Discord.exe; steam ,\n")
	if len(l) != 2 || !tunAppMatch("discord.exe", l) || !tunAppMatch("Steam.exe", l) || tunAppMatch("chrome.exe", l) {
		t.Fatalf("apps %v", l)
	}
	if tunUDPTarget(netip.MustParseAddr("224.0.0.251")) || tunUDPTarget(netip.MustParseAddr("255.255.255.255")) || !tunUDPTarget(netip.MustParseAddr("8.8.8.8")) {
		t.Fatal("udp target filter")
	}
	if !tunInternal(tunDNS4) || tunInternal(netip.MustParseAddr("172.19.0.5")) {
		t.Fatal("internal subnet")
	}
}
