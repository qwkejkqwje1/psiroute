package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"sync"
	"time"
)

// Encrypted DNS: direct connections resolve names over DoH (Cloudflare by IP)
// so DNS spoofing by the ISP does not break them. Falls back to the system
// resolver.

type dnsEntry struct {
	ips []string
	exp time.Time
}

type dnsCache struct {
	mu sync.Mutex
	m  map[string]dnsEntry
}

var theDNS = &dnsCache{m: map[string]dnsEntry{}}

func (d *dnsCache) clear() {
	d.mu.Lock()
	d.m = map[string]dnsEntry{}
	d.mu.Unlock()
	theDoHWire.clear()
}

// cachedIPs returns the already-cached IP addresses for host without
// performing any network lookup.
func (d *dnsCache) cachedIPs(host string) []net.IP {
	d.mu.Lock()
	e, ok := d.m[host]
	d.mu.Unlock()
	if !ok || len(e.ips) == 0 || time.Now().After(e.exp) {
		return nil
	}
	out := make([]net.IP, 0, len(e.ips))
	for _, s := range e.ips {
		if ip := net.ParseIP(s); ip != nil {
			out = append(out, ip)
		}
	}
	return out
}

var dohClient = &http.Client{
	Timeout:   6 * time.Second,
	Transport: &http.Transport{DialContext: dialDesync, ForceAttemptHTTP2: true},
}

func dohLookup(ctx context.Context, host string) ([]string, error) {
	u := "https://1.1.1.1/dns-query?name=" + url.QueryEscape(host) + "&type=A"
	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("accept", "application/dns-json")
	resp, err := dohClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("DoH: HTTP %d", resp.StatusCode)
	}
	var r struct {
		Answer []struct {
			Type int    `json:"type"`
			Data string `json:"data"`
		} `json:"Answer"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 64<<10)).Decode(&r); err != nil {
		return nil, err
	}
	var ips []string
	for _, a := range r.Answer {
		if a.Type == 1 {
			ips = append(ips, a.Data)
		}
	}
	if len(ips) == 0 {
		return nil, errors.New("DoH: нет адресов")
	}
	return ips, nil
}

func resolve(ctx context.Context, host string, useDoH bool) ([]string, error) {
	if net.ParseIP(host) != nil {
		return []string{host}, nil
	}
	theDNS.mu.Lock()
	e, ok := theDNS.m[host]
	theDNS.mu.Unlock()
	if ok && time.Now().Before(e.exp) {
		if len(e.ips) == 0 {
			return nil, errors.New("адрес не найден (кэш)")
		}
		return e.ips, nil
	}
	var ips []string
	var err error
	if useDoH {
		ips, err = dohLookup(ctx, host)
		if err != nil {
			logf("debug", "DoH для %s не ответил (%v) — системный DNS", host, err)
		}
	}
	if len(ips) == 0 {
		ips, err = net.DefaultResolver.LookupHost(ctx, host)
	}
	if err == nil && len(ips) == 0 {
		err = errors.New("адрес не найден")
	}
	if err != nil {
		if ctx.Err() == nil { // negative cache: do not hammer DNS for dead names
			theDNS.mu.Lock()
			theDNS.m[host] = dnsEntry{exp: time.Now().Add(30 * time.Second)}
			theDNS.mu.Unlock()
		}
		return nil, err
	}
	theDNS.mu.Lock()
	if len(theDNS.m) > 4096 { // cap: drop everything expired, else reset
		now := time.Now()
		for k, v := range theDNS.m {
			if now.After(v.exp) {
				delete(theDNS.m, k)
			}
		}
		if len(theDNS.m) > 4096 {
			theDNS.m = map[string]dnsEntry{}
		}
	}
	theDNS.m[host] = dnsEntry{ips: ips, exp: time.Now().Add(5 * time.Minute)}
	theDNS.mu.Unlock()
	return ips, nil
}
