package main

// Platform-independent helpers for the TUN mode (tun.go): addresses, socket
// binding to the real adapter, traffic sniffing, the reverse DNS map.

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"net"
	"net/netip"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

var (
	tunAddr4 = netip.MustParseAddr("172.19.0.1")
	tunDNS4  = netip.MustParseAddr("172.19.0.2")
	tunNet4  = netip.MustParsePrefix("172.19.0.0/30")
	tunAddr6 = netip.MustParseAddr("fdfe:dcba:9876::1")
	tunDNS6  = netip.MustParseAddr("fdfe:dcba:9876::2")
	tunNet6  = netip.MustParsePrefix("fdfe:dcba:9876::/126")

	errNeedAdmin      = errors.New("need_admin")
	errTunUnsupported = errors.New("режим TUN есть только в Windows")

	// tunActive: while TUN is on, our own direct sockets are bound to the
	// real adapter (physIdx4/6), otherwise they would loop back into TUN.
	tunActive          atomic.Bool
	physIdx4, physIdx6 atomic.Uint32
	physAlias          atomic.Value // string
)

// directControl is set as net.Dialer.Control / ListenConfig.Control on every
// direct outbound socket of Psiroute.
func directControl(network, address string, c syscall.RawConn) error {
	if !tunActive.Load() {
		return nil
	}
	return bindPhys(network, address, c)
}

func tunDialBound(ctx context.Context, network, addr string) (net.Conn, error) {
	d := net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second, Control: directControl}
	return d.DialContext(ctx, network, addr)
}

// listenUDPDirect replaces net.ListenUDP("udp", nil) for outbound UDP.
func listenUDPDirect() (*net.UDPConn, error) {
	lc := net.ListenConfig{Control: directControl}
	pc, err := lc.ListenPacket(context.Background(), "udp", ":0")
	if err != nil {
		return nil, err
	}
	if u, ok := pc.(*net.UDPConn); ok {
		return u, nil
	}
	pc.Close()
	return nil, errors.New("udp: неожиданный тип сокета")
}

func tunPhysIdx(ip netip.Addr) uint32 {
	if ip.Is4() {
		return physIdx4.Load()
	}
	return physIdx6.Load()
}

func tunPhysText() string {
	if s, _ := physAlias.Load().(string); s != "" {
		return s
	}
	return "—"
}

func tunErrText(err error) string {
	if err == nil {
		return ""
	}
	if errors.Is(err, errNeedAdmin) {
		return "Для режима TUN нужны права администратора — нажмите «Перезапустить от администратора»"
	}
	return err.Error()
}

func tunInternal(ip netip.Addr) bool { return tunNet4.Contains(ip) || tunNet6.Contains(ip) }

// tunUDPTarget drops multicast and broadcast: they never leave the LAN.
func tunUDPTarget(ip netip.Addr) bool {
	if !ip.IsValid() || ip.IsUnspecified() || ip.IsMulticast() {
		return false
	}
	return !(ip.Is4() && ip.As4() == [4]byte{255, 255, 255, 255})
}

var tunSelfExe = func() string {
	p, err := os.Executable()
	if err != nil {
		return ""
	}
	return filepath.Base(p)
}()

// isSelfProc: Psiroute itself, its Psiphon, WARP, country workers and the
// probe. Their traffic goes straight to the real adapter, never to Psiphon.
func isSelfProc(pid uint32, name string) bool {
	if pid == 0 {
		return false
	}
	if int(pid) == os.Getpid() {
		return true
	}
	return name != "" && tunSelfExe != "" && strings.EqualFold(name, tunSelfExe)
}

func tunSplitApps(s string) []string {
	var out []string
	for _, f := range strings.FieldsFunc(s, func(r rune) bool { return r == ',' || r == ';' || r == '\n' || r == '\r' }) {
		if f = strings.TrimSpace(f); f != "" {
			out = append(out, f)
		}
	}
	return out
}

func tunAppMatch(app string, list []string) bool {
	if app == "" {
		return false
	}
	a := strings.TrimSuffix(strings.ToLower(app), ".exe")
	for _, x := range list {
		if strings.TrimSuffix(strings.ToLower(strings.TrimSpace(x)), ".exe") == a {
			return true
		}
	}
	return false
}

// ---------- sniffing ----------

var tunHTTPMethods = []string{"GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS ", "PATCH ", "CONNECT ", "TRACE "}

func tunLooksHTTP(b []byte) bool {
	for _, m := range tunHTTPMethods {
		if bytes.HasPrefix(b, []byte(m)) {
			return true
		}
	}
	return false
}

func tunCleanHost(h string) string {
	h = strings.Trim(strings.TrimSuffix(strings.ToLower(strings.TrimSpace(h)), "."), "[]")
	if h == "" || len(h) > 253 || strings.ContainsAny(h, " /\\\x00") {
		return ""
	}
	return h
}

// sniffHost returns the TLS SNI or the HTTP Host of the first client bytes.
func sniffHost(b []byte) string {
	if len(b) == 0 {
		return ""
	}
	if b[0] == 0x16 {
		return tunCleanHost(parseSNI(b))
	}
	if !tunLooksHTTP(b) {
		return ""
	}
	lines := bytes.Split(b, []byte("\r\n"))
	for _, line := range lines[1:] {
		if len(line) == 0 {
			break
		}
		if len(line) > 5 && strings.EqualFold(string(line[:5]), "host:") {
			h := strings.TrimSpace(string(line[5:]))
			if hh, _, err := net.SplitHostPort(h); err == nil {
				h = hh
			}
			return tunCleanHost(h)
		}
	}
	return ""
}

// sniffWantMore: the ClientHello or the HTTP headers are not complete yet.
func sniffWantMore(b []byte) bool {
	if len(b) == 0 {
		return true
	}
	if b[0] == 0x16 {
		if len(b) < 5 {
			return true
		}
		need := 5 + (int(b[3])<<8 | int(b[4]))
		return len(b) < need && len(b) < 16<<10
	}
	if tunLooksHTTP(b) {
		return !bytes.Contains(b, []byte("\r\n\r\n")) && len(b) < 8<<10
	}
	return false
}

// tunServerFirst: protocols where the server speaks first, waiting for the
// client would only add delay.
func tunServerFirst(port int) bool {
	switch port {
	case 21, 22, 23, 25, 110, 143, 587, 3306:
		return true
	}
	return false
}

// ---------- reverse DNS map: IP -> domain from our own DNS answers ----------

type revEntry struct {
	name string
	exp  time.Time
}

type revMap struct {
	mu sync.Mutex
	m  map[netip.Addr]revEntry
}

func (r *revMap) put(ip net.IP, name string, ttl time.Duration) {
	a, ok := netip.AddrFromSlice(ip)
	if !ok || name == "" {
		return
	}
	a = a.Unmap()
	now := time.Now()
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.m == nil {
		r.m = map[netip.Addr]revEntry{}
	}
	if len(r.m) > 20000 {
		for k, v := range r.m {
			if now.After(v.exp) {
				delete(r.m, k)
			}
		}
		if len(r.m) > 20000 {
			r.m = map[netip.Addr]revEntry{}
		}
	}
	r.m[a] = revEntry{name, now.Add(ttl)}
}

func (r *revMap) get(a netip.Addr) string {
	r.mu.Lock()
	defer r.mu.Unlock()
	e, ok := r.m[a.Unmap()]
	if !ok || time.Now().After(e.exp) {
		return ""
	}
	return e.name
}

// ---------- DNS helpers ----------

// dnsQName returns the first question name and the offset right after the
// question (end < 0: not a valid query).
func dnsQName(q []byte) (name string, end int) {
	if len(q) < 12 || binary.BigEndian.Uint16(q[4:]) == 0 {
		return "", -1
	}
	off := 12
	var sb strings.Builder
	for {
		if off >= len(q) {
			return "", -1
		}
		l := int(q[off])
		off++
		if l == 0 {
			break
		}
		if l&0xc0 != 0 || off+l > len(q) {
			return "", -1
		}
		if sb.Len() > 0 {
			sb.WriteByte('.')
		}
		sb.Write(q[off : off+l])
		off += l
	}
	if off+4 > len(q) {
		return "", -1
	}
	return strings.ToLower(sb.String()), off + 4
}

// dnsServfail builds a SERVFAIL answer so programs do not wait for a timeout.
func dnsServfail(q []byte) []byte {
	_, end := dnsQName(q)
	if end < 0 {
		return nil
	}
	r := append([]byte(nil), q[:end]...)
	r[2] = q[2]&0x79 | 0x80 // QR, keep opcode and RD
	r[3] = 0x80 | 2         // RA, SERVFAIL
	binary.BigEndian.PutUint16(r[4:], 1)
	for i := 6; i < 12; i++ {
		r[i] = 0
	}
	return r
}
