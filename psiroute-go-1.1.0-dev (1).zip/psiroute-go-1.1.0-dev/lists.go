package main

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// Address lists ("подписки"): a rule may reference lists of domains / IPs /
// subnets that are downloaded automatically from trusted HTTPS sources,
// cached next to the program and refreshed in the background. A rule with
// lists:["ru-blocked"] matches every address from that list, so hundreds of
// sites go through one route (for example "psiphon:DE") with one rule.

// listPresets are short names for well-known lists. Any https URL on a
// trusted host can be used directly as well.
var listPresets = map[string]string{
	"ru-blocked":           "https://raw.githubusercontent.com/itdoginfo/allow-domains/main/Russia/inside-raw.lst",
	"antifilter-community": "https://community.antifilter.download/list/domains.lst",
	"antifilter-ip":        "https://antifilter.download/list/allyouneed.lst",
	"youtube":              "https://raw.githubusercontent.com/itdoginfo/allow-domains/main/Services/youtube.lst",
	"discord":              "https://raw.githubusercontent.com/itdoginfo/allow-domains/main/Services/discord.lst",
	"telegram-ip":          "https://raw.githubusercontent.com/itdoginfo/allow-domains/main/Subnets/IPv4/telegram.lst",
}

// listTrustedHosts: lists are only fetched from these hosts, only over
// HTTPS with normal certificate verification. A list can redirect traffic,
// so it must not come from an arbitrary place.
var listTrustedHosts = []string{
	"raw.githubusercontent.com",
	"antifilter.download",
	"community.antifilter.download",
	"iplist.opencck.org",
}

const (
	listMaxBytes = 32 << 20
	listRefresh  = 24 * time.Hour
	listRetry    = 30 * time.Minute
)

// resolveListURL turns a preset name or URL into a checked https URL.
func resolveListURL(s string) (string, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return "", errors.New("пустой список")
	}
	if u, ok := listPresets[strings.ToLower(s)]; ok {
		return u, nil
	}
	u, err := url.Parse(s)
	if err != nil || u.Scheme != "https" || u.Host == "" {
		return "", fmt.Errorf("%s: нужен https-адрес или имя готового списка", s)
	}
	h := strings.ToLower(u.Hostname())
	for _, t := range listTrustedHosts {
		if h == t {
			return u.String(), nil
		}
	}
	return "", fmt.Errorf("%s: источник не в списке надёжных (%s)", h, strings.Join(listTrustedHosts, ", "))
}

type listData struct {
	domains  map[string]struct{}
	prefixes []netip.Prefix
	updated  time.Time
	tried    time.Time
	err      string
}

// parseList accepts plain domains, *.domain / .domain, IPs and CIDRs, one
// per line; # // ! ; start comments. Unknown lines are skipped.
func parseList(r io.Reader) *listData {
	d := &listData{domains: map[string]struct{}{}}
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 64<<10), 1<<20)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if i := strings.IndexAny(line, "#;!"); i >= 0 {
			line = line[:i]
		}
		if i := strings.Index(line, "//"); i >= 0 {
			line = line[:i]
		}
		line = strings.TrimSpace(line)
		if f := strings.Fields(line); len(f) > 0 {
			line = f[0] // "domain comment" or hosts-like lines keep the first token
		} else {
			continue
		}
		line = strings.TrimPrefix(line, "domain:")
		line = strings.TrimPrefix(line, "full:")
		if p, err := netip.ParsePrefix(line); err == nil {
			d.prefixes = append(d.prefixes, p.Masked())
			continue
		}
		if a, err := netip.ParseAddr(line); err == nil {
			d.prefixes = append(d.prefixes, netip.PrefixFrom(a, a.BitLen()))
			continue
		}
		line = strings.ToLower(strings.TrimSuffix(strings.TrimPrefix(strings.TrimPrefix(line, "*"), "."), "."))
		if validListDomain(line) {
			d.domains[line] = struct{}{}
		}
	}
	if err := sc.Err(); err != nil {
		logf("warn", "Список прочитан не полностью: %v", err)
	}
	sort.Slice(d.prefixes, func(i, j int) bool { return d.prefixes[i].Bits() > d.prefixes[j].Bits() })
	return d
}

func validListDomain(s string) bool {
	if len(s) < 2 || len(s) > 253 || !strings.Contains(s, ".") {
		return false
	}
	for _, c := range s {
		if !(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '-' || c == '.' || c == '_' || c > 127) {
			return false
		}
	}
	return true
}

func (d *listData) match(host string, ip netip.Addr) bool {
	if d == nil {
		return false
	}
	if ip.IsValid() {
		ip = ip.Unmap()
		for _, p := range d.prefixes {
			if p.Contains(ip) {
				return true
			}
		}
		return false
	}
	// host and every parent domain: a.b.example.com, b.example.com, example.com
	for h := host; h != ""; {
		if _, ok := d.domains[h]; ok {
			return true
		}
		i := strings.IndexByte(h, '.')
		if i < 0 {
			break
		}
		h = h[i+1:]
	}
	return false
}

// Lists downloads, caches and serves address lists.
type Lists struct {
	app  *App
	dir  string
	mu   sync.RWMutex
	data map[string]*listData // by resolved URL
	kick chan struct{}
}

func newLists(app *App, dir string) *Lists {
	return &Lists{app: app, dir: dir, data: map[string]*listData{}, kick: make(chan struct{}, 1)}
}

func (l *Lists) file(u string) string {
	h := sha256.Sum256([]byte(u))
	return filepath.Join(l.dir, hex.EncodeToString(h[:8])+".lst")
}

// wanted returns every list URL referenced by the rules.
func (l *Lists) wanted() []string {
	l.app.cfg.mu.Lock()
	defer l.app.cfg.mu.Unlock()
	seen := map[string]bool{}
	out := []string{}
	for _, ru := range l.app.cfg.Routing.Rules {
		for _, s := range ru.Lists {
			if u, err := resolveListURL(s); err == nil && !seen[u] {
				seen[u] = true
				out = append(out, u)
			}
		}
	}
	return out
}

// Refresh asks the background loop to check the lists now (after rules change).
func (l *Lists) Refresh() {
	select {
	case l.kick <- struct{}{}:
	default:
	}
}

// Start loads cached copies immediately and keeps lists fresh.
func (l *Lists) Start(ctx context.Context) {
	_ = os.MkdirAll(l.dir, 0o700)
	for _, u := range l.wanted() {
		l.loadCache(u)
	}
	go func() {
		t := time.NewTicker(10 * time.Minute)
		defer t.Stop()
		select { // give Psiphon a moment so blocked sources can go through it
		case <-ctx.Done():
			return
		case <-time.After(5 * time.Second):
		}
		for {
			l.updateDue(ctx)
			select {
			case <-ctx.Done():
				return
			case <-t.C:
			case <-l.kick:
			}
		}
	}()
}

func (l *Lists) loadCache(u string) {
	f, err := os.Open(l.file(u))
	if err != nil {
		return
	}
	defer f.Close()
	d := parseList(f)
	if st, err := f.Stat(); err == nil {
		d.updated = st.ModTime()
	}
	l.mu.Lock()
	if l.data[u] == nil {
		l.data[u] = d
	}
	l.mu.Unlock()
}

func (l *Lists) updateDue(ctx context.Context) {
	for _, u := range l.wanted() {
		l.mu.RLock()
		d := l.data[u]
		l.mu.RUnlock()
		if d == nil {
			l.loadCache(u)
			l.mu.RLock()
			d = l.data[u]
			l.mu.RUnlock()
		}
		if d != nil && (time.Since(d.updated) < listRefresh || time.Since(d.tried) < listRetry) {
			continue
		}
		if ctx.Err() != nil {
			return
		}
		l.update(ctx, u)
	}
}

// update downloads one list: directly first, then through Psiphon (the
// source itself may be blocked). TLS is always verified.
func (l *Lists) update(ctx context.Context, u string) {
	var body []byte
	var err error
	via := ""
	for _, ob := range []string{obDirect, obPsiphon} {
		body, err = l.fetch(ctx, u, ob)
		if err == nil {
			via = ob
			break
		}
	}
	l.mu.Lock()
	old := l.data[u]
	if err != nil {
		if old == nil {
			old = &listData{domains: map[string]struct{}{}}
			l.data[u] = old
		}
		old.tried = time.Now()
		old.err = short(err.Error(), 160)
		l.mu.Unlock()
		logf("warn", "Список %s не скачался: %s (используется сохранённая копия, если есть)", u, short(err.Error(), 120))
		return
	}
	l.mu.Unlock()
	d := parseList(strings.NewReader(string(body)))
	if len(d.domains)+len(d.prefixes) == 0 {
		l.mu.Lock()
		if old != nil {
			old.tried, old.err = time.Now(), "скачан пустой или непонятный файл"
		}
		l.mu.Unlock()
		logf("warn", "Список %s: в файле нет адресов, оставляю прежний", u)
		return
	}
	d.updated, d.tried = time.Now(), time.Now()
	tmp := l.file(u) + ".tmp"
	if os.WriteFile(tmp, body, 0o600) == nil {
		_ = os.Rename(tmp, l.file(u))
	}
	l.mu.Lock()
	l.data[u] = d
	l.mu.Unlock()
	logf("info", "Список обновлён (%s): %d доменов, %d подсетей — %s", via, len(d.domains), len(d.prefixes), u)
}

func (l *Lists) fetch(ctx context.Context, u, ob string) ([]byte, error) {
	dial := l.app.router.dialer(ob)
	tr := &http.Transport{
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			return dial(ctx, network, addr)
		},
		TLSHandshakeTimeout: 15 * time.Second,
		ForceAttemptHTTP2:   true,
	}
	defer tr.CloseIdleConnections()
	cl := &http.Client{Transport: tr, Timeout: 90 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) > 3 {
				return errors.New("слишком много перенаправлений")
			}
			_, err := resolveListURL(req.URL.String()) // a redirect must stay on trusted hosts
			return err
		}}
	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "psiroute/"+version)
	resp, err := cl.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, listMaxBytes+1))
	if err != nil {
		return nil, err
	}
	if len(b) > listMaxBytes {
		return nil, errors.New("файл больше 32 МБ")
	}
	return b, nil
}

// Match reports whether host (already cleaned, lower-case) or its IP is in
// any of the given lists.
func (l *Lists) Match(lists []string, host string) bool {
	return l.MatchIPs(lists, host, nil)
}

// MatchIPs checks both the host name and any known resolved/destination IPs
// against the given lists.
func (l *Lists) MatchIPs(lists []string, host string, ips []net.IP) bool {
	if l == nil || len(lists) == 0 {
		return false
	}
	ip, _ := netip.ParseAddr(host)
	var addrs []netip.Addr
	if ip.IsValid() {
		addrs = append(addrs, ip.Unmap())
	}
	for _, x := range ips {
		if a, ok := netip.AddrFromSlice(x); ok {
			addrs = append(addrs, a.Unmap())
		}
	}
	l.mu.RLock()
	defer l.mu.RUnlock()
	for _, s := range lists {
		u, err := resolveListURL(s)
		if err != nil {
			continue
		}
		d := l.data[u]
		if d == nil {
			continue
		}
		if !ip.IsValid() && d.match(host, netip.Addr{}) {
			return true
		}
		for _, a := range addrs {
			if d.match("", a) {
				return true
			}
		}
	}
	return false
}

// Status is shown in the UI.
func (l *Lists) Status() []map[string]any {
	out := []map[string]any{}
	for _, u := range l.wanted() {
		l.mu.RLock()
		d := l.data[u]
		l.mu.RUnlock()
		m := map[string]any{"url": u, "domains": 0, "subnets": 0, "updated": int64(0), "error": ""}
		if d != nil {
			m["domains"], m["subnets"], m["error"] = len(d.domains), len(d.prefixes), d.err
			if !d.updated.IsZero() {
				m["updated"] = d.updated.Unix()
			}
		}
		out = append(out, m)
	}
	return out
}
