package main

import (
	"bufio"
	"context"
	"encoding/binary"

	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Per-rule exit country. tunnel-core allows one controller (one egress
// region) per process, so the outbound "psiphon:DE" is served by a separate
// worker process with its own Psiphon data and a local SOCKS5 port. Workers
// start on first use and stop after 15 minutes without traffic.

const countryIdle = 5 * time.Minute

// countryOf returns "DE" for "psiphon:de".
func countryOf(ob string) (string, bool) {
	if !strings.HasPrefix(ob, obPsiphon+":") {
		return "", false
	}
	cc := strings.ToUpper(strings.TrimSpace(ob[len(obPsiphon)+1:]))
	if len(cc) != 2 || cc[0] < 'A' || cc[0] > 'Z' || cc[1] < 'A' || cc[1] > 'Z' {
		return "", false
	}
	return cc, true
}

func isCountryOb(ob string) bool { _, ok := countryOf(ob); return ok }

// countryChoices fills the route dropdowns in the UI.
var countryChoices = []string{"DE", "NL", "FI", "SE", "FR", "GB", "US", "CA", "PL", "AT", "CH", "JP", "SG"}

type countryWorker struct {
	cc      string
	cmd     *exec.Cmd
	stdin   io.Closer
	mu      sync.Mutex
	addr    string // SOCKS5 of the worker, "" until it reports
	state   string
	egress  string
	lastUse time.Time
	done    chan struct{}
}

type Countries struct {
	app *App
	mu  sync.Mutex
	w   map[string]*countryWorker
}

func newCountries(app *App) *Countries { return &Countries{app: app, w: map[string]*countryWorker{}} }

func (c *Countries) Start(ctx context.Context) {
	go func() {
		t := time.NewTicker(time.Minute)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				c.StopAll()
				return
			case <-t.C:
				c.mu.Lock()
				for cc, w := range c.w {
					w.mu.Lock()
					idle := time.Since(w.lastUse) > countryIdle
					w.mu.Unlock()
					if idle {
						logf("info", "Psiphon %s: не используется, останавливаю", cc)
						w.stop()
						delete(c.w, cc)
					}
				}
				c.mu.Unlock()
			}
		}
	}()
}

func (c *Countries) StopAll() {
	c.mu.Lock()
	defer c.mu.Unlock()
	for cc, w := range c.w {
		w.stop()
		delete(c.w, cc)
	}
}

func (w *countryWorker) stop() {
	if w.stdin != nil {
		_ = w.stdin.Close() // worker exits when its stdin closes
	}
	select {
	case <-w.done:
	case <-time.After(5 * time.Second):
		if w.cmd != nil && w.cmd.Process != nil {
			_ = w.cmd.Process.Kill()
		}
	}
}

// Status for the UI.
func (c *Countries) Status() []map[string]any {
	c.mu.Lock()
	defer c.mu.Unlock()
	out := []map[string]any{}
	for cc, w := range c.w {
		w.mu.Lock()
		out = append(out, map[string]any{"country": cc, "state": w.state, "egress": w.egress})
		w.mu.Unlock()
	}
	return out
}

func (c *Countries) get(cc string) (*countryWorker, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if w := c.w[cc]; w != nil {
		select {
		case <-w.done:
			delete(c.w, cc) // crashed: start again
		default:
			return w, nil
		}
	}
	if c.app.ctx.Err() != nil {
		return nil, c.app.ctx.Err()
	}
	exe, err := os.Executable()
	if err != nil {
		return nil, err
	}
	dir := filepath.Join(c.app.dataDir, "country-"+cc)
	seedPsiphonData(filepath.Join(c.app.dataDir, "psiphon"), filepath.Join(dir, "psiphon"))
	cmd := exec.Command(exe, "--psi-worker", "--worker-dir", dir, "--worker-region", cc, "--config", c.app.cfgPath)
	hideConsole(cmd)
	in, err := cmd.StdinPipe()
	if err != nil {
		return nil, err
	}
	out, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	cmd.Stderr = cmd.Stdout
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	w := &countryWorker{cc: cc, cmd: cmd, stdin: in, state: "connecting", lastUse: time.Now(), done: make(chan struct{})}
	c.w[cc] = w
	logf("info", "Psiphon %s: запускаю отдельное подключение для этой страны", cc)
	go func() {
		sc := bufio.NewScanner(out)
		for sc.Scan() {
			line := sc.Text()
			switch {
			case strings.HasPrefix(line, "@listen "):
				w.mu.Lock()
				w.addr = strings.TrimSpace(line[8:])
				w.mu.Unlock()
			case strings.HasPrefix(line, "@state "):
				f := strings.Fields(line[7:])
				w.mu.Lock()
				if len(f) > 0 {
					w.state = f[0]
				}
				if len(f) > 1 {
					w.egress = f[1]
				}
				w.mu.Unlock()
			case strings.HasPrefix(line, "@log "):
				lv, msg, _ := strings.Cut(line[5:], " ")
				logf(lv, "[%s] %s", cc, msg)
			}
		}
		if err := sc.Err(); err != nil {
			logf("warn", "Psiphon %s: связь с процессом прервалась: %v", cc, err)
		}
		_ = cmd.Wait()
		w.mu.Lock()
		w.state, w.addr = "stopped", ""
		w.mu.Unlock()
		close(w.done)
	}()
	return w, nil
}

// Dial goes out through the worker for country cc. While the worker is
// still connecting it waits up to 25 seconds, like the main Psiphon dialer.
func (c *Countries) Dial(ctx context.Context, cc, addr string) (net.Conn, error) {
	w, err := c.get(cc)
	if err != nil {
		return nil, err
	}
	deadline := time.Now().Add(25 * time.Second)
	for {
		w.mu.Lock()
		w.lastUse = time.Now()
		socks, state := w.addr, w.state
		w.mu.Unlock()
		if socks != "" && state == "connected" {
			return dialSocks5(ctx, socks, addr, "", "")
		}
		if time.Now().After(deadline) {
			return nil, fmt.Errorf("Psiphon %s ещё подключается", cc)
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-w.done:
			return nil, fmt.Errorf("Psiphon %s: процесс завершился", cc)
		case <-time.After(300 * time.Millisecond):
		}
	}
}

// seedPsiphonData copies the main server-list database into a new worker
// directory once, so the worker does not have to download the server list
// (that download is often blocked). Best effort: a locked file is skipped.
func seedPsiphonData(from, to string) {
	if _, err := os.Stat(to); err == nil {
		return
	}
	_ = filepath.Walk(from, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		rel, rerr := filepath.Rel(from, p)
		if rerr != nil {
			return nil
		}
		dst := filepath.Join(to, rel)
		if info.IsDir() {
			_ = os.MkdirAll(dst, 0o700)
			return nil
		}
		if strings.HasSuffix(p, ".lock") || info.Size() > 256<<20 {
			return nil
		}
		if b, err := os.ReadFile(p); err == nil {
			_ = os.WriteFile(dst, b, 0o600)
		}
		return nil
	})
	_ = os.MkdirAll(to, 0o700)
}

// ---- worker process ----

// runPsiWorker is the child process: one Psiphon with a fixed exit country
// and a local SOCKS5 server (127.0.0.1, random port) for the parent only.
func runPsiWorker(cfgPath, dir, region string) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go func() { _, _ = io.Copy(io.Discard, os.Stdin); cancel() }() // parent gone -> exit
	_ = os.MkdirAll(dir, 0o700)

	a := NewApp(ctx, cancel, cfgPath, dir)
	a.cfg.mu.Lock()
	a.cfg.path = "" // never write the user's config from a worker
	a.cfg.Psiphon.Country = region
	a.cfg.Psiphon.Standby = false
	if a.cfg.Psiphon.Parallel > 2 {
		a.cfg.Psiphon.Parallel = 2
	}
	a.cfg.mu.Unlock()

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		fmt.Println("@log error", err)
		return
	}
	defer ln.Close()
	fmt.Println("@listen", ln.Addr().String())

	// forward the worker journal to the parent
	go func() {
		sent := 0
		last := ""
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
			}
			lines := theLog.snapshot()
			if sent > len(lines) {
				sent = 0
			}
			for _, l := range lines[sent:] {
				fmt.Println("@log", l.Level, strings.ReplaceAll(l.Msg, "\n", " "))
			}
			sent = len(lines)
			a.psi.mu.Lock()
			st := a.psi.state + " " + a.psi.egress
			a.psi.mu.Unlock()
			if st != last {
				fmt.Println("@state", st)
				last = st
			}
		}
	}()

	a.psi.Start()
	go func() { <-ctx.Done(); ln.Close() }()
	for {
		c, err := ln.Accept()
		if err != nil {
			break
		}
		go serveWorkerSocks(ctx, c, a.psi.Dial)
	}
	a.psi.Stop()
}

// serveWorkerSocks is a minimal SOCKS5 CONNECT server (no auth). It only
// listens on 127.0.0.1 and is used by the parent process.
func serveWorkerSocks(ctx context.Context, c net.Conn, dial dialFunc) {
	defer c.Close()
	_ = c.SetDeadline(time.Now().Add(40 * time.Second))
	br := bufio.NewReader(c)
	hdr := make([]byte, 2)
	if _, err := io.ReadFull(br, hdr); err != nil || hdr[0] != 5 {
		return
	}
	if _, err := io.ReadFull(br, make([]byte, int(hdr[1]))); err != nil {
		return
	}
	_, _ = c.Write([]byte{5, 0})
	req := make([]byte, 4)
	if _, err := io.ReadFull(br, req); err != nil || req[1] != 1 {
		_, _ = c.Write([]byte{5, 7, 0, 1, 0, 0, 0, 0, 0, 0})
		return
	}
	var host string
	switch req[3] {
	case 1:
		b := make([]byte, 4)
		if _, err := io.ReadFull(br, b); err != nil {
			return
		}
		host = net.IP(b).String()
	case 4:
		b := make([]byte, 16)
		if _, err := io.ReadFull(br, b); err != nil {
			return
		}
		host = net.IP(b).String()
	case 3:
		l, err := br.ReadByte()
		if err != nil {
			return
		}
		b := make([]byte, int(l))
		if _, err := io.ReadFull(br, b); err != nil {
			return
		}
		host = string(b)
	default:
		return
	}
	pb := make([]byte, 2)
	if _, err := io.ReadFull(br, pb); err != nil {
		return
	}
	addr := net.JoinHostPort(host, strconv.Itoa(int(binary.BigEndian.Uint16(pb))))
	dctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	up, err := dial(dctx, "tcp", addr)
	cancel()
	if err != nil {
		_, _ = c.Write([]byte{5, 5, 0, 1, 0, 0, 0, 0, 0, 0})
		return
	}
	defer up.Close()
	if _, err := c.Write([]byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0}); err != nil {
		return
	}
	_ = c.SetDeadline(time.Time{})
	errc := make(chan error, 2)
	go func() { _, err := io.Copy(up, br); errc <- err }()
	go func() { _, err := io.Copy(c, up); errc <- err }()
	<-errc
}
