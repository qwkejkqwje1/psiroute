package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"net/http"
	_ "net/http/pprof"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
)

const version = "1.1.0-dev"

// crashRestarts: how many times the watchdog restarted the core after a crash.
var crashRestarts int

// dataDir: next to the exe (portable) if writable, otherwise the user's
// config folder.
func dataDirFor() string {
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		if f, err := os.CreateTemp(dir, ".psiroute-w"); err == nil {
			f.Close()
			os.Remove(f.Name())
			return dir
		}
	}
	base, err := os.UserConfigDir()
	if err != nil {
		base = "."
	}
	d := filepath.Join(base, "Psiroute")
	_ = os.MkdirAll(d, 0o700)
	return d
}

func main() {
	cfgFlag := flag.String("config", "", "путь к psiroute.json")
	noGUI := flag.Bool("no-gui", false, "без окна и трея (интерфейс в браузере)")
	minimized := flag.Bool("minimized", false, "запуск в фоне, только значок в трее (автозапуск)")
	window := flag.String("window", "", "internal: window process for this UI address")
	parent := flag.Int("parent", 0, "internal")
	probe := flag.Bool("probe", false, "internal: DPI probe worker")
	probeDir := flag.String("probe-dir", "", "internal")
	probeRegion := flag.String("probe-region", "", "internal")
	psiWorker := flag.Bool("psi-worker", false, "internal: Psiphon worker for one exit country")
	workerDir := flag.String("worker-dir", "", "internal")
	workerRegion := flag.String("worker-region", "", "internal")
	pprofAddr := flag.String("pprof", "", "test: pprof address, e.g. 127.0.0.1:6060")
	showVer := flag.Bool("version", false, "версия")
	selftest := flag.Bool("selftest", false, "самопроверка: отчёт в psiroute-selftest.txt")
	noWatch := flag.Bool("no-watchdog", false, "без сторожа (не перезапускать после сбоя)")
	core := flag.Bool("core", false, "internal: started by the watchdog")
	restarts := flag.Int("restarts", 0, "internal")
	waitPID := flag.Int("wait-pid", 0, "internal: дождаться выхода прежней копии (перезапуск от администратора)")
	flag.Parse()
	if *waitPID > 0 {
		waitForPID(*waitPID)
	}

	if *showVer {
		fmt.Println("psiroute", version)
		return
	}
	setupMemory() // every process: core, window, country workers, probe
	if *psiWorker {
		runPsiWorker(*cfgFlag, *workerDir, *workerRegion)
		return
	}
	if *probe {
		runProbe(*probeDir, *probeRegion)
		return
	}
	dir := dataDirFor()
	if *window != "" {
		runWindowProcess(dir, *window, *parent)
		return
	}
	if *selftest {
		os.Exit(runSelftestCLI(dir))
	}
	// The watchdog: a tiny parent that restarts the core after a crash (Go
	// panics outside a recover, fatal runtime errors). --no-gui runs are
	// usually supervised by something else and stay single-process.
	if !*core && !*noWatch && !*noGUI && *pprofAddr == "" {
		if code, ran := runWatchdog(dir); ran {
			os.Exit(code)
		}
	}
	if *core {
		watchdogPID = os.Getppid()
		crashRestarts = *restarts
	}
	crash := findCrash(dir)
	setupCrashOutput(dir)
	if *pprofAddr != "" {
		go func() { _ = http.ListenAndServe(*pprofAddr, nil) }() // profiling for tests only; UI uses its own handler
	}

	path := *cfgFlag
	if path == "" {
		path = filepath.Join(dir, "psiroute.json")
	}
	sigCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	ctx, cancel := context.WithCancel(sigCtx)
	defer cancel()

	a := NewApp(ctx, cancel, path, dir)
	if err := a.Start(); err != nil {
		if errors.Is(err, errAlreadyRunning) {
			// Second launch: show the window of the running instance.
			if !*noGUI {
				runWindowProcess(dir, a.uiURL(), 0)
			}
			return
		}
		fmt.Fprintln(os.Stderr, "psiroute:", err)
		if !*noGUI {
			showFatal("Psiroute не запустился:\n\n" + err.Error()) // -H windowsgui has no console
		}
		os.Exit(1)
	}
	if err := theLog.openFile(filepath.Join(dir, "psiroute.log")); err != nil {
		logf("warn", "Журнал не записывается в файл: %v", err)
	}
	defer theLog.closeFile()
	if crash.unseen {
		logf("warn", "Прошлый запуск завершился сбоем (%s): %s — подробности в crash.log", crash.At.Format("02.01 15:04"), crash.Headline)
		crash.markSeen(dir)
	}
	if crashRestarts > 0 {
		logf("warn", "Psiroute перезапущен после сбоя (%d-й раз подряд)", crashRestarts)
	}
	if _, err := os.Stat(path); err != nil {
		_ = a.cfg.save() // first run: write defaults so the file can be edited
	}
	if *noGUI {
		fmt.Println("Psiroute запущен, интерфейс:", a.uiURL())
		<-ctx.Done()
	} else {
		// Tray icon in this process; the window is a separate process that
		// takes its WebView2 memory with it when closed.
		runDesktop(ctx, a, dir, !*minimized)
	}
	a.Shutdown()
}
