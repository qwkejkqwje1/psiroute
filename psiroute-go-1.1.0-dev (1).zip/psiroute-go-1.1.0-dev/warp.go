package main

// Built-in Cloudflare WARP as an underlay for Psiphon («Через WARP»): the
// provider sees a WireGuard flow to Cloudflare instead of a connection to
// Psiphon. Only what Psiphon needs is taken from ProxyDesk's WARP helper: a
// free device, handshake masking (a signature packet I1 that looks like QUIC
// or DNS plus junk packets before every handshake), a node outside the
// filtered countries, a fresh UDP flow when the network cuts the old one and
// a local SOCKS5 port for Psiphon. There is no extra program: the tunnel runs
// in-process (wireguard-go and gVisor's netstack: both modules are already in
// tunnel-core's dependency graph, the exe grows by a few MB), opens on first
// use and closes after warpIdle unused.
// This file: the device and the masking; warptun.go: the tunnel;
// warpsvc.go: the service and its SOCKS5 port.

import (
	"bytes"
	"crypto/ecdh"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	mrand "math/rand/v2"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const (
	warpAPI    = "https://api.cloudflareclient.com/v0a4005"
	warpMTU    = 1280             // WARP's own MTU
	warpIdle   = 10 * time.Minute // unused this long: the tunnel closes
	warpSearch = 30 * time.Second // search for a node abroad once a tunnel works
)

var warpHeaders = map[string]string{"User-Agent": "okhttp/3.12.1", "CF-Client-Version": "a-6.30-3596"}

// ---------- device (warp-identity.json in the data directory) ----------

type warpIdentity struct {
	PrivateKey string `json:"private_key"`
	ID         string `json:"id"`
	Token      string `json:"token"`
	ClientID   string `json:"client_id"`
	V4         string `json:"v4"`
	V6         string `json:"v6"`
	PeerKey    string `json:"peer_public_key"`
	PeerHost   string `json:"peer_host"`
	Account    string `json:"account_type"`
	Endpoint   string `json:"endpoint,omitempty"` // the endpoint that worked last
	Colo       string `json:"colo,omitempty"`     // its data center
	Mask       string `json:"mask,omitempty"`     // the masking that worked
	Created    int64  `json:"created"`
}

type warpRegResp struct {
	ID     string `json:"id"`
	Token  string `json:"token"`
	Config struct {
		ClientID string `json:"client_id"`
		Peers    []struct {
			PublicKey string `json:"public_key"`
			Endpoint  struct {
				Host string `json:"host"`
			} `json:"endpoint"`
		} `json:"peers"`
		Interface struct {
			Addresses struct {
				V4 string `json:"v4"`
				V6 string `json:"v6"`
			} `json:"addresses"`
		} `json:"interface"`
	} `json:"config"`
	Account struct {
		AccountType string `json:"account_type"`
	} `json:"account"`
}

func loadWarpIdentity(path string) (*warpIdentity, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var id warpIdentity
	if err := json.Unmarshal(b, &id); err != nil {
		return nil, err
	}
	if id.PrivateKey == "" || id.PeerKey == "" || id.V4 == "" {
		return nil, errors.New("неполные данные WARP")
	}
	return &id, nil
}

func saveWarpIdentity(path string, id *warpIdentity) error {
	b, _ := json.MarshalIndent(id, "", "  ")
	_ = os.MkdirAll(filepath.Dir(path), 0o700)
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// warpAPIDo calls the registration API through the first client that
// reaches it.
func warpAPIDo(clients []*http.Client, method, path, token string, body any) ([]byte, error) {
	var last error
	for i, c := range clients {
		var rd io.Reader
		if body != nil {
			b, _ := json.Marshal(body)
			rd = bytes.NewReader(b)
		}
		req, err := http.NewRequest(method, warpAPI+path, rd)
		if err != nil {
			return nil, err
		}
		req.Header.Set("Content-Type", "application/json; charset=UTF-8")
		for k, v := range warpHeaders {
			req.Header.Set(k, v)
		}
		if token != "" {
			req.Header.Set("Authorization", "Bearer "+token)
		}
		resp, err := c.Do(req)
		if err != nil {
			last = err
			if i == 0 && len(clients) > 1 {
				logf("warn", "WARP: API Cloudflare напрямую недоступен (%s), пробую в обход", short(err.Error(), 120))
			}
			continue
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		resp.Body.Close()
		if resp.StatusCode/100 != 2 {
			return nil, fmt.Errorf("API Cloudflare: %s: %.200s", resp.Status, b)
		}
		return b, nil
	}
	return nil, fmt.Errorf("API Cloudflare недоступен: %w", last)
}

// warpRegister creates a free WARP device.
func warpRegister(clients []*http.Client) (*warpIdentity, error) {
	priv, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	body := map[string]any{
		"install_id": "", "fcm_token": "", "tos": time.Now().UTC().Format(time.RFC3339Nano),
		"key":  base64.StdEncoding.EncodeToString(priv.PublicKey().Bytes()),
		"type": "Android", "model": "PC", "locale": "en_US", "warp_enabled": true,
	}
	b, err := warpAPIDo(clients, "POST", "/reg", "", body)
	if err != nil {
		return nil, err
	}
	var r warpRegResp
	if err := json.Unmarshal(b, &r); err != nil {
		return nil, err
	}
	if len(r.Config.Peers) == 0 || r.Config.Interface.Addresses.V4 == "" {
		return nil, errors.New("API Cloudflare вернул неполные данные")
	}
	return &warpIdentity{
		PrivateKey: base64.StdEncoding.EncodeToString(priv.Bytes()), ID: r.ID, Token: r.Token,
		ClientID: r.Config.ClientID, V4: r.Config.Interface.Addresses.V4, V6: r.Config.Interface.Addresses.V6,
		PeerKey: r.Config.Peers[0].PublicKey, PeerHost: r.Config.Peers[0].Endpoint.Host,
		Account: r.Account.AccountType, Created: time.Now().Unix(),
	}, nil
}

// ---------- handshake masking ----------

// warpMask is a masking preset: a signature packet and junk packets sent
// before every handshake so that the flow does not start like WireGuard.
type warpMask struct {
	ID, Title      string
	I1             string // signature packet, AmneziaWG syntax ("" = none)
	Jc, Jmin, Jmax int    // junk packets and their size range
}

// warpMaskOrder is what "auto" tries, after the masking that worked last.
var warpMaskOrder = []string{"quic", "bwg", "dns", "off"}

func makeWarpMask(id string) (warpMask, error) {
	switch id {
	case "quic":
		sig, _, err := genI1("quic", "www.google.com")
		return warpMask{ID: id, Title: "QUIC (как HTTP/3 к www.google.com)", I1: sig, Jc: 4, Jmin: 40, Jmax: 70}, err
	case "bwg":
		return warpMask{ID: id, Title: "как в bash-warp-generator", I1: bwgI1, Jc: 120, Jmin: 23, Jmax: 911}, nil
	case "dns":
		sig, _, err := genI1("dns", "icloud.com")
		return warpMask{ID: id, Title: "DNS-запрос (как warpscout)", I1: sig, Jc: 6, Jmin: 10, Jmax: 50}, err
	case "off":
		return warpMask{ID: id, Title: "без маскировки"}, nil
	}
	return warpMask{}, fmt.Errorf("неизвестная маскировка %q", id)
}

// warpSigPart is one tag of a signature packet: <b 0x…> bytes, <r N> random
// bytes, <rc N> random letters, <rd N> random digits, <t> unix time, <c> the
// packet counter.
type warpSigPart struct {
	kind string
	data []byte
	n    int
}

func parseWarpSig(s string) ([]warpSigPart, error) {
	var parts []warpSigPart
	s = strings.TrimSpace(s)
	for s != "" {
		if s[0] != '<' {
			return nil, fmt.Errorf("подпись: ожидался тег, а не %.20q", s)
		}
		end := strings.IndexByte(s, '>')
		if end < 0 {
			return nil, errors.New("подпись: тег не закрыт")
		}
		f := strings.Fields(s[1:end])
		s = strings.TrimSpace(s[end+1:])
		if len(f) == 0 {
			return nil, errors.New("подпись: пустой тег")
		}
		p := warpSigPart{kind: f[0]}
		switch f[0] {
		case "b":
			if len(f) != 2 {
				return nil, errors.New("подпись: <b> без данных")
			}
			b, err := hex.DecodeString(strings.TrimPrefix(strings.TrimPrefix(f[1], "0x"), "0X"))
			if err != nil {
				return nil, fmt.Errorf("подпись: %w", err)
			}
			p.data = b
		case "r", "rc", "rd":
			n := -1
			if len(f) == 2 {
				if v, err := strconv.Atoi(f[1]); err == nil {
					n = v
				}
			}
			if n < 0 || n > 1400 {
				return nil, fmt.Errorf("подпись: неверная длина в <%s>", strings.Join(f, " "))
			}
			p.n = n
		case "t", "c":
		default:
			return nil, fmt.Errorf("подпись: неизвестный тег <%s>", f[0])
		}
		parts = append(parts, p)
	}
	return parts, nil
}

func buildWarpSig(parts []warpSigPart, counter uint32) []byte {
	var out []byte
	for _, p := range parts {
		switch p.kind {
		case "b":
			out = append(out, p.data...)
		case "r":
			b := make([]byte, p.n)
			_, _ = rand.Read(b)
			out = append(out, b...)
		case "rc":
			for range p.n {
				out = append(out, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[mrand.IntN(52)])
			}
		case "rd":
			for range p.n {
				out = append(out, byte('0'+mrand.IntN(10)))
			}
		case "t":
			out = binary.BigEndian.AppendUint32(out, uint32(time.Now().Unix()))
		case "c":
			out = binary.BigEndian.AppendUint32(out, counter)
		}
	}
	return out
}
