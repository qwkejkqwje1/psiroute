package main

import (
	"bufio"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/Psiphon-Labs/psiphon-tunnel-core/psiphon"
	"github.com/Psiphon-Labs/psiphon-tunnel-core/psiphon/common/parameters"
)

// Psiphon runs in-process through tunnel-core (the same library the official
// clients use). This is the main reason for the move to Go: we control the
// fragmentor / TLS ClientHello split, tunnel protocols, upstream proxy,
// NetworkID rotation and dial through ctl.Dial without any local SOCKS port.

const psiRSLKey = "MIICIDANBgkqhkiG9w0BAQEFAAOCAg0AMIICCAKCAgEAt7Ls+/39r+T6zNW7GiVpJfzq/xvL9SBH5rIFnk0RXYEYavax3WS6HOD35eTAqn8AniOwiH+DOkvgSKF2caqk/y1dfq47Pdymtwzp9ikpB1C5OfAysXzBiwVJlCdajBKvBZDerV1cMvRzCKvKwRmvDmHgphQQ7WfXIGbRbmmk6opMBh3roE42KcotLFtqp0RRwLtcBRNtCdsrVsjiI1Lqz/lH+T61sGjSjQ3CHMuZYSQJZo/KrvzgQXpkaCTdbObxHqb6/+i1qaVOfEsvjoiyzTxJADvSytVtcTjijhPEV6XskJVHE1Zgl+7rATr/pDQkw6DPCNBS1+Y6fy7GstZALQXwEDN/qhQI9kWkHijT8ns+i1vGg00Mk/6J75arLhqcodWsdeG/M/moWgqQAnlZAGVtJI1OgeF5fsPpXu4kctOfuZlGjVZXQNW34aOzm8r8S0eVZitPlbhcPiR4gT/aSMz/wd8lZlzZYsje/Jr8u/YtlwjjreZrGRmG8KMOzukV3lLmMppXFMvl4bxv6YFEmIuTsOhbLTwFgh7KYNjodLj/LsqRVfwz31PgWQFTEPICV7GCvgVlPRxnofqKSjgTWI4mxDhBpVcATvaoBl1L/6WLbFvBsoAUBItWwctO2xalKxF5szhGm8lccoc5MZr8kfE0uxMgsxz4er68iCID+rsCAQM="

const (
	psiRSLURL   = "https://s3.amazonaws.com//psiphon/web/mjr4-p23r-puwl/server_list_compressed"
	speedURL    = "https://speed.cloudflare.com/__down?bytes=20000000"
	psiPlatform = "Android_4.0.4_com.example.exampleClientLibraryApp"
)

var psiProtoSets = map[string][]string{
	"meek": {"FRONTED-MEEK-OSSH", "FRONTED-MEEK-HTTP-OSSH"},
	"tls":  {"TLS-OSSH", "UNFRONTED-MEEK-HTTPS-OSSH", "UNFRONTED-MEEK-SESSION-TICKET-OSSH"},
	"quic": {"QUIC-OSSH"},
	"ossh": {"OSSH", "SHADOWSOCKS-OSSH", "UNFRONTED-MEEK-OSSH"},
	// Conduit / in-proxy: the tunnel goes through volunteer Conduit
	// proxies (home IPs, WebRTC), matched by Psiphon brokers.
	"conduit": {"INPROXY-WEBRTC-OSSH", "INPROXY-WEBRTC-TLS-OSSH", "INPROXY-WEBRTC-UNFRONTED-MEEK-OSSH",
		"INPROXY-WEBRTC-UNFRONTED-MEEK-HTTPS-OSSH", "INPROXY-WEBRTC-UNFRONTED-MEEK-SESSION-TICKET-OSSH", "INPROXY-WEBRTC-QUIC-OSSH"},
}

var psiDPINames = map[string]string{
	"":       "стандартный обход",
	"off":    "без обхода",
	"hello":  "только разрез TLS-приветствия",
	"light":  "лёгкое дробление",
	"strong": "сильное дробление",
	"auto":   "авто: перебор и запоминание",
}

// strategyDef is one way of reaching Psiphon. Enabled strategies are tried in
// the configured order until one connects.
type strategyDef struct {
	ID        string
	Title     string
	Transport string // direct | warp | proxy
	Protos    string // key of psiProtoSets, "" = all
	DPI       string // forced DPI mode, "" = use settings
	Upstream  string // None | Warp | Proxy (for the UI)
}

var psiStrategies = []strategyDef{
	{ID: "auto", Title: "Авто (все протоколы)", Transport: "direct", Upstream: "None"},
	{ID: "conduit", Title: "Conduit (через добровольцев)", Transport: "direct", Protos: "conduit", Upstream: "None"},
	{ID: "meek", Title: "Через CDN (meek)", Transport: "direct", Protos: "meek", Upstream: "None"},
	{ID: "tls", Title: "TLS", Transport: "direct", Protos: "tls", Upstream: "None"},
	{ID: "quic", Title: "QUIC", Transport: "direct", Protos: "quic", DPI: "off", Upstream: "None"},
	{ID: "ossh", Title: "OSSH и Shadowsocks", Transport: "direct", Protos: "ossh", Upstream: "None"},
	{ID: "via-warp", Title: "Через WARP", Transport: "warp", Upstream: "Warp"},
	{ID: "via-proxy", Title: "Через внешний прокси", Transport: "proxy", Upstream: "Proxy"},
}

func strategyByID(id string) (strategyDef, bool) {
	for _, s := range psiStrategies {
		if s.ID == id {
			return s, true
		}
	}
	return strategyDef{}, false
}

type psiNotice struct {
	Type string         `json:"noticeType"`
	Data map[string]any `json:"data"`
}

var (
	errRotate   = errors.New("смена узла")
	errNext     = errors.New("следующий способ")
	errUnstable = errors.New("туннели рвутся вскоре после подключения")
	errTimeout  = errors.New("не удалось подключиться за отведённое время")
	psiErrRe    = regexp.MustCompile(`\S+#\d+: `)
	psiNoise    = []string{"Config migration", "DSL", "RoundTripperFailedError", "tactics request aborted", "context canceled", "is not a Closer"}
)

// Psi is the Psiphon engine.
type Psi struct {
	app     *App
	dataDir string
	dpiAuto psiDPIAuto // psiphon.dpi = auto: rotation of fragmentation modes

	mu          sync.Mutex
	state       string
	lastErr     string
	strategy    strategyDef
	attempt     int
	egress      string
	clientReg   string
	server      string
	protocol    string
	speedKBps   int
	healthMs    int
	since       time.Time
	tunnels     int
	regions     []string
	nodes       []map[string]any
	regionStats map[string]map[string]any
	warnSeen    map[string]bool
	cmdAt       time.Time        // last button press passed on (userCmd)
	attemptAt   time.Time        // start of the current attempt
	unstable    map[string]int64 // method -> unix time until which it goes last

	cur    atomic.Pointer[psiphon.Controller]
	notes  chan psiNotice
	cmd    chan string
	cancel context.CancelFunc
	done   chan struct{}
}

func newPsi(app *App, dataDir string) *Psi {
	p := &Psi{app: app, dataDir: dataDir, state: "stopped", regionStats: map[string]map[string]any{},
		notes: make(chan psiNotice, 64), cmd: make(chan string, 4), warnSeen: map[string]bool{}}
	psiphon.SetNoticeWriter(psiphon.NewNoticeReceiver(p.onNotice))
	return p
}

func ptr[T any](v T) *T { return &v }

// psiRSLURLs returns the remote server list in the plural config form.
// The URL MUST be base64 there ("TransferURLs.DecodeAndValidate: illegal
// base64" otherwise); the singular RemoteServerListUrl is deprecated.
func psiRSLURLs() parameters.TransferURLs {
	return parameters.TransferURLs{{
		URL:               base64.StdEncoding.EncodeToString([]byte(psiRSLURL)),
		OnlyAfterAttempts: 0,
	}}
}

func short(s string, n int) string {
	if len([]rune(s)) <= n {
		return s
	}
	return string([]rune(s)[:n]) + "…"
}

func num(v any) int {
	if f, ok := v.(float64); ok {
		return int(f)
	}
	return 0
}

func strList(v any) []string {
	arr, _ := v.([]any)
	out := make([]string, 0, len(arr))
	for _, x := range arr {
		if s, ok := x.(string); ok {
			out = append(out, s)
		}
	}
	return out
}

func cleanPsiErr(s string) string { return short(psiErrRe.ReplaceAllString(s, ""), 200) }

func (p *Psi) set(f func()) {
	p.mu.Lock()
	f()
	p.mu.Unlock()
}

// ---- control ----

func (p *Psi) Start() {
	p.mu.Lock()
	if p.cancel != nil {
		p.mu.Unlock()
		return
	}
	ctx, cancel := context.WithCancel(p.app.ctx)
	p.cancel = cancel
	p.done = make(chan struct{})
	p.state = "connecting"
	p.lastErr = ""
	done := p.done
	p.mu.Unlock()
	go func() {
		defer close(done)
		// A panic deep inside the tunnel code must not leave the program
		// without Psiphon: log it and start the connection loop again.
		for catchPanic("Psiphon", func() { p.run(ctx) }) && ctx.Err() == nil {
			p.set(func() { p.state = "reconnecting" })
			select {
			case <-ctx.Done():
			case <-time.After(3 * time.Second):
			}
		}
	}()
}

func (p *Psi) Stop() {
	p.mu.Lock()
	cancel, done := p.cancel, p.done
	p.cancel = nil
	p.mu.Unlock()
	if cancel == nil {
		return
	}
	cancel()
	select {
	case <-done:
	case <-time.After(10 * time.Second):
	}
	p.set(func() { p.state = "stopped"; p.tunnels = 0; p.since = time.Time{} })
	logf("info", "Psiphon остановлен")
}

func (p *Psi) Restart() { p.Stop(); p.Start() }

func (p *Psi) send(c string) {
	select {
	case p.cmd <- c:
	default:
	}
}

// Next skips to the next connection strategy.
func (p *Psi) Next() int { return p.userCmd("next") }

// NewNode rotates NetworkID so Psiphon picks a different server.
func (p *Psi) NewNode() int { return p.userCmd("rotate") }

func (p *Psi) running() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.cancel != nil
}

// ---- engine loop ----

func (p *Psi) enabled() []strategyDef {
	c := p.app.cfg
	c.mu.Lock()
	ids := append([]string(nil), c.Psiphon.Strategies...)
	c.mu.Unlock()
	out := []strategyDef{}
	for _, id := range ids {
		if s, ok := strategyByID(id); ok && p.available(s) {
			out = append(out, s)
		}
	}
	return out
}

func (p *Psi) available(s strategyDef) bool {
	c := p.app.cfg
	c.mu.Lock()
	defer c.mu.Unlock()
	switch s.Transport {
	case "warp":
		return c.Warp.Enabled && (c.Warp.Engine != "socks" || c.Warp.Socks != "")
	case "proxy":
		return c.Proxy.Enabled && c.Proxy.Upstream != ""
	}
	return true
}

func (p *Psi) file(name string) string { return filepath.Join(p.dataDir, name) }

func (p *Psi) netID() string {
	if b, err := os.ReadFile(p.file("psiroute-netid")); err == nil && len(strings.TrimSpace(string(b))) > 0 {
		return strings.TrimSpace(string(b))
	}
	return "psiroute"
}

func (p *Psi) rotateNetID() {
	id := fmt.Sprintf("psiroute-%d", time.Now().UnixNano())
	_ = os.WriteFile(p.file("psiroute-netid"), []byte(id), 0o600)
}

func (p *Psi) run(ctx context.Context) {
	fails := 0
	for ctx.Err() == nil {
		list := p.order(p.enabled(), p.lastGood())
		if len(list) == 0 {
			p.set(func() {
				p.state = "error"
				p.lastErr = "нет доступных способов подключения — включите хотя бы один"
			})
			select {
			case <-ctx.Done():
				return
			case <-time.After(5 * time.Second):
				continue
			}
		}
		s := list[fails%len(list)]
		timeout := 0
		if len(list) > 1 {
			timeout = attemptTimeout(fails / len(list))
			if s.Transport == "warp" && !p.warpUp() {
				timeout += 60 // WARP itself may still be connecting
			}
		}
		p.set(func() {
			p.attempt++
			p.strategy = s
			p.attemptAt = time.Now()
			if p.state != "connected" {
				if fails > 0 {
					p.state = "reconnecting"
				} else {
					p.state = "connecting"
				}
			}
			p.warnSeen = map[string]bool{}
		})
		if timeout > 0 {
			logf("info", "Psiphon: пробую «%s» (до %d с)", s.Title, timeout)
		} else {
			logf("info", "Psiphon: пробую «%s»", s.Title)
		}
		wasUnstable := p.isUnstable(s.ID)
		wasConnected, err := p.attemptOnce(ctx, s, timeout)
		if ctx.Err() != nil {
			return
		}
		switch {
		case errors.Is(err, errRotate), errors.Is(err, errNetChange):
			p.set(func() { p.state = "reconnecting" })
			continue
		case errors.Is(err, errNext):
			fails++
			p.set(func() { p.state = "reconnecting" })
			continue
		case errors.Is(err, errUnstable):
			// the method went to the end of the list, so the next one now
			// stands in its place (unless it was at the end already)
			if wasUnstable || len(list) == 1 {
				fails++
			}
			p.set(func() { p.state = "reconnecting" })
			continue
		}
		if wasConnected {
			fails = 0
		} else {
			fails++
		}
		msg := "соединение потеряно"
		if err != nil {
			msg = cleanPsiErr(err.Error())
		}
		p.set(func() { p.state = "reconnecting"; p.lastErr = msg })
		logf("warn", "Psiphon «%s»: %s", s.Title, msg)
		if len(list) == 1 || fails%len(list) == 0 {
			wait := time.Duration(min(5<<min(fails/max(len(list), 1), 5), 120)) * time.Second
			select {
			case <-ctx.Done():
				return
			case <-time.After(wait):
			}
		}
	}
}

func (p *Psi) configFor(s strategyDef, timeout int) *psiphon.Config {
	c := p.app.cfg
	c.mu.Lock()
	region := strings.ToUpper(c.Psiphon.Country)
	pool := c.Psiphon.Parallel
	dpi := c.Psiphon.DPI
	warp := c.Warp.Socks
	builtinWarp := c.Warp.Engine != "socks"
	upstream := c.Proxy.Upstream
	c.mu.Unlock()
	if pool < 1 {
		pool = 1
	}
	if pool > 4 {
		pool = 4
	}
	dir := filepath.Join(p.dataDir, "psiphon")
	_ = os.MkdirAll(dir, 0o700)
	cfg := &psiphon.Config{
		EgressRegion:                       region,
		DisableLocalSocksProxy:             true,
		DisableLocalHTTPProxy:              true,
		PropagationChannelId:               "FFFFFFFFFFFFFFFF",
		SponsorId:                          "FFFFFFFFFFFFFFFF",
		RemoteServerListDownloadFilename:   "remote_server_list",
		RemoteServerListSignaturePublicKey: psiRSLKey,
		RemoteServerListURLs:               psiRSLURLs(),
		EmitDiagnosticNotices:              true,
		NetworkID:                          p.netID(),
		ClientPlatform:                     psiPlatform,
		DataRootDirectory:                  dir,
		TunnelPoolSize:                     pool,
		EstablishTunnelPausePeriodSeconds:  ptr(2),
	}
	if timeout > 0 {
		cfg.EstablishTunnelTimeoutSeconds = &timeout
	}
	switch s.Transport {
	case "warp":
		if builtinWarp && p.app != nil {
			if addr := p.app.warp.Addr(); addr != "" {
				warp = addr // the built-in WARP's local port
				p.app.warp.Want()
			}
		}
		cfg.UpstreamProxyURL = "socks5://" + strings.TrimPrefix(warp, "socks5://")
	case "proxy":
		cfg.UpstreamProxyURL = upstream
	}
	if cfg.UpstreamProxyURL != "" {
		cfg.UpstreamProxyAllowAllServerEntrySources = ptr(true) // *bool in this tunnel-core
		return cfg                                              // fragmentation is pointless inside an upstream tunnel
	}
	if s.DPI != "" {
		dpi = s.DPI
	}
	if dpi == "auto" {
		dpi = p.dpiAuto.next()
	}
	applyDPI(cfg, dpi)
	if set := psiProtoSets[s.Protos]; len(set) > 0 {
		cfg.LimitTunnelProtocols = append([]string(nil), set...)
	}
	return cfg
}

// applyDPI configures tunnel-core's fragmentor (byte-level splitting of the
// first bytes of each connection with random delays) and TLS ClientHello
// fragmentation - the same ideas zapret/GoodbyeDPI use, built into Psiphon.
func applyDPI(c *psiphon.Config, mode string) {
	frag := func(minT, maxT, minW, maxW, minD, maxD int) {
		c.FragmentorProbability = ptr(1.0)
		c.FragmentorMinTotalBytes = ptr(minT)
		c.FragmentorMaxTotalBytes = ptr(maxT)
		c.FragmentorMinWriteBytes = ptr(minW)
		c.FragmentorMaxWriteBytes = ptr(maxW)
		c.FragmentorMinDelayMicroseconds = ptr(minD)
		c.FragmentorMaxDelayMicroseconds = ptr(maxD)
	}
	switch mode {
	case "off":
		c.FragmentorProbability = ptr(0.0)
		c.TLSFragmentClientHelloProbability = ptr(0.0)
		return
	case "hello":
		c.FragmentorProbability = ptr(0.0)
	case "light":
		frag(100, 600, 20, 200, 100, 2000)
	case "strong":
		frag(1000, 3000, 1, 10, 5000, 30000)
	default:
		frag(300, 1500, 1, 60, 500, 10000)
	}
	c.TLSFragmentClientHelloProbability = ptr(1.0)
}

func (p *Psi) attemptOnce(ctx context.Context, s strategyDef, timeout int) (connected bool, err error) {
	cfg := p.configFor(s, timeout)
	if err := cfg.Commit(true); err != nil {
		return false, err
	}
	if err := psiphon.OpenDataStore(cfg); err != nil {
		return false, err
	}
	defer psiphon.CloseDataStore()
	ctl, err := psiphon.NewController(cfg)
	if err != nil {
		return false, err
	}
	// drain stale notices
	for len(p.notes) > 0 {
		<-p.notes
	}
	actx, cancel := context.WithCancel(ctx)
	runDone := make(chan struct{})
	go func() {
		ctl.Run(actx)
		close(runDone)
	}()
	defer func() {
		p.cur.Store(nil)
		cancel()
		select {
		case <-runDone:
		case <-time.After(8 * time.Second):
		}
		p.set(func() { p.tunnels = 0 })
	}()

	healthEvery := func() time.Duration {
		p.app.cfg.mu.Lock()
		defer p.app.cfg.mu.Unlock()
		return time.Duration(max(p.app.cfg.Psiphon.HealthIntervalS, 10)) * time.Second
	}
	health := time.NewTicker(healthEvery())
	defer health.Stop()
	healthFails := 0
	// upAt: when the tunnels came up; quick: how often they were lost soon
	// after; holdC fires once they held long enough to be remembered
	var upAt time.Time
	quick := 0
	var holdC <-chan time.Time

	for {
		select {
		case <-ctx.Done():
			return connected, ctx.Err()
		case <-runDone:
			return connected, errors.New("Psiphon завершил работу")
		case n := <-p.notes:
			switch n.Type {
			case "Tunnels":
				count := num(n.Data["count"])
				p.set(func() { p.tunnels = count })
				if count > 0 && p.cur.Load() == nil {
					connected = true
					p.cur.Store(ctl)
					p.set(func() { p.state = "connected"; p.lastErr = ""; p.since = time.Now() })
					logf("info", "Psiphon подключён: «%s»", s.Title)
					upAt, holdC = time.Now(), time.After(holdOK)
					go p.onConnected(actx, s)
				} else if count == 0 && p.cur.Load() != nil {
					p.cur.Store(nil)
					p.set(func() { p.state = "reconnecting"; p.since = time.Time{} })
					logf("warn", "Psiphon: туннели потеряны, переподключаюсь")
					holdC = nil
					if life := time.Since(upAt); !upAt.IsZero() && life < shortLife {
						quick++
						logf("warn", "Psiphon «%s»: туннели продержались всего %s", s.Title, humanDur(life))
						if quick >= 2 {
							p.markUnstable(s.ID, true)
							logf("warn", "Psiphon «%s»: туннели рвутся вскоре после подключения — похоже, сеть режет этот способ. Пробую следующий, а этот следующие %s — последним", s.Title, humanDur(unstableFor))
							return true, errUnstable
						}
					}
				}
			case "EstablishTunnelTimeout":
				return connected, errTimeout
			case "Exiting":
				return connected, errors.New("Psiphon завершил работу")
			}
		case c := <-p.cmd:
			switch c {
			case "rotate":
				p.rotateNetID()
				logf("info", "Psiphon: меняю узел")
				return connected, errRotate
			case "next":
				logf("info", "Psiphon: следующий способ подключения")
				return connected, errNext
			case "check": // after sleep or a network change (netwatch.go)
				if p.cur.Load() == nil {
					continue // still connecting: Psiphon retries by itself
				}
				ms, herr := p.ping(ctx)
				if herr != nil {
					if ctx.Err() != nil {
						return connected, ctx.Err()
					}
					logf("warn", "Psiphon: после смены сети туннель не отвечает (%v) — переподключаюсь", herr)
					return connected, errNetChange
				}
				healthFails = 0
				logf("info", "Psiphon: туннель работает (%d мс)", ms)
			}
		case <-holdC:
			holdC = nil
			_ = os.WriteFile(p.file("psiroute-last"), []byte(s.ID), 0o600)
			if p.isUnstable(s.ID) {
				p.markUnstable(s.ID, false)
			}
		case <-health.C:
			if p.cur.Load() == nil {
				continue
			}
			ms, herr := p.ping(ctx)
			if herr != nil {
				healthFails++
				logf("warn", "Psiphon: проверка связи не прошла (%d/3): %s", healthFails, short(herr.Error(), 120))
				if healthFails >= 3 {
					p.rotateNetID()
					return connected, errRotate
				}
			} else {
				healthFails = 0
				p.set(func() { p.healthMs = ms })
			}
			health.Reset(healthEvery())
		}
	}
}

// onConnected checks where we came out, measures latency and, if a minimum
// speed is set, measures the speed and rotates slow nodes away.
func (p *Psi) onConnected(ctx context.Context, s strategyDef) {
	p.dpiAuto.good()
	tctx, cancel := context.WithTimeout(ctx, 20*time.Second)
	tr, err := getTrace(tctx, p.Dial)
	cancel()
	if err == nil {
		p.set(func() {
			if tr.Loc != "" {
				p.egress = tr.Loc
			}
		})
		logf("info", "Psiphon: выход %s (%s, %s)", tr.IP, tr.Loc, tr.Colo)
	}
	ms, _ := p.ping(ctx)
	p.mu.Lock()
	p.healthMs = ms
	node := map[string]any{"region": p.egress, "server": p.server, "protocol": p.protocol,
		"strategy_title": s.Title, "since": time.Now().Unix()}
	p.nodes = append([]map[string]any{node}, p.nodes...)
	if len(p.nodes) > 30 {
		p.nodes = p.nodes[:30]
	}
	p.mu.Unlock()

	p.app.cfg.mu.Lock()
	minSpeed := p.app.cfg.Psiphon.MinSpeedKBps
	p.app.cfg.mu.Unlock()
	if minSpeed <= 0 {
		return
	}
	kbps, err := p.speed(ctx, 8*time.Second)
	if err != nil || ctx.Err() != nil {
		return
	}
	if kbps < minSpeed {
		logf("warn", "Psiphon: узел медленный (%d КБ/с < %d), меняю", kbps, minSpeed)
		p.send("rotate") // not a button press: no pause
	}
}

// ---- dialing ----

// Dial opens a connection through the active Psiphon tunnel. If Psiphon is
// still connecting it waits up to 20 seconds.
func (p *Psi) Dial(ctx context.Context, network, addr string) (net.Conn, error) {
	deadline := time.Now().Add(20 * time.Second)
	for try := 0; ; try++ {
		ctl := p.cur.Load()
		if ctl == nil {
			if !p.running() || time.Now().After(deadline) {
				return nil, errors.New("Psiphon не подключён")
			}
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(300 * time.Millisecond):
			}
			continue
		}
		type res struct {
			c   net.Conn
			err error
		}
		ch := make(chan res, 1)
		go func() {
			c, err := ctl.Dial(addr, nil)
			ch <- res{c, err}
		}()
		select {
		case <-ctx.Done():
			go func() {
				if r := <-ch; r.c != nil {
					r.c.Close()
				}
			}()
			return nil, ctx.Err()
		case r := <-ch:
			if r.err == nil {
				return r.c, nil
			}
			if try >= 1 {
				return nil, errors.New(cleanPsiErr(r.err.Error()))
			}
		}
	}
}

// ping measures the round trip of a tiny HTTP request through the tunnel.
func (p *Psi) ping(ctx context.Context) (int, error) {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	t0 := time.Now()
	c, err := p.Dial(ctx, "tcp", "www.gstatic.com:80")
	if err != nil {
		return 0, err
	}
	defer c.Close()
	_ = c.SetDeadline(time.Now().Add(10 * time.Second))
	if _, err := io.WriteString(c, "HEAD /generate_204 HTTP/1.1\r\nHost: www.gstatic.com\r\nConnection: close\r\n\r\n"); err != nil {
		return 0, err
	}
	line, err := bufio.NewReader(c).ReadString('\n')
	if err != nil {
		return 0, err
	}
	if !strings.HasPrefix(line, "HTTP/") {
		return 0, errors.New("неожиданный ответ")
	}
	return int(time.Since(t0).Milliseconds()), nil
}

// speed downloads for up to d and returns KB/s (0 when under 32 KB came in).
func (p *Psi) speed(ctx context.Context, d time.Duration) (int, error) {
	ctx, cancel := context.WithTimeout(ctx, d+10*time.Second)
	defer cancel()
	cl := &http.Client{Transport: &http.Transport{DialContext: p.Dial}}
	defer cl.CloseIdleConnections()
	req, err := http.NewRequestWithContext(ctx, "GET", speedURL, nil)
	if err != nil {
		return 0, err
	}
	resp, err := cl.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	t0 := time.Now()
	buf := make([]byte, 64<<10)
	var total int64
	for time.Since(t0) < d {
		n, err := resp.Body.Read(buf)
		total += int64(n)
		if err != nil {
			break
		}
	}
	secs := time.Since(t0).Seconds()
	kbps := 0
	if total >= 32<<10 && secs > 0 {
		kbps = int(float64(total) / 1024 / secs)
	}
	p.mu.Lock()
	p.speedKBps = kbps
	if p.egress != "" {
		p.regionStats[p.egress] = map[string]any{"kbps": kbps, "ms": p.healthMs}
	}
	p.mu.Unlock()
	return kbps, nil
}

// SpeedTest is the "measure speed" button.
func (p *Psi) SpeedTest(ctx context.Context) map[string]any {
	ms, err := p.ping(ctx)
	if err != nil {
		return map[string]any{"ok": false, "error": short(err.Error(), 160)}
	}
	kbps, err := p.speed(ctx, 8*time.Second)
	if err != nil {
		return map[string]any{"ok": false, "error": short(err.Error(), 160)}
	}
	p.mu.Lock()
	p.healthMs = ms
	region := p.egress
	p.mu.Unlock()
	return map[string]any{"ok": true, "kbps": kbps, "ms": ms, "region": region}
}

// ---- notices ----

func (p *Psi) onNotice(b []byte) {
	var n psiNotice
	if json.Unmarshal(b, &n) != nil {
		return
	}
	switch n.Type {
	case "Tunnels", "EstablishTunnelTimeout", "Exiting":
		select {
		case p.notes <- n:
		default:
		}
	case "AvailableEgressRegions":
		regs := strList(n.Data["regions"])
		p.set(func() { p.regions = regs })
	case "ClientRegion":
		r, _ := n.Data["region"].(string)
		p.set(func() { p.clientReg = r })
	case "ConnectedServerRegion":
		r, _ := n.Data["serverRegion"].(string)
		p.set(func() { p.egress = r })
	case "ActiveTunnel":
		proto, _ := n.Data["protocol"].(string)
		id, _ := n.Data["diagnosticID"].(string)
		p.set(func() {
			p.protocol = proto
			if id != "" {
				p.server = id
			}
		})
	case "ConnectingServer":
		if id, _ := n.Data["diagnosticID"].(string); id != "" {
			p.set(func() {
				if p.state != "connected" {
					p.server = id
				}
			})
		}
	case "CandidateServers":
		logf("info", "Psiphon: серверов-кандидатов: %d", num(n.Data["count"]))
	case "RemoteServerListResourceDownloaded":
		logf("info", "Psiphon: список серверов обновлён")
	case "UpstreamProxyError":
		msg, _ := n.Data["message"].(string)
		msg = cleanPsiErr(msg)
		p.set(func() { p.lastErr = "внешний прокси: " + msg })
		logf("warn", "Psiphon: ошибка внешнего прокси: %s", msg)
	case "Warning", "Error":
		msg, _ := n.Data["message"].(string)
		if strings.Contains(msg, "close tunnel ssh error") && strings.Contains(msg, "use of closed network connection") {
			return // a spare tunnel closed after the pool filled up: not an error
		}
		for _, x := range psiNoise {
			if strings.Contains(msg, x) {
				return
			}
		}
		msg = cleanPsiErr(msg)
		p.mu.Lock()
		key := short(msg, 60)
		fresh := !p.warnSeen[key] && len(p.warnSeen) < 6
		p.warnSeen[key] = true
		p.mu.Unlock()
		if fresh {
			logf("warn", "Psiphon: %s", msg)
		}
	}
}

// ---- views for the API ----

func (p *Psi) view() map[string]any {
	p.mu.Lock()
	defer p.mu.Unlock()
	since := int64(0)
	if !p.since.IsZero() {
		since = p.since.Unix()
	}
	p.app.cfg.mu.Lock()
	region := p.app.cfg.Psiphon.Country
	p.app.cfg.mu.Unlock()
	return map[string]any{
		"state": p.state, "last_error": p.lastErr, "strategy_title": p.strategy.Title,
		"attempt": p.attempt, "egress_region": p.egress, "region": region,
		"server": p.server, "protocol": p.protocol, "speed_kbps": p.speedKBps,
		"health_ms": p.healthMs, "connected_since": since, "active_slot": 0,
		"client_region": p.clientReg, "tunnels": p.tunnels,
	}
}

// slots shows the tunnel pool: slot 0 carries traffic, the rest are warm
// standby tunnels tunnel-core keeps for instant failover.
func (p *Psi) slots() []map[string]any {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.app.cfg.mu.Lock()
	n := max(p.app.cfg.Psiphon.Parallel, 1)
	p.app.cfg.mu.Unlock()
	out := make([]map[string]any, 0, n)
	for i := 0; i < n; i++ {
		st := p.state
		switch {
		case p.state == "stopped":
			st = "stopped"
		case i < p.tunnels && i == 0:
			st = "connected"
		case i < p.tunnels:
			st = "standby"
		case p.state == "connected":
			st = "connecting"
		}
		s := map[string]any{"idx": i, "state": st, "strategy": p.strategy.ID, "strategy_title": p.strategy.Title,
			"protocol": "", "server": "", "health_ms": 0, "speed_kbps": 0, "last_error": ""}
		if i == 0 {
			s["protocol"], s["server"], s["health_ms"], s["speed_kbps"], s["last_error"] = p.protocol, p.server, p.healthMs, p.speedKBps, p.lastErr
		}
		out = append(out, s)
	}
	return out
}

func (p *Psi) info() map[string]any {
	c := p.app.cfg
	c.mu.Lock()
	order := append([]string(nil), c.Psiphon.Strategies...)
	parallel, standby := c.Psiphon.Parallel, c.Psiphon.Standby
	health, minSpeed := c.Psiphon.HealthIntervalS, c.Psiphon.MinSpeedKBps
	c.mu.Unlock()
	on := map[string]bool{}
	for _, id := range order {
		on[id] = true
	}
	// enabled strategies first, in priority order, then the rest
	sorted := []strategyDef{}
	for _, id := range order {
		if s, ok := strategyByID(id); ok {
			sorted = append(sorted, s)
		}
	}
	for _, s := range psiStrategies {
		if !on[s.ID] {
			sorted = append(sorted, s)
		}
	}
	list := []map[string]any{}
	for _, s := range sorted {
		protos := psiProtoSets[s.Protos]
		if protos == nil {
			protos = []string{}
		}
		list = append(list, map[string]any{"id": s.ID, "title": s.Title, "protocols": protos,
			"upstream": s.Upstream, "available": p.available(s), "enabled": on[s.ID]})
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	regions := p.regions
	live := len(regions) > 0
	if !live {
		regions = []string{"AT", "BE", "BG", "CA", "CH", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "HU", "IE", "IN", "IT", "JP", "LV", "NL", "NO", "PL", "RO", "RS", "SE", "SG", "SK", "US"}
	}
	nodes := append([]map[string]any(nil), p.nodes...)
	if nodes == nil {
		nodes = []map[string]any{}
	}
	rs := map[string]any{}
	for k, v := range p.regionStats {
		rs[k] = v
	}
	return map[string]any{
		"egress_region": p.egress, "regions": regions, "regions_live": live, "region_stats": rs,
		"nodes": nodes, "strategies": list, "order": order, "parallel": parallel, "standby": standby,
		"health_interval_secs": health, "min_speed_kbps": minSpeed, "dpi": psiDPINames,
	}
}
