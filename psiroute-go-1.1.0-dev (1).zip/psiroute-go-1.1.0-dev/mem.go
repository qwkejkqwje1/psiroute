package main

import (
	"os"
	"runtime/debug"
	"runtime/metrics"
	"strconv"
	"sync"
	"time"
)

// setupMemory runs in every psiroute process: the core, the window, the
// country workers and the DPI probe.
func setupMemory() {
	if os.Getenv("GOGC") == "" {
		debug.SetGCPercent(50) // lighter on memory; traffic buffers are short-lived
	}
	go memTrimmer()
}

// memTrimmer gives freed heap pages back to the system. On its own the Go
// runtime does it only gradually, so after a burst (handshakes, server
// lists, WARP buffers) a process kept its peak size for minutes.
func memTrimmer() {
	s := []metrics.Sample{{Name: "/memory/classes/heap/free:bytes"}}
	for range time.Tick(20 * time.Second) {
		metrics.Read(s)
		if s[0].Value.Kind() == metrics.KindUint64 && s[0].Value.Uint64() >= 4<<20 {
			debug.FreeOSMemory()
		}
	}
}

// goMemory: what the Go runtime holds from the system (heap, stacks, its
// own structures), minus what it has already given back.
func goMemory() uint64 {
	s := []metrics.Sample{{Name: "/memory/classes/total:bytes"}, {Name: "/memory/classes/heap/released:bytes"}}
	metrics.Read(s)
	if s[0].Value.Kind() != metrics.KindUint64 || s[1].Value.Kind() != metrics.KindUint64 {
		return 0
	}
	return s[0].Value.Uint64() - s[1].Value.Uint64()
}

// memSnap: where Psiroute's memory goes. On Windows the sizes are private
// working sets, the "Memory" column of Task Manager.
type memSnap struct {
	App      uint64 `json:"app"`       // the core process
	Go       uint64 `json:"go"`        // of it, held by the Go runtime
	Workers  uint64 `json:"workers"`   // helper processes: countries, DPI probe
	WorkersN int    `json:"workers_n"` //
	Window   uint64 `json:"window"`    // the window process and its WebView2 processes
	WindowN  int    `json:"window_n"`  //
	Watchdog uint64 `json:"watchdog"`  // the crash watchdog (parent process)
	Total    uint64 `json:"total"`
}

var memCache struct {
	sync.Mutex
	at   time.Time
	snap memSnap
}

// memView is cached for 2 s: the UI asks every second, the tray every 2 s.
func memView() memSnap {
	memCache.Lock()
	defer memCache.Unlock()
	if !memCache.at.IsZero() && time.Since(memCache.at) < 2*time.Second {
		return memCache.snap
	}
	s := procTreeMemory()
	s.Go = goMemory()
	if s.App == 0 {
		s.App = s.Go // no OS figure on this platform
	}
	s.Total = s.App + s.Workers + s.Window + s.Watchdog
	memCache.at, memCache.snap = time.Now(), s
	return s
}

func mbText(b uint64) string {
	return strconv.FormatUint((b+1<<19)>>20, 10) + " МБ"
}
